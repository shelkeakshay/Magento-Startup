<?php

class Capital_Tool_MenController extends Mage_Core_Controller_Front_Action {

    public function getBasePath() {
        $basePath = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        return $basePath;
    }

    public function getBaseDir() {
        $baseDir = Mage::getBaseDir();
        return $baseDir;
    }

    public function getReadConnection() {
        $r_connection = Mage::getSingleton('core/resource')->getConnection('core_read');
        return $r_connection;
    }

    public function getWriteConnection() {
        $w_connection = Mage::getSingleton('core/resource')->getConnection('core_write');
        return $w_connection;
    }

    public function suitAction() {
        $this->loadLayout();
        $this->getLayout()->getBlock("head")->setTitle($this->__("Men Suit Tool"));

        /* $breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
          $breadcrumbs->addCrumb("home", array(
          "label" => $this->__("Home Page"),
          "title" => $this->__("Home Page"),
          "link" => Mage::getBaseUrl()
          ));

          $breadcrumbs->addCrumb("socks tool", array(
          "label" => $this->__("Capital Tool"),
          "title" => $this->__("Capital Tool")
          )); */

        $this->renderLayout();
    }

    public function getSuitAccentAction() {
        $basePath = $this->getBasePath();
        $r_connection = $this->getReadConnection();

        /* $sqlbrass_buttons = "SELECT * FROM suitbrassbuttons WHERE status='1'";
          $brass_collection = $r_connection->fetchAll($sqlbrass_buttons); */

        $brass_buttons = array();

        /* foreach ($brass_collection as $button) {
          $id     = $button->getbrassbuttonsId();
          $type   = $button->gettype();
          $name = $button->getbtnCount().' Button';
          $btn_count   = $button->getbtnCount();
          $status = $button->getstatus();
          $thumb  = $button->getthumb();

          if ($status) {
          $brass_buttons[] = array('id' => $id,"style_type"=>$type,"btn_count"=>$btn_count, 'parent' => 'brassbutton', "designType" => "jacket", 'name' => $name, "img" => $basePath . 'media/'.$thumb);
          }
          } */

        $sqlbrass = "SELECT * FROM jacket_brass_brass where status = '1'";
        $jackbrass_collection = $r_connection->fetchAll($sqlbrass);


        $i = 1;
        foreach ($jackbrass_collection as $bc) {
            $brass_buttons[] = array(
                'id' => $i,
                'parent' => 'brassbuttons',
                "designType" => "jacket",
                "designRel" => "buttons",
                'name' => $bc['name'],
                'price' => $bc['price'],
                "class" => "",
                "img" => $basePath . 'media/brass/image' . $bc['th']);

            $i++;
        }


        $brass_data = array('id' => 1, 'name' => 'Brass Buttons', 'class' => "icon-v2-Brass_Buttons ", "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $brass_buttons);


        $sqlthread = "SELECT * FROM suit_suitthreadfabric where status = '1'";
        $thread_collection = $r_connection->fetchAll($sqlthread);

        foreach ($thread_collection as $t) {
            $id = $t['fabric_id'];
            $name = $t['title'];

            $thumb = $t['fabric_thumb'];
            $price = $t['price'];

            $threads[] = array('id' => $id, 'parent' => 'threads', 'price' => $price, "designType" => "jacket", "designRel" => "buttons", 'name' => $name, "img" => $basePath . 'media/' . $thumb, "class" => "");
        }

        $threads_data = array('id' => 2, 'name' => 'Threads', 'class' => "icon-v2-Thread", "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $threads);

        $sqlsquare = "SELECT * FROM suit_suitpocketsquarefabric where status = '1'";
        $pocketsquare_collection = $r_connection->fetchAll($sqlsquare);

        $pocketsquares = array();

        foreach ($pocketsquare_collection as $p) {
            $id = $p['fabric_id'];
            $name = $p['title'];
            $thumb = $p['fabric_thumb'];
            $price = $p['price'];


            $pocketsquares[] = array('id' => $id, 'parent' => 'pocketsquare', 'price' => $price, "designType" => "jacket", "designRel" => "buttons", 'name' => $name, "img" => $basePath . 'media/' . $thumb, "class" => "");
        }

        $pocketsquare_data = array('id' => 3, 'name' => 'Pocketsquare', 'class' => "icon-v2-Main_Icon15", "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $pocketsquares);


        /* $lining_collection = Mage::getModel('lining/lining')->getCollection();

          foreach ($lining_collection as $l) {
          $id = $l->getliningId();
          $name = $l->gettitle();
          $thumb = $l->getliningImage();

          $linings[] = array('id' => $id, 'parent' => 'lining', "designType" => "jacket", "designRel" => "lining", 'name' => $name, "img" => $basePath . 'media/' . $thumb);
          }

          $linings_data = array('id' => 4, 'name' => 'Lining', 'class' =>"icon-pocket",  "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $linings);
         */

        $sqlfab = "SELECT * FROM shirt_suitfabric where status = '1'";
        $fabrics_collection = $r_connection->fetchAll($sqlfab);

        $fabrics = array();

        foreach ($fabrics_collection as $fabric) {
            $id = $fabric['fabric_id'];
            $name = $fabric['title'];
            //    $thumb = $fabric['fabric_thumb'];
            $thumb = $fabric['display_fabric_thumb'];
            $large_image = $fabric['fabric_large_image'];
            $status = $fabric['status'];
            $price = $fabric['fab_avail'];


            if ($status) {
                $fabrics[] = array('id' => $id, 'name' => $name, 'price' => $price, 'parent' => 'lining', "designType" => "jacket", "designRel" => "lining", "img" => $basePath . 'media/' . $thumb, "large_img" => $basePath . 'media/' . $large_image, "class" => "");
            }
        }
        $linings_data = array('id' => 4, 'name' => 'Lining', 'class' => "icon-v2-Main_Icon16", "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $fabrics);


        $sqlbackcoll = "SELECT * FROM backcollar where status = '1' order by backcollar_id desc";
        $backcollar_collection = $r_connection->fetchAll($sqlbackcoll);
        $backcollar = array();
        $i = 1;
        foreach ($backcollar_collection as $bcoll) {
            $backcollar[] = array(
                'id' => $i,
                'parent' => 'backcollaraccent',
                "designType" => "jacket",
                "designRel" => "buttons",
                'name' => $bcoll['title'],
                'price' => $bcoll['price'],
                "img" => $basePath . 'media/' . $bcoll['thumb'],
                'class' => $bcoll['class'],
            );
            $i++;
        }

        $backcollar_data = array('id' => 5, 'name' => 'Back Collar', 'class' => "icon-v2-Custom_Colour", "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00_Backclloar_Main_Icon.png', "style" => $backcollar);

        $sqlelbpatch = "SELECT * FROM elbowpatches where status = '1' order by elbowpatches_id desc";
        $elbowpatches_collection = $r_connection->fetchAll($sqlelbpatch);
        $elbowpatches = array();
        $i = 1;
        foreach ($elbowpatches_collection as $elbpatch) {
            $elbowpatches[] = array(
                'id' => $i,
                'parent' => 'elbowpatches',
                "designType" => "jacket",
                "designRel" => "buttons",
                'name' => $elbpatch['title'],
                'price' => $elbpatch['price'],
                "img" => $basePath . 'media/' . $elbpatch['thumb'],
                'class' => $elbpatch['class'],
            );
            $i++;
        }

        $elbowpatches_data = array('id' => 6, 'name' => 'Elbow Patch', 'class' => "icon-v2-With_Elbow_Patch", "designType" => "jacket", "img" => $basePath . 'media/jacket_img/thumbnail/00_Elbowpatch_Main_Icon.png', "style" => $elbowpatches);
        $design_data = array($brass_data, $threads_data, $pocketsquare_data, $linings_data, $backcollar_data, $elbowpatches_data);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($design_data));
    }

    public function getSuitDesignAction() {
        $basePath = $this->getBasePath();
        $r_connection = $this->getReadConnection();

        $sqlfit = "SELECT * FROM suitfit WHERE status='1'";
        $fit_collection = $r_connection->fetchAll($sqlfit);
        $fits = array();

        //print_r($fit_collection->getData());die;
        foreach ($fit_collection as $fit) {
            $id = $fit['suitfit_id'];
            $name = $fit['title'];
            $class = $fit['class'];
            $status = $fit['status'];
            $thumb = $fit['thumb'];
            $price = $fit['price'];

            if ($status) {
                $fits[] = array('id' => $id, 'class' => $class, 'parent' => 'Fit', "designType" => "jacket", 'name' => $name, "price" => $price, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $fit_data = array('id' => 1, 'name' => 'Fit', "designType" => "jacket", 'class' => "icon-v2-Fit_Main_Icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $fits);

        $sqlstyle = "SELECT * FROM suitstyle WHERE status='1'";
        $style_collection = $r_connection->fetchAll($sqlstyle);

        $styles = array();

        foreach ($style_collection as $style) {
            $id = $style['suitstyle_id'];
            $name = $style['title'];
            $class = $style['class'];
            $type = $style['type'];
            $status = $style['status'];
            $thumb = $style['thumb'];
            $price = $style['price'];

            if ($status) {
                $styles[] = array('id' => $id, 'class' => $class, 'parent' => 'Style', "designType" => "jacket", 'name' => $name, "price" => $price, 'type' => $id, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $style_data = array('id' => 2, "designType" => "jacket", 'name' => 'Style', 'class' => "icon-v2-Main_Style_Icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $styles);



        $lapels = array();

        $lapel_type = array('Notch', 'Peak', 'Shawl');

        $lapel_type_class = array('icon-notch', 'icon-peak', 'icon-shwal');

        $lapel_type_thumb = array('Lapel_Notch.png', 'Lapel_Peak.png', 'Lapel_Shawl.png');

        $lapel_size = array('Slim', 'Regular', 'Wide');

        $lapel_size_class = array('icon-slim-lapel', 'icon-standard', 'icon-wide');

        $lapel_size_thumb = array('Width_Slim.png', 'Width_Standard.png', 'Width_Wide.png');


        $sqllapel = "SELECT * FROM suitlapeltype WHERE status='1'";
        $lapeltype_collection = $r_connection->fetchAll($sqllapel);

        $i = 0;
        foreach ($lapeltype_collection as $ltc) {
            $lapels[] = array(
                'id' => $i + 1,
                'parent' => 'Lapel',
                'class' => $ltc['class'],
                "designType" => "jacket",
                'name' => $ltc['title'],
                'price' => $ltc['price'],
                "img" => '');
            $i++;
        }

        /*
          for ($i = 0; $i < 3; $i++) {
          $lapels[] = array(
          'id' => $i + 1,
          'parent' => 'Lapel',
          'class'=>$lapel_type_class[$i],
          "designType" => "jacket",
          'name' => $lapel_type[$i],
          "img" => $basePath . 'media/glow_mask/lapel/'.$lapel_type_thumb[$i]);
          } */

        $sqlsize = "SELECT * FROM suitlapelsize WHERE status='1'";
        $lapelsize_collection = $r_connection->fetchAll($sqlsize);


        $j = 0;
        foreach ($lapelsize_collection as $lsc) {
            $lapel_size1[] = array(
                'id' => $j + 1,
                'parent' => 'Lapel',
                'class' => $lsc['class'],
                "designType" => "jacket",
                'name' => $lsc['title'],
                'price' => $lsc['price'],
                "img" => '');
            $j++;
        }

        /*
          for ($j = 0; $j < 3; $j++) {
          $lapel_size1[] = array(
          'id' => $j + 1,
          'parent' => 'Lapel',
          'class'=>$lapel_size_class[$j],
          "designType" => "jacket",
          'name' => $lapel_size[$j],
          "img" => $basePath.'media/glow_mask/lapel/'.$lapel_size_thumb[$j]);
          } */

        $lapels_data = array('id' => 3, 'name' => 'Lapel', "designType" => "jacket", 'class' => "icon-v2-Lapel_Main_Icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $lapels, "size" => $lapel_size1);

        $sqlpocket = "SELECT * FROM suitpockets WHERE status='1'";
        $pocket_collection = $r_connection->fetchAll($sqlpocket);

        $pockets = array();
        //print_r($pocket_collection->getData());die;
        foreach ($pocket_collection as $pocket) {
            $id = $pocket['suitpocket_id'];
            $name = $pocket['title'];
            $class = $pocket['class'];
            $type = $pocket['type'];
            $thumb = $pocket['thumb'];
            $price = $pocket['price'];
            $status = $pocket['status'];

            if ($status) {
                $pockets[] = array('id' => $id, 'class' => $class, 'name' => $name, 'price' => $price, 'parent' => 'Pockets', "designType" => "jacket", 'type' => $type, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $pockets_data = array('id' => 4, 'name' => 'Pockets', "designType" => "jacket", 'class' => "icon-v2-Pockets_Main_Icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $pockets);



        $sqlsleeve = "SELECT * FROM suitsleeve WHERE status='1'";
        $sleeve_collection = $r_connection->fetchAll($sqlsleeve);

        $j = 0;
        //$sleeve[] = array();
        $sleeve_btns = array();
        foreach($sleeve_collection as $sleeve) {   
            $id = $sleeve['suitsleeve_id'];
            $name = $sleeve['title'];
            $class = $sleeve['class'];
            $thumb = $sleeve['thumb'];
            $btn_count = $sleeve['btn_count'];
            $status = $sleeve['status'];
            $price = $sleeve['price'];  

        if ($status) {
                $sleeve_btns[] = array('id' => $id,'class'=>$class, 'name' => $name, 'price'=>0,'parent' => 'sleeve_buttons', "designType" => "jacket", 'btn_count' => $btn_count, "img" => $basePath . 'media/'.$thumb,);
            }  
        }

        $sleeve_btn_data = array('id' => 5, 'name' => 'sleeve buttons', "designType" => "jacket",'class' =>"icon-v2-Sleeve_Main_Icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $sleeve_btns);

        $sqlvent = "SELECT * FROM suitvent WHERE status='1'";
        $vent_collection = $r_connection->fetchAll($sqlvent);

        $vents = array();

        foreach ($vent_collection as $vent) {
            $id = $vent['suitvent_id'];
            $name = $vent['title'];
            $class = $vent['class'];
            $thumb = $vent['thumb'];
            $price = $vent['price'];
            $main_image = $basePath . 'media/' . $vent['main_image'];
            if (!$vent['main_image']) {
                $main_image = $basePath . 'media/blank.png';
            }
            $status = $vent['status'];

            if ($status) {
                $vents[] = array('id' => $id, 'name' => $name, 'price' => $price, 'class' => $class, 'parent' => 'Vents', "designType" => "jacket", "main_img" => $main_image, "img" => $basePath . 'media/' . $thumb,);
            }
        }

        $vents_data = array('id' => 6, 'name' => 'Vents', "designType" => "jacket", 'class' => "icon-v2-Main_Icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $vents);

        $sqlbutton = "SELECT * FROM suitbutton WHERE status='1'";
        $buttons_collection = $r_connection->fetchAll($sqlbutton);

        $buttons = array();

        foreach ($buttons_collection as $button) {
            $id = $button['suitbutton_id'];
            $type = $button['style_type'];
            $class = $button['class'];
            $name = $button['btn_count'] . ' Button';
            $thumb = $button['thumb'];
            $price = $button['price'];
            $btn_count = $button['btn_count'];
            $status = $button['status'];

            if ($status) {
                $buttons[] = array('id' => $id, 'style_id' => $type, 'price' => $price, 'class' => $class, 'name' => $name, 'parent' => 'buttons', "designType" => "jacket", 'btn_count' => $btn_count, "img" => $basePath . 'media/' . $thumb,);
            }
        }

        $buttons_data = array('id' => 7, 'name' => 'buttons', "designType" => "jacket", 'class' => "icon-v2-Single_Breasted_2_Button", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $buttons);



        $design_data = array($fit_data, $style_data, $lapels_data, $pockets_data, $sleeve_btn_data, $vents_data, $buttons_data);

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($design_data));
    }

    public function getCoatDesignAction() {
        $basePath = $this->getBasePath();
        $r_connection = $this->getReadConnection();
       
        $sqlstyle = "SELECT * FROM suitcoatstyles WHERE status='1'";
        $style_collection = $r_connection->fetchAll($sqlstyle);

        $styles = array();

        foreach ($style_collection as $style) {
            $id     = $style['suitcoatstyles_id'];
            $name   = $style['title'];
            $class  = $style['class'];
            $type   = $style['type'];
            $status = $style['status'];
            $thumb  = $style['thumb'];
            $price  = $style['price'];

            if ($status) {
                $styles[] = array('id' => $id, 'class' => $class, 'parent' => 'topcoatstyle', "designType" => "topcoat", 'name' => $name, "price" => $price, 'type' => $id, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $style_data = array('id' => 1, "designType" => "topcoat", 'name' => 'Style', 'class' => "icon-v2-Style_01-01", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $styles);
        
        
        /*$sqlpockets = "SELECT * FROM suitcoatpockets WHERE status='1'";
        $pockets_collection = $r_connection->fetchAll($sqlpockets);

        $styles = array();

        foreach ($pockets_collection as $pockets) {
            $id     = $pockets['suitcoatpockets_id'];
            $name   = $pockets['title'];
            $class  = $pockets['class'];
            $type   = $pockets['type'];
            $status = $pockets['status'];
            $thumb  = $pockets['thumb'];
            $price  = $pockets['price'];

            if ($status) {
                $pockets[] = array('id' => $id, 'class' => $class, 'parent' => 'topcoatstyle', "designType" => "pant", 'name' => $name, "price" => $price, 'type' => $id, "img" => $basePath . 'media/' . $thumb);
            }
        }
        $pockets_data = array('id' => 2, "designType" => "coat", 'name' => 'Pockets', 'class' => "icon-icon-32", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $pocketss);
        */
        
        
        
        
        $design_data = array($style_data);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($design_data));
    }
    
    
    public function getSuitFabricsAction() {
        $basePath = $this->getBasePath();
        $r_connection = $this->getReadConnection();

        $sqlmaterial = "SELECT * FROM suitmaterial WHERE status='1'";
        $material_collection = $r_connection->fetchAll($sqlmaterial);
        $materials = array();
        foreach ($material_collection as $material) {
            $id = $material['suitmaterial_id'];
            $name = $material['title'];
            $status = $material['status'];
            if ($status) {
                $materials[] = array('id' => $id, 'name' => $name, 'parent' => 'material');
            }
        }
        $sqlpattern = "SELECT * FROM suitpattern WHERE status='1'";
        $pattern_collection = $r_connection->fetchAll($sqlpattern);
        $patterns = array();
        foreach ($pattern_collection as $pattern) {
            $id = $pattern['suitpattern_id'];
            $name = $pattern['title'];
            if ($status) {
                $patterns[] = array('id' => $id, 'name' => $name, 'parent' => 'pattern');
            }
        }
        $sqlseason = "SELECT * FROM suitseason WHERE status='1'";
        $season_collection = $r_connection->fetchAll($sqlseason);
        $seasons = array();
        foreach ($season_collection as $season) {
            $id = $season['suitseason_id'];
            $name = $season['title'];
            if ($status) {
                $seasons[] = array('id' => $id, 'name' => $name, 'parent' => 'seasons');
            }
        }
        $sqlcolor = "SELECT * FROM suitcolor WHERE status='1'";
        $color_collection = $r_connection->fetchAll($sqlcolor);
        $colors = array();
        foreach ($color_collection as $color) {
            $id = $color['suitcolor_id'];
            $name = $color['title'];
            if ($status) {
                $colors[] = array('id' => $id, 'name' => $name, 'parent' => 'color');
            }
        }
        $sqlcategory = "SELECT * FROM suitcategory WHERE status='1'";
        $category_collection = $r_connection->fetchAll($sqlcategory);
        $categorys = array();
        foreach ($category_collection as $category) {
            $id = $category['suitcategory_id'];
            $name = $category['title'];
            $class = $category['class'];

            if ($status) {
                $categorys[] = array('id' => $id, 'name' => $name, 'class' => $class, 'parent' => 'category');
            }
        }

        $categories = array($materials, $patterns, $seasons, $colors, $categorys);

        $sqlfab = "SELECT * FROM shirt_suitfabric WHERE status='1'";
        $fabrics_collection = $r_connection->fetchAll($sqlfab);

        $fabrics = array();


        foreach ($fabrics_collection as $fabric) {

            $material_id = $fabric['suit_material_id'];
            $sqlmaterial = "SELECT * FROM suitmaterial WHERE status='1' AND suitmaterial_id='" . $material_id . "'";
            $material_collection = $r_connection->fetchAll($sqlmaterial);

            $pattern_id = $fabric['suit_pattern_id'];
            $sqlpattern = "SELECT * FROM suitpattern WHERE status='1' AND suitpattern_id='" . $pattern_id . "' ";
            $pattern_collection = $r_connection->fetchAll($sqlpattern);

            $season_id = $fabric['suit_season_id'];
            $sqlseason = "SELECT * FROM suitseason WHERE status='1' AND suitseason_id='" . $season_id . "'";
            $season_collection = $r_connection->fetchAll($sqlseason);

            $color_id = $fabric['suit_color_id'];
            $sqlcolor = "SELECT * FROM suitcolor WHERE status='1' AND suitcolor_id='" . $color_id . "'";
            $color_collection = $r_connection->fetchAll($sqlcolor);

            $category_id = $fabric['suit_category_id'];
            $sqlcategory = "SELECT * FROM suitcategory WHERE status='1' AND suitcategory_id='" . $category_id . "'";
            $category_collection = $r_connection->fetchAll($sqlcategory);

            $name = $fabric['title'];
            $thumb = $fabric['display_fabric_thumb'];
            $large_image = $fabric['fabric_large_image'];
            $style_type = $fabric['style_type'];
            $btn_color_id = 4;//$fabric['btn_color_id'];
            $tie_color = $fabric['tie_color'];
            $shirt_type = $fabric['shirt_type'];
            $shoes_color = $fabric['shoes_color'];
            $status = $fabric['status'];
            $suit_material_id = $fabric['suit_material_id'];
            $suit_pattern_id = $fabric['suit_pattern_id'];
            $suit_season_id = $fabric['suit_season_id'];
            $suit_color_id = $fabric['suit_color_id'];
            $suit_category_id = $fabric['suit_category_id'];
            $price = $fabric['price'];
            $is_fabric = $fabric['is_fabric'];
            $fab_id = $fabric['fabric_id'];

            if ($status) {
                $suit_fab_type_name = $material_collection[0]['title'];

                $fabrics[] = array('id' => $fab_id,
                    'type' => $suit_fab_type_name,
                    'price' => $price,
                    'name' => $name,
                    'img' => $basePath . 'media/' . $thumb,
                    'real_img' => $basePath . 'media/' . $large_image,
                    'style_type' => $style_type,
                    'button_color' => $btn_color_id,
                    'tie_color' => $tie_color,
                    'shirt_type' => $shirt_type,
                    'shoes_color' => $shoes_color,
                    'is_fabric' => $is_fabric,
                    'material_parent' => $material_collection[0]['title'],
                    'pattern_parent' => $pattern_collection[0]['title'],
                    'season_parent' => $season_collection[0]['title'],
                    'color_parent' => $color_collection[0]['title'],
                    'category_parent' => $category_collection[0]['title']
                );
            }
        }

        $fabricInfo = array(
            'fabric' => $fabrics,
            'category' => $categories
        );

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fabricInfo));
    }

    public function getSuitPantAction() {
        $basePath = $this->getBasePath();
        $r_connection = $this->getReadConnection();

        $sqlfit = "SELECT * FROM pantfit WHERE status='1'";
        $fit_collection = $r_connection->fetchAll($sqlfit);

        $fits = array();

        foreach ($fit_collection as $fit) {
            //print_r($fit);
            $id = $fit['pantfit_id'];
            $name = $fit['title'];
            $class = $fit['class'];
            $thumb = $fit['thumb'];
            $price = $fit['price'];
            $status = $fit['status'];

            if ($status) {
                $fits[] = array('id' => $id, 'parent' => 'pantfit', 'price' => $price, 'class' => $class, "designType" => "pant", 'name' => $name, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $fits_data = array('id' => 1, 'name' => 'Fit', "designType" => "pant", 'class' => "icon-v2-Main_Icon6", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $fits);


        $sqlpantpleats = "SELECT * FROM pantpleats WHERE status='1'";
        $pleates_collection = $r_connection->fetchAll($sqlpantpleats);
        $pleates = array();

        foreach ($pleates_collection as $pleate) {
            $id = $pleate['pantpleats_id'];
            $name = $pleate['title'];
            $class = $pleate['class'];
            $glow_image = $pleate['glow_image'];
            $mask_image = $pleate['mask_image'];
            $thumb = $pleate['thumb'];
            $price = $pleate['price'];
            $status = $pleate['status'];

            if ($status) {
                $pleates[] = array('id' => $id, 'parent' => 'pantpleats', 'price' => $price, 'class' => $class, "designType" => "pant", "front_pleate_img" => $basePath . 'media/' . $glow_image, "folded_pleate_img" => $basePath . 'media/' . $mask_image, 'name' => $name, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $pleates_data = array('id' => 2, 'name' => 'Pleats', "designType" => "pant", 'class' => "icon-v2-Main_Icon7", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $pleates);


        $sqlpantfastening = "SELECT * FROM pantfastening WHERE status='1'";
        $fastening_collection = $r_connection->fetchAll($sqlpantfastening);

        $fastenings = array();

        foreach ($fastening_collection as $fastening) {
            $id = $fastening['pantfastening_id'];
            $name = $fastening['title'];
            $class = $fastening['class'];
            $thumb = $fastening['thumb'];
            $price = $fastening['price'];
            $main_img = $fastening['glow_image'];
            $status = $fastening['status'];

            if ($status) {
                $fastenings[] = array('id' => $id, 'parent' => 'fastening', 'price' => $price, 'class' => $class, "designType" => "pant", 'name' => $name, "main_img" => $basePath . 'media/' . $main_img, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $fastening_data = array('id' => 3, 'name' => 'Fastening', "designType" => "pant", 'class' => "icon-v2-Main_Icon8", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $fastenings);


        $sqlpantpocket = "SELECT * FROM pantsidepocket WHERE status='1'";
        $pocket_collection = $r_connection->fetchAll($sqlpantpocket);

        $pockets = array();

        foreach ($pocket_collection as $pocket) {
            $id = $pocket['pantsidepocket_id'];
            $name = $pocket['title'];
            $class = $pocket['class'];
            $thumb = $pocket['thumb'];
            $price = $pocket['price'];
            $main_img = $pocket['main_image'];
            $folded_img = $pocket['folded_main_image'];
            $status = $pocket['status'];

            if ($status) {
                $pockets[] = array('id' => $id, 'parent' => 'pantpockets', 'price' => 0, 'class' => $class, "designType" => "pant", 'name' => $name, "main_img" => $basePath . 'media/' . $main_img, "folded_img" => $basePath . 'media/' . $folded_img, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $pockets_data = array('id' => 4, 'name' => 'Pockets', "designType" => "pant", 'class' => "icon-v2-Main_Icon10", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $pockets);

        $sqlpantcuff = "SELECT * FROM pantcuff WHERE status='1'";
        $cuff_collection = $r_connection->fetchAll($sqlpantcuff);

        $cuffs = array();

        foreach ($cuff_collection as $cuff) {
            $id = $cuff['pantcuff_id'];
            $name = $cuff['title'];
            $class = $cuff['class'];
            $price = $cuff['price'];
            $thumb = $cuff['thumb'];
            $status = $cuff['status'];

            if ($status) {
                $cuffs[] = array('id' => $id, 'parent' => 'pantcuff', 'price' => $price, 'class' => $class, "designType" => "pant", 'name' => $name, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $cuffs_data = array('id' => 5, 'name' => 'Cuffs', "designType" => "pant", 'class' => "icon-v2-Main_Icon9", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $cuffs);



        $design_data = array($fits_data, $pleates_data, $fastening_data, $pockets_data, $cuffs_data);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($design_data));
    }

    public function getSuitVestAction() {
        $basePath = $this->getBasePath();
        $r_connection = $this->getReadConnection();

        $lapels = array();
        $styles = array();

        $sqlveststyprc = "SELECT * FROM veststyle WHERE status='1'";
        $style_data = $r_connection->fetchAll($sqlveststyprc);

        $i = 1;

        foreach ($style_data as $sd) {
            $styles[] = array(
                'id' => $i,
                'name' => $sd['title'],
                'price' => $sd['price'],
                "parent" => "veststyle",
                'class' => $sd['class'],
                "designType" => "vest",
                "img" => '');
            $i++;
        }

        $sqlvestlapel = "SELECT * FROM vestlapels WHERE status='1' Group BY lapel";
        $lapel_data = $r_connection->fetchAll($sqlvestlapel);


        $j = 1;
        foreach ($lapel_data as $lapel) {
            $lapels[] = array(
                'id' => $j,
                'name' => $lapel['title'],
                "parent" => "vestlapel",
                'class' => $lapel['class'],
                'price' => $lapel['price'],
                "designType" => "vest",
                "img" => '');
            $j++;
        }

        $style_data = array('id' => 1, 'name' => 'Style', 'class' => "icon-v2-Main_style_icon", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $styles);
        $lapels_data = array('id' => 2, 'name' => 'Lapel', 'class' => "icon-v2-Main_Icon12", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $lapels);

        $sqlvestedge = "SELECT * FROM vestedge WHERE status='1'";
        $edge_collection = $r_connection->fetchAll($sqlvestedge);


        $edges = array();

        foreach ($edge_collection as $edge) {
            $id = $edge['vestedge_id'];
            $name = $edge['title'];
            $class = $edge['class'];
            $thumb = $edge['thumb'];
            $price = $edge['price'];
            $status = $edge['status'];

            if ($status) {
                $edges[] = array('id' => $id, 'name' => $name, 'price' => $price, "parent" => "vestedge", 'class' => $class, "designType" => "vest", "img" => $basePath . 'media/' . $thumb);
            }
        }

        $edges_data = array('id' => 3, 'name' => 'Edge', 'class' => "icon-v2-Main_Icon11", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $edges);

        $sqlvestpocket = "SELECT * FROM vestpocket WHERE status='1'";
        $pocket_collection = $r_connection->fetchAll($sqlvestpocket);

        $pockets = array();

        foreach ($pocket_collection as $pocket) {
            $id = $pocket['vestpocket_id'];
            $name = $pocket['title'];
            $class = $pocket['class'];
            $thumb = $pocket['thumb'];
            $price = $pocket['price'];
            $status = $pocket['status'];

            if ($status) {
                $pockets[] = array('id' => $id, 'name' => $name, 'price' => $price, "parent" => "vestpockets", 'class' => $class, "designType" => "vest", "img" => $basePath . 'media/' . $thumb);
            }
        }

        $pockets_data = array('id' => 4, 'name' => 'Pockets', 'class' => "icon-v2-Main_Icon13", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $pockets);

        $sqlvestpocket = "SELECT * FROM vestbreastpocket WHERE status='1'";
        $breastpocket_collection = $r_connection->fetchAll($sqlvestpocket);

        $k = 1;
        foreach ($breastpocket_collection as $bpc) {
            $breast_pockets[] = array(
                'id' => $k,
                'name' => $bpc['title'],
                'price' => $bpc['price'],
                'class' => $bpc['class'],
                "parent" => "breastpocket",
                "designType" => "vest",
                "img" => '');
            $k++;
        }




        $breast_pockets_data = array('id' => 5, 'name' => 'Breast Pockets', 'class' => 'icon-v2-Breast_Pocket_Main_Icon', "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $breast_pockets);

        $sqlvestbutton = "SELECT * FROM vestbuttons WHERE status='1'";
        $vestbuttons_collection = $r_connection->fetchAll($sqlvestbutton);

        $vestbuttons = array();

        foreach ($vestbuttons_collection as $vestbutton) {
            $id = $vestbutton['vestbuttons_id'];
            $type = $vestbutton['type'];
            $class = $vestbutton['class'];
            $name = $vestbutton['title'] . ' Button';
            $thumb = $vestbutton['thumb'];
            $price = $vestbutton['price'];
            $btn_count = $vestbutton['btn_count'];
            $status = $vestbutton['status'];

            if ($status) {
                $vestbuttons[] = array('id' => $id, 'style_id' => $type, 'class' => $class, 'name' => $name, 'price' => $price, 'parent' => 'vestbuttons', "designType" => "vest", 'btn_count' => $btn_count, "img" => $basePath . 'media/' . $thumb);
            }
        }

        $vestbuttons_data = array('id' => 7, 'name' => 'vestbuttons', "designType" => "vest", 'class' => "icon-v2-Main_Icons", "img" => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $vestbuttons);

        $design_data = array($style_data, $edges_data, $lapels_data, $pockets_data, $breast_pockets_data, $vestbuttons_data);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($design_data));
    }

    public function shirtAction() {
        $this->loadLayout();
        $this->getLayout()->getBlock("head")->setTitle($this->__("Men Shirt Tool"));
        $this->renderLayout();
    }

//    Get Shirt Accent Data
    public function getShirtAccentAction() {
        $readConnection = $this->getReadConnection();
        $basePath = $this->getBasePath();
        $monogram_data = array('id' => 1, 'name' => 'Add Monogram', 'class' => 'icon-Add_Monogram', 'price' => '20', 'designType' => 'shirt', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Style_Main_Icon.png');

// collar style
        $sqlCollarStyle = "SELECT * FROM shirt_accent_collarstyle WHERE status='1' ORDER BY collarstyle_id ASC";
        $collarstyle_collection = $readConnection->fetchAll($sqlCollarStyle);

        $collarstyleArr = array();
        foreach ($collarstyle_collection as $collarstyle) {

            $id = $collarstyle['collarstyle_id'];
            $title = $collarstyle['title'];
            $class = $collarstyle['class'];
            $price = $collarstyle['price'];
            $status = $collarstyle['status'];

            if ($status) {
                $collarstyleArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'CollarStyle',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => ''
                );
            }
        }

        $collarstyle_data = array('id' => 2, 'name' => 'Collar Style', 'designType' => 'shirt', 'class' => 'icon-Collar_Contrast_Main_Icon', 'img' => $basePath . 'images/Collar/all.svg', "style" => $collarstyleArr);

// cuff
        $sqlCuff = "SELECT * FROM shirt_accent_cuffs WHERE status='1' ORDER BY cuff_id ASC";
        $cuff_collection = $readConnection->fetchAll($sqlCuff);

        $cuffsArr = array();
        foreach ($cuff_collection as $cuff) {

            $id = $cuff['cuff_id'];
            $title = $cuff['title'];
            $class = $cuff['class'];
            $price = $cuff['price'];
            $status = $cuff['status'];

            if ($status) {
                $cuffsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Cuffs',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => ''
                );
            }
        }

        $cuff_data = array('id' => 3, 'name' => 'Cuffs', 'designType' => 'shirt', 'class' => 'icon-Cuff_Contrast_Main_Icon', 'price' => '10', 'img' => $basePath . 'images/Cuffs/all.png', "style" => $cuffsArr);

// threads

        $sqlThreads = "SELECT * FROM shirt_shirtthreadfabric WHERE status='1' ORDER BY fabric_id ASC";
        $threads_collection = $readConnection->fetchAll($sqlThreads);

        $threadsArr = array();
        foreach ($threads_collection as $threads) {

            $id = $threads['fabric_id'];
            $title = $threads['title'];
            $class = $threads['class'];
            $price = $threads['price'];
            $thumb = $threads['display_fabric_thumb'];
            $status = $threads['status'];

            if ($status) {
                $threadsColorArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Threads',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $sqlThreads = "SELECT * FROM shirt_accent_threads WHERE status='1' ORDER BY threads_id ASC";
        $threads_collection = $readConnection->fetchAll($sqlThreads);

        $threadsArr = array();
        foreach ($threads_collection as $threads) {

            $id = $threads['threads_id'];
            $title = $threads['title'];
            $class = $threads['class'];
            $price = $threads['price'];
            $status = $threads['status'];

            if ($status) {
                $threadsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Threads',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb,
                );
            }
        }




        $threads_data = array('id' => 4, 'name' => 'Threads', 'designType' => 'shirt', 'class' => 'icon-Thread_Main_Icon', 'price' => '10', "style" => $threadsArr);


// elbowpatches
        $sqlElbowpatches = "SELECT * FROM shirt_accent_elbowpatches WHERE status='1' ORDER BY elbowpatches_id ASC";
        $elbowpatches_collection = $readConnection->fetchAll($sqlElbowpatches);

        $elbowpatchesArr = array();
        foreach ($elbowpatches_collection as $elbowpatches) {

            $id = $elbowpatches['elbowpatches_id'];
            $title = $elbowpatches['title'];
            $class = $elbowpatches['class'];
            $price = $elbowpatches['price'];
            $thumb = null;
            $status = $elbowpatches['status'];

            if ($status) {
                $elbowpatchesArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'ElbowPatch',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $elbowpatches_data = array('id' => 5, 'name' => 'Elbow Patch', 'designType' => 'shirt', 'class' => 'icon-Main_Icon2', 'price' => '10', 'img' => $basePath . 'media/jacket_img/thumbnail/00_Elbowpatch_Main_Icon.png', "style" => $elbowpatchesArr);

// chest pleats
        $sqlChestpleats = "SELECT * FROM shirt_accent_chestpleats WHERE status='1' ORDER BY chestpleats_id ASC";
        $chestpleats_collection = $readConnection->fetchAll($sqlChestpleats);

        $chestpleatsArr = array();
        foreach ($chestpleats_collection as $chestpleats) {

            $id = $chestpleats['chestpleats_id'];
            $title = $chestpleats['title'];
            $class = $chestpleats['class'];
            $price = $chestpleats['price'];
            $status = $chestpleats['status'];

            if ($status) {
                $chestpleatsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Chest pleats',
                    'designType' => 'shirt',
                    'designRel' => 'lining',
                    'name' => $title,
                    'price' => $price,
                    'img' => ''
                );
            }
        }

        $chestpleats_data = array('id' => 6, 'name' => 'Chest Pleats', 'designType' => 'shirt', 'class' => 'icon-Main_Icon', 'price' => '10', 'img' => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $chestpleatsArr);

// front placket
        $sqlPlacket = "SELECT * FROM shirt_accent_placket WHERE status='1' ORDER BY placket_id ASC";
        $placket_collection = $readConnection->fetchAll($sqlPlacket);

        $placketsArr = array();
        foreach ($placket_collection as $placket) {

            $id = $placket['placket_id'];
            $title = $placket['title'];
            $class = $placket['class'];
            $price = $placket['price'];
            $status = $placket['status'];

            if ($status) {
                $placketsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Front Placket',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price
                );
            }
        }

        $placket_data = array('id' => 7, 'name' => 'Front Placket', 'designType' => 'shirt', 'class' => 'icon-Front_Placket_Contrast_Main_Icon', 'price' => '10', 'img' => $basePath . 'images/Plackets/all.png', "style" => $placketsArr);
        $button_threads_data = array('id' => 8, 'name' => 'Button Threads', 'designType' => 'shirt', 'class' => 'icon-Thread_Main_Icon', 'price' => '10', "style" => $threadsColorArr);
        $shirtAccentInfo = array($monogram_data, $collarstyle_data, $cuff_data, $threads_data, $elbowpatches_data, $chestpleats_data, $placket_data, $button_threads_data);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($shirtAccentInfo));
    }

//    Get Shirt Button Fabric
    public function getShirtButtonFabricAction() {
        $readConnection = $this->getReadConnection();
        $basePath = $this->getBasePath();

        $sql = " SELECT * FROM shirt_button_fabric ";
        $rows = $readConnection->fetchAll($sql);
        $fabrics = array();
        foreach ($rows as $fabric) {
            $id = $fabric['button_fabric_id'];
            $name = $fabric['title'];
            $thumb = $fabric['fabric_thumb'];
            $real_img = $fabric['fabric_real_image'];
            $shirt_type_name = "Cotton";
            $fabrics[] = array('id' => $id, 'price' => '1', 'name' => $name, 'real_img' => $basePath . 'media/' . $real_img, 'img' => $basePath . 'media/' . $thumb);
        }

//        echo json_encode($fabrics, true);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fabrics));
    }

//    Get Shirt Design
    public function getShirtDesignAction() {
        $readConnection = $this->getReadConnection();
        $basePath = $this->getBasePath();

        $sqlCollarStyle = " SELECT * FROM shirtstyle WHERE status='1' ORDER BY shirtstyle_id ASC "; //AND gender='1'
        $collarstyle_collection = $readConnection->fetchAll($sqlCollarStyle);

        $collarstylesArr = array();
        foreach ($collarstyle_collection as $collarstyle) {

            $id = $collarstyle['shirtstyle_id'];
            $title = $collarstyle['title'];
            $class = $collarstyle['class'];
            $price = $collarstyle['price'];
            $thumb = $collarstyle['thumb'];
            $status = $collarstyle['status'];

            if ($status) {
                $collarstylesArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Collar Style',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $collarstyle_data = array('id' => 1, 'name' => 'Collar Style', 'designType' => 'shirt', 'class' => 'icon-Collar_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Style_Main_Icon.png', "style" => $collarstylesArr);

// cuff
        $sqlCuff = "SELECT * FROM shirtcuff WHERE status='1' ORDER BY shirtcuff_id ASC"; //AND gender='1'
        $cuff_collection = $readConnection->fetchAll($sqlCuff);

        $cuffsArr = array();
        foreach ($cuff_collection as $cuff) {

            $id = $cuff['shirtcuff_id'];
            $title = $cuff['title'];
            $class = $cuff['class'];
            $price = $cuff['price'];
            $thumb = null;
            $status = $cuff['status'];

            if ($status) {
                $cuffsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Cuffs',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $cuff_data = array('id' => 2, 'name' => 'Cuffs', 'designType' => 'shirt', 'class' => 'icon-Cuff_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Cuffs_Main_Icon.png', "style" => $cuffsArr);

// sleeves
        $sqlSleeves = "SELECT * FROM shirtsleeves WHERE status='1' ORDER BY shirtsleeves_id ASC"; //AND gender='1'
        $sleeves_collection = $readConnection->fetchAll($sqlSleeves);

        $sleevesArr = array();
        foreach ($sleeves_collection as $sleeves) {

            $id = $sleeves['shirtsleeves_id'];
            $title = $sleeves['title'];
            $class = $sleeves['class'];
            $price = $sleeves['price'];
            $thumb = null;
            $status = $sleeves['status'];

            if ($status) {
                $sleevesArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Sleeves',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $sleeves_data = array('id' => 3, 'name' => 'Sleeves', 'designType' => 'shirt', 'class' => 'icon-Sleeve_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Fit_Main_Icon.png', "style" => $sleevesArr);

// fit
        $sqlFit = "SELECT * FROM shirtfit WHERE status='1'  ORDER BY shirtfit_id ASC"; //AND gender='1'
        $fit_collection = $readConnection->fetchAll($sqlFit);

        $fitsArr = array();
        foreach ($fit_collection as $fit) {

            $id = $fit['shirtfit_id'];
            $title = $fit['title'];
            $class = $fit['class'];
            $price = $fit['price'];
            $thumb = null;
            $status = $fit['status'];

            if ($status) {
                $fitsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Fit',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $fit_data = array('id' => 4, 'name' => 'Fit', 'designType' => 'shirt', 'class' => 'icon-Fit_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Fit_Main_Icon.png', "style" => $fitsArr);

// pocket
        $sqlPocket = "SELECT * FROM shirtpocket WHERE status='1' ORDER BY shirtpocket_id ASC"; //AND gender='1'
        $pocket_collection = $readConnection->fetchAll($sqlPocket);

        $pocketsArr = array();
        foreach ($pocket_collection as $pocket) {

            $id = $pocket['shirtpocket_id'];
            $title = $pocket['title'];
            $class = $pocket['class'];
            $price = $pocket['price'];
            $thumb = $pocket['thumb'];
            $status = $pocket['status'];

            if ($status) {
                $pocketsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Pocket',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $pocket_data = array('id' => 5, 'name' => 'Pocket', 'designType' => 'shirt', 'class' => 'icon-Withoutflap_Pocket_Right', 'img' => $basePath . 'media/shirt_images/thumbnail/00Pocket_Main_Icon.png', "style" => $pocketsArr);

// plackets
        $sqlPlackets = "SELECT * FROM shirtplackets WHERE status='1' ORDER BY shirtplackets_id ASC"; //AND gender='1'
        $plackets_collection = $readConnection->fetchAll($sqlPlackets);

        $placketsArr = array();
        foreach ($plackets_collection as $plackets) {

            $id = $plackets['shirtplackets_id'];
            $title = $plackets['title'];
            $class = $plackets['class'];
            $price = $plackets['price'];
            $thumb = $plackets['thumb'];
            $status = $plackets['status'];

            if ($status) {
                $placketsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Plackets',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $plackets_data = array('id' => 6, 'name' => 'Plackets', 'designType' => 'shirt', 'class' => 'icon-Placket_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Plackets_Main_Icon.png', "style" => $placketsArr);

// pleats
        $sqlPleats = "SELECT * FROM shirtpleats WHERE status='1' ORDER BY shirtpleats_id ASC"; //AND gender='1'
        $pleats_collection = $readConnection->fetchAll($sqlPleats);

        $pleatsArr = array();
        foreach ($pleats_collection as $pleats) {

            $id = $pleats['shirtpleats_id'];
            $title = $pleats['title'];
            $class = $pleats['class'];
            $price = $pleats['price'];
            $image = $pleats['image'];
            $status = $pleats['status'];

            if ($status) {
                $pleatsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Pleats',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $image
                );
            }
        }

        $pleats_data = array('id' => 7, 'name' => 'Pleats', 'designType' => 'shirt', 'class' => 'icon-Pleats_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Pleats_Main_Icon.png', "style" => $pleatsArr);

// bottom
        $sqlBottom = "SELECT * FROM shirtbottom WHERE status='1' ORDER BY shirtbottom_id ASC"; //AND gender='1'
        $bottom_collection = $readConnection->fetchAll($sqlBottom);

        $bottomsArr = array();
        foreach ($bottom_collection as $bottom) {

            $id = $bottom['shirtbottom_id'];
            $title = $bottom['title'];
            $class = $bottom['class'];
            $price = $bottom['price'];
            $view1_image = $bottom['view1_image'];
            $view2_image = $bottom['view2_image'];
            $view3_image = $bottom['view3_image'];
            $status = $bottom['status'];

            if ($status) {
                $bottomsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Bottom',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'view1_image' => $basePath . 'media/' . $view1_image,
                    'view2_image' => $basePath . 'media/' . $view2_image,
                    'view3_image' => $basePath . 'media/' . $view3_image,
                );
            }
        }

        $bottom_data = array('id' => 8, 'name' => 'Bottom', 'designType' => 'shirt', 'class' => 'icon-Bottom_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Bottom_Main_Icon.png', "style" => $bottomsArr);

        $shirtDesignInfo = array($collarstyle_data, $cuff_data, $sleeves_data, $fit_data, $pocket_data, $plackets_data, $pleats_data, $bottom_data);
//        echo json_encode($shirtDesignInfo, true);
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($shirtDesignInfo));
    }

    //    Get Shirt Fabrics
    public function getShirtFabricsAction() {
        $readConnection = $this->getReadConnection();
        $basePath = $this->getBasePath();

        $sqlmaterial = "SELECT * FROM fabric_season WHERE status='1'";
        $material_collection = $readConnection->fetchAll($sqlmaterial);
        $materials = array();
        foreach ($material_collection as $material) {
            $id = $material['season_id'];
            $name = $material['title'];
            $status = $material['status'];
            if ($status) {
                $materials[] = array('id' => $id, 'name' => $name, 'parent' => 'material');
            }
        }
        $sqlpattern = "SELECT * FROM fabric_pattern WHERE status='1'";
        $pattern_collection = $readConnection->fetchAll($sqlpattern);
        $patterns = array();
        foreach ($pattern_collection as $pattern) {
            $id = $pattern['pattern_id'];
            $name = $pattern['title'];
            if ($status) {
                $patterns[] = array('id' => $id, 'name' => $name, 'parent' => 'pattern');
            }
        }
        $sqlseason = "SELECT * FROM fabric_material WHERE status='1'";
        $season_collection = $readConnection->fetchAll($sqlseason);
        $seasons = array();
        foreach ($season_collection as $season) {
            $id = $season['material_id'];
            $name = $season['title'];
            if ($status) {
                $seasons[] = array('id' => $id, 'name' => $name, 'parent' => 'seasons');
            }
        }
        $sqlcolor = "SELECT * FROM fabric_color WHERE status='1'";
        $color_collection = $readConnection->fetchAll($sqlcolor);
        $colors = array();
        foreach ($color_collection as $color) {
            $id = $color['color_id'];
            $name = $color['title'];
            if ($status) {
                $colors[] = array('id' => $id, 'name' => $name, 'parent' => 'color');
            }
        }
        $sqlcategory = "SELECT * FROM fabric_category WHERE status='1'";
        $category_collection = $readConnection->fetchAll($sqlcategory);
        $categorys = array();
        foreach ($category_collection as $category) {
            $id = $category['category_id'];
            $name = $category['title'];
            $class = $category['class'];
            if ($status) {
                $categorys[] = array('id' => $id, 'name' => $name, 'parent' => 'category', "class" => $class);
            }
        }

        $categories = array($materials, $patterns, $seasons, $colors, $categorys);

        $sqlfab = "SELECT * FROM shirt_shirtfabric WHERE status='1' ORDER BY title ASC";
        $fabrics_collection = $readConnection->fetchAll($sqlfab);

        $fabrics = array();


        foreach ($fabrics_collection as $fabric) {
            //            print_r($fabric);die;
            $id = $fabric['fabric_id'];
            $name = $fabric['title'];
            $thumb = $fabric['display_fabric_thumb'];
            $price = $fabric['price'];
            $real_img = $fabric['fabric_large_image'];
            $shirt_type_name = "Cotton";
            $status = $fabric['status'];


            $shirt_material_id = $fabric['fabric_material_id'];
            $sqlmaterial = "SELECT * FROM fabric_material WHERE status='1' AND material_id='" . $shirt_material_id . "'";
            $material_collection = $readConnection->fetchAll($sqlmaterial);


            $shirt_pattern_id = $fabric['fabric_pattern_id'];
            $sqlpattern = "SELECT * FROM fabric_pattern WHERE status='1' AND pattern_id='" . $shirt_pattern_id . "' ";
            $pattern_collection = $readConnection->fetchAll($sqlpattern);

            $shirt_season_id = $fabric['fabric_season_id'];
            $sqlseason = "SELECT * FROM fabric_season WHERE status='1' AND season_id='" . $shirt_season_id . "'";

            $shirt_color_id = $fabric['fabric_color_id'];
            $sqlcolor = "SELECT * FROM fabric_color WHERE status='1' AND color_id='" . $shirt_color_id . "'";
            $color_collection = $readConnection->fetchAll($sqlcolor);

            $shirt_category_id = $fabric['fabric_category_id'];
            $sqlcategory = "SELECT * FROM fabric_category WHERE status='1' AND category_id='" . $shirt_category_id . "'";
            $category_collection = $readConnection->fetchAll($sqlcategory);

            if ($status) {
                $shirt_fab_type_name = $material_collection[0]['title'];
                $fabrics[] = array('id' => $id,
                    'name' => $name,
                    'fabric_thumb' => $basePath . 'media/' . $thumb,
                    'real_img' => $basePath . 'media/' . $real_img,
                    'price' => $price,
                    'material_parent' => $material_collection[0]['title'],
                    'pattern_parent' => $pattern_collection[0]['title'],
                    'season_parent' => $season_collection[0]['title'],
                    'color_parent' => $color_collection[0]['title'],
                    'category_parent' => $category_collection[0]['title']
                );
            }
        }

        $fabricInfo = array('fabric' => $fabrics, 'category' => $categories);
        //        echo json_encode($fabricInfo, true);

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fabricInfo));
    }

//    Save Shirt Design

    public function saveShirtDesignAction() {
        $readConnection = $this->getReadConnection();
        $writeConnection = $this->getWriteConnection();
        $basePath = $this->getBasePath();
        $homepath = $this->getBaseDir();
        $product_Id = 1;

        $jsonname = $this->getRequest()->getParam('style_data'); //$_POST['style_data'];
        $sizedata = $this->getRequest()->getParam('size_Data_Arr'); //$_POST['size_Data_Arr'];
        $categoryId = $this->getRequest()->getParam('category_id');

        if (isset($categoryId)) {
            $product_id = $this->getRequest()->getParam('category_id'); //$_POST['category_id'];
        }

        $fabric_id = $this->getRequest()->getParam('fabricId'); //$_POST['fabricId'];
        $price = $this->getRequest()->getParam('price'); //$_POST['price'];
        $gender = $this->getRequest()->getParam('gender'); //$_POST['gender'];
        $size = $this->getRequest()->getParam('qty'); //$_POST['qty'];
        $price = $this->getRequest()->getParam('price'); //$_POST['price'];

        $jsonname = json_encode($jsonname, JSON_UNESCAPED_SLASHES);
        $sizedata = json_encode($sizedata, JSON_UNESCAPED_SLASHES);

        /* print_r($sizedata);
          die(); */

        $fname = "Swapnil Mulay";
        $email = "swapnilmulay.1104@gmail.com";

        if ($user_id == '') {
            $user_id = 2;
        }

        $name = 'shirtdesign_' . time();

        $image = str_replace('data:image/png;base64,', '', $this->getRequest()->getParam('prodImg'));
        $fp = fopen($homepath . "media/tool_data/img/customize-image/" . $name . ".png", "w+");
        fwrite($fp, base64_decode($image));
        fclose($fp);

        $product_image = "media/tool_data/img/customize-image/" . $name . ".png";

//        $wpdb->insert(
//                'user_designs', // table
//                array('product_id' => $product_Id, 'user_id' => $user_id, 'user_name' => $fname, 'user_email' => $email,
//                    'customize_image' => $product_image, 'json_data' => $jsonname, 'json_data_sizes' => $sizedata, 'product_type' => 'shirt'), // data
//                array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s') //data format			
//        );

        $sql = "INSERT INTO user_designs ("
                . "product_id,user_id,user_name,user_email,customize_image"
                . ",json_data,json_data_sizes,product_type) VALUES('" . $product_Id . "','" . $user_id . "','" . $fname . "','" . $email
                . "','" . $product_image . "','" . $jsonname . "','" . $sizedata . "','shirt')";
        $writeConnection->query($sql);
        $this->getResponse()->setBody($writeConnection->lastInsertId());
    }

}
