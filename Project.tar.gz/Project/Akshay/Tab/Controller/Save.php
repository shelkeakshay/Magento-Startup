<?php

namespace Akshay\Tab\Controller;

class Save extends \Magento\Catalog\Controller\Adminhtml\Product\Save {
    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
}
