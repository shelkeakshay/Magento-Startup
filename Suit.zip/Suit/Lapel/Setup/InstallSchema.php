<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Lapel\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {


        $installer = $setup;
        $installer->startSetup();

        /**
         * Create table 'suit_lapel'
         */
        $table = $installer->getConnection()->newTable($installer->getTable('suit_lapel'))
            ->addColumn(
                'suit_lapel_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Lapel ID'
            )
            ->addColumn(
                'title',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => true, 'default' => null],
                'Title'
            )

            ->addColumn(
                'class',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 
                255, 
                ['nullable' => true, 'default' => null], 
                'Class'
            )


            ->addColumn(
                'suit_upperrightmask',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'Upper Right Mask Image'
            )
            ->addColumn(
                'main_image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'Main Image'
            )
            ->addColumn(
                'objimage',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'Object File'
            )->addColumn(
                'mlt_image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'MLT File'
            )
            ->addColumn(
                'status', 
                \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                null,
                ['nullable' => false, 'unsigned' => true, 'default' => '1'], 
                'Date'
            )
            ->addColumn(
                'created_time',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
                'Creation Time'
            )
            ->addColumn(
                'update_time',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP, 
                null,
                ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE], 
                'Update Time'
        );

        $installer->getConnection()->createTable($table);

        
        $installer->endSetup();
    }

}
