<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace PartFinder\Extension\Observer;

/**
 * Description of Productsaveafter
 *
 * @author magento
 */
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;

class Productsaveafter implements ObserverInterface {

    private $_customerRepository;
    protected $_uploaderFactory;
    protected $_fileSystem;
    protected $_messageManager;
    protected $_fileId = 'product_pdf';
    protected $_allowedExtensions = ['pdf', 'PDF'];

    public function __construct(
    \Magento\Framework\Message\ManagerInterface $messageManager, \Magento\Framework\App\RequestInterface $request, CustomerRepositoryInterface $customerRepository, UploaderFactory $uploaderFactory, Filesystem $fileSystem
    ) {
        $this->_request = $request;
        $this->_messageManager = $messageManager;
        $this->_customerRepository = $customerRepository;
        $this->_uploaderFactory = $uploaderFactory;
        $this->_fileSystem = $fileSystem;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        
        $_product = $observer->getProduct();  // you will get product object
        $_sku = $_product->getSku(); // for sku
        try {
            $destinationPath = $this->_fileSystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath() . "catalog/product/pdf/";

            $uploader = $this->_uploaderFactory->create(['fileId' => $this->_fileId])
                    ->setAllowCreateFolders(true)
                    ->setAllowRenameFiles(true)
                    ->setAllowedExtensions($this->_allowedExtensions);

            if (!$fileData = $uploader->save($destinationPath)) {
                throw new LocalizedException(
                __('File cannot be saved to path: $1', $destinationPath)
                );
            }
            $fileName = "catalog/product/pdf/" . $fileData['file'];
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('custom_tab');
            //Delete Data from table
            $sql = "Delete FROM " . $tableName . " Where id =" . $_product->getId();
            $connection->query($sql);
            //Insert Data into table
            $sql = "Insert Into " . $tableName . " (id, tab_value ) Values (" . $_product->getId() . ",'" . $fileName . "')";
            $connection->query($sql);
        } catch (\Exception $e) {
            $this->_messageManager->addError(
                    __("Fail to upload product document. Please check the allowed extension(pdf).")
            );
        }
    }

}
