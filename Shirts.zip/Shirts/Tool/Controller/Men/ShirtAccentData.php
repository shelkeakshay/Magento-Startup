<?php

namespace Shirts\Tool\Controller\Men;

use Magento\Framework\Controller\ResultFactory;

class ShirtAccentData extends \Magento\Framework\App\Action\Action
{

  public function __construct(
		\Magento\Backend\App\Action\Context $context,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
		parent::__construct($context);
		$this->resultJsonFactory = $resultJsonFactory;
	}

  public function DBConnect(){
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
    	$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
    	return $resource->getConnection();
  }

  public function basePath(){
  	$om = \Magento\Framework\App\ObjectManager::getInstance();
  	$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
  	$currentStore = $storeManager->getStore();
  	return $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
  }

  public function execute()
  {

    $monogram_data = array('id' => 1, 'name' => 'Add Monogram', 'class' => 'icon-Add_Monogram', 'price' => '20', 'designType' => 'shirt', 'img' => $this->basePath() . 'shirt_images/thumbnail/00_Style_Main_Icon.png');

    // collar style
    $sqlCollarStyle = "SELECT * FROM shirt_accent_collarstyle WHERE status='1' ORDER BY collarstyle_id ASC";
    $collarstyle_collection = $this->DBConnect()->fetchAll($sqlCollarStyle);

    $collarstyleArr = array();
    foreach ($collarstyle_collection as $collarstyle) {

        $id = $collarstyle['collarstyle_id'];
        $title = $collarstyle['title'];
        $class = $collarstyle['class'];
        $price = $collarstyle['price'];
        $status = $collarstyle['status'];

        if ($status) {
            $collarstyleArr[] = array(
                'id' => $id,
                'class' => $class,
                'parent' => 'CollarStyle',
                'designType' => 'shirt',
                'name' => $title,
                'price' => $price,
                'img' => ''
            );
        }
    }

    $collarstyle_data = array('id' => 2, 'name' => 'Collar Style', 'designType' => 'shirt', 'class' => 'icon-Collar_Contrast_Main_Icon', 'img' => $this->basePath() . '', "style" => $collarstyleArr);

// cuff
    $sqlCuff = "SELECT * FROM shirt_accent_cuffs WHERE status='1' ORDER BY cuff_id ASC";
    $cuff_collection = $this->DBConnect()->fetchAll($sqlCuff);

    $cuffsArr = array();
    foreach ($cuff_collection as $cuff) {

        $id = $cuff['cuff_id'];
        $title = $cuff['title'];
        $class = $cuff['class'];
        $price = $cuff['price'];
        $status = $cuff['status'];

        if ($status) {
            $cuffsArr[] = array(
                'id' => $id,
                'class' => $class,
                'parent' => 'Cuffs',
                'designType' => 'shirt',
                'name' => $title,
                'price' => $price,
                'img' => ''
            );
        }
    }

    $cuff_data = array('id' => 3, 'name' => 'Cuffs', 'designType' => 'shirt', 'class' => 'icon-Cuff_Contrast_Main_Icon', 'price' => '10', 'img' => $this->basePath() . '', "style" => $cuffsArr);

// threads
    $sqlThreads = "SELECT * FROM shirt_accent_threads WHERE status='1' ORDER BY threads_id ASC";
    $threads_collection = $this->DBConnect()->fetchAll($sqlThreads);

    $threadsArr = array();
    foreach ($threads_collection as $threads) {

        $id = $threads['threads_id'];
        $title = $threads['title'];
        $class = $threads['class'];
        $price = $threads['price'];
        $thumb = null;
        $status = $threads['status'];

        if ($status) {
            $threadsArr[] = array(
                'id' => $id,
                'class' => $class,
                'parent' => 'Threads',
                'designType' => 'shirt',
                'name' => $title,
                'price' => $price,
                'img' => $this->basePath() . '' . $thumb
            );
        }
    }

    $threads_data = array('id' => 4, 'name' => 'Threads', 'designType' => 'shirt', 'class' => 'icon-Thread_Main_Icon', 'price' => '10', 'img' => $this->basePath() . '', "style" => $threadsArr);

// elbowpatches
    $sqlElbowpatches = "SELECT * FROM shirt_accent_elbowpatches WHERE status='1' ORDER BY elbowpatches_id ASC";


    $elbowpatches_collection = $this->DBConnect()->fetchAll($sqlElbowpatches);

    $elbowpatchesArr = array();
    foreach ($elbowpatches_collection as $elbowpatches) {
        echo '<pre>';
        print_r($elbowpatches); die;
        $id = $elbowpatches['elbowpatches_id'];
        $title = $elbowpatches['title'];
        $class = $elbowpatches['class'];
        $price = $elbowpatches['price'];
        $thumb = null;
        $status = $elbowpatches['status'];

        if ($status) {
            $elbowpatchesArr[] = array(
                'id' => $id,
                'class' => $class,
                'parent' => 'ElbowPatch',
                'designType' => 'shirt',
                'name' => $title,
                'price' => $price,
                'img' => $this->basePath() . '' . $thumb
            );
        }
    }

    $elbowpatches_data = array('id' => 5, 'name' => 'Elbow Patch', 'designType' => 'shirt', 'class' => 'icon-Main_Icon2', 'price' => '10', 'img' => $this->basePath() . '', "style" => $elbowpatchesArr);

// chest pleats
    $sqlChestpleats = "SELECT * FROM shirt_accent_chestpleats WHERE status='1' ORDER BY chestpleats_id ASC";
    $chestpleats_collection = $this->DBConnect()->fetchAll($sqlChestpleats);

    $chestpleatsArr = array();
    foreach ($chestpleats_collection as $chestpleats) {

        $id = $chestpleats['chestpleats_id'];
        $title = $chestpleats['title'];
        $class = $chestpleats['class'];
        $price = $chestpleats['price'];
        $status = $chestpleats['status'];

        if ($status) {
            $chestpleatsArr[] = array(
                'id' => $id,
                'class' => $class,
                'parent' => 'Chest pleats',
                'designType' => 'shirt',
                'designRel' => 'lining',
                'name' => $title,
                'price' => $price,
                'img' => ''
            );
        }
    }

    $chestpleats_data = array('id' => 6, 'name' => 'Chest Pleats', 'designType' => 'shirt', 'class' => 'icon-Main_Icon', 'price' => '10', 'img' => $this->basePath() . '', "style" => $chestpleatsArr);

// front placket
    $sqlPlacket = "SELECT * FROM shirt_accent_placket WHERE status='1' ORDER BY placket_id ASC";
    $placket_collection = $this->DBConnect()->fetchAll($sqlPlacket);

    $placketsArr = array();
    foreach ($placket_collection as $placket) {

        $id = $placket['placket_id'];
        $title = $placket['title'];
        $class = $placket['class'];
        $price = $placket['price'];
        $status = $placket['status'];

        if ($status) {
            $placketsArr[] = array(
                'id' => $id,
                'class' => $class,
                'parent' => 'Front Placket',
                'designType' => 'shirt',
                'name' => $title,
                'price' => $price
            );
        }
    }

    $placket_data = array('id' => 7, 'name' => 'Front Placket', 'designType' => 'shirt', 'class' => 'icon-Front_Placket_Contrast_Main_Icon', 'price' => '10', 'img' => $this->basePath() . '', "style" => $placketsArr);

    $shirtAccentInfo = array($monogram_data, $collarstyle_data, $cuff_data, $threads_data, $elbowpatches_data, $chestpleats_data, $placket_data);

    return  $this->resultJsonFactory->create()->setData($shirtAccentInfo);

  }


}