  require(['jquery'],function(){
          jQuery(document).ready(function() {
              jQuery("#search_form").submit(function(){
                  event.preventDefault();

                    q = jQuery('#partsearch').val();
                    grouped_pid = jQuery("#grouped_product_id").val();
          
                    jQuery.ajax({
              
                          url : '/magento2.4/ajax/index/search/',
                          data: { 'q' :  q  , 'grouped_pid': grouped_pid},
                          type : 'GET',
                            beforeSend: function () {
                                jQuery('body').trigger('processStart');
                            },
                            success: function (res) {
                              alert('Search Complete');
                                jQuery('#search-filter-result').html('');
                                jQuery('#search-filter-result').append(res);
                                jQuery('body').trigger('processStop');
                            }
                    });

              });
          });
                
      });