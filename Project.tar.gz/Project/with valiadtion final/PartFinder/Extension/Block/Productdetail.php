<?php
namespace PartFinder\Extension\Block;
/**
    * Created By:Nisha Jadhav
    * Created On:13th June 2018
    * Purpose:Create block for grouped product
    */

use Magento\Catalog\Model\Product;
use Magento\GroupedProduct\Block\Product\View\Type\Grouped as MagentoGrouped;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Framework\Stdlib\ArrayUtils;
use Magento\Catalog\Model\ProductFactory;

Class Productdetail extends \Magento\Framework\View\Element\Template
{   
      
    public function __construct(
       
        ProductFactory $productFactory,
        Context $context,
        ArrayUtils $arrayUtils,
        array $data = [],
        \Magento\Framework\Registry $registry      
       )
    {
       
        $this->productFactory               = $productFactory;
        $this->registry     = $registry;
        parent::__construct($context, $data);
    }
    
    public function getProductById()
    {
        $productId = $this->registry->registry('custom');//custom regisrty which are created in controller have store id of product(grouped)
        $object= \Magento\Framework\App\ObjectManager::getInstance();
        return   $object->create('Magento\Catalog\Model\Product')->load($productId);
    }
}