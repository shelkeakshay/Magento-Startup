<?php

namespace Shirts\Tool\Controller\Men;

use Magento\Framework\Controller\ResultFactory;

class Akshay extends \Magento\Framework\App\Action\Action
{

  	public function __construct(
		\Magento\Backend\App\Action\Context $context,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
		parent::__construct($context);
		$this->resultJsonFactory = $resultJsonFactory;
	}

  	public function DBConnect(){
      	$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
    	$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
    	return $resource->getConnection();
  	}

  	public function basePath(){
	  	$om = \Magento\Framework\App\ObjectManager::getInstance();
	  	$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
	  	$currentStore = $storeManager->getStore();
	  	return $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
  	}

  	public function execute()
  	{

	    $monogram_data = array('id' => 1, 'name' => 'Add Monogram', 'class' => 'icon-Add_Monogram', 'price' => '20', 'designType' => 'shirt', 'img' => $this->basePath() . 'shirt_images/thumbnail/00_Style_Main_Icon.png');

	    // collar style
	    $sqlCollarStyle = "SELECT * FROM shirt_accent_collarstyle WHERE status='1' ORDER BY collarstyle_id ASC";
	    $collarstyle_collection = $this->DBConnect()->fetchAll($sqlCollarStyle);

	    $collarstyleArr = array();
	    foreach ($collarstyle_collection as $collarstyle) {

	        $id = $collarstyle['collarstyle_id'];
	        $title = $collarstyle['title'];
	        $class = $collarstyle['class'];
	        $price = $collarstyle['price'];
	        $status = $collarstyle['status'];

	        if ($status) {
	            $collarstyleArr[] = array(
	                'id' => $id,
	                'class' => $class,
	                'parent' => 'CollarStyle',
	                'designType' => 'shirt',
	                'name' => $title,
	                'price' => $price,
	                'img' => ''
	            );
	        }
	    }

	    $collarstyle_data = array('test' => 'akshay',
	    	'id' 		=> $id, 
	    	'name' 	=> $title, 
	    	'designType' => 'shirt', 
	    	'class' 	=> 'icon-Collar_Contrast_Main_Icon', 
	    	'img' 		=> $this->basePath() . '', 
	    	"style" 	=> $collarstyleArr
	    );

	    
	    $shirtAccentInfo = array($collarstyle_data);

	    return $this->resultJsonFactory->create()->setData($shirtAccentInfo);

  	}

}