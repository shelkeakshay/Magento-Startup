<?php
namespace Test\Ajax\Controller\Index;
use \Magento\Framework\View\Result\PageFactory;

class Cart extends \Magento\Framework\App\Action\Action
{ 
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Catalog\Model\Product $product,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\Data\Form\FormKey $formKey,
        PageFactory $pageFactory
        )
    {
       
        $this->_cart = $cart;
        $this->_product = $product;
        $this->formKey = $formKey;
        $this->resultPageFactory = $pageFactory;
        return parent::__construct($context);
    }

    public function execute()
    {
            try {
               
                $productIds = $this->getRequest()->getParam('id');
                $objectManager= \Magento\Framework\App\ObjectManager::getInstance();
                for($i = 0; $i < sizeof($productIds); $i++){
               
                $product = $objectManager->create('\Magento\Catalog\Model\Product')->load($productIds[$i]['checkbox']);

                     $params = array(
                              'form_key' => $this->formKey->getFormKey(),
                              'product' => $productIds[$i]['checkbox'], //product Id
                              'qty' => $productIds[$i]['qty']//quantity of product
                              
                        );
                
                        $this->_cart->addProduct($product, $params);
                        $this->_cart->save();
                   
                }
              
               $this->messageManager->addSuccess(__('Product has been successfully added to cart.'));
               $this->_redirect("../magento2.4/checkout/cart/index/", $params);


        }catch (\Magento\Framework\Exception\LocalizedException $e) {
          echo $e; 
            $this->messageManager->addException($e, __('%1', $e->getMessage()));
        } catch (\Exception $e) {
            $this->messageManager->addException($e);
        }
    }
 
}
