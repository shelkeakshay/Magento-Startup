<?php
namespace PartFinder\Extension\Controller\Index;
/**
    * Created By:Nisha Jadhav
    * Created On:26 th June 2018
    * Purpose:Add Product into Cart
*/
  
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;

class Cart extends Action
{
    protected $_resultPageFactory;
    protected $_storeManager;
    protected $productRepository;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;
    protected $_productloader;
    protected $cartRepository;
    protected $quoteManagement;
    protected $_customerSession;
    protected $quoteFactory;
    public function __construct(Context $context,
                                \Magento\Store\Model\StoreManagerInterface $storeManager,
                                \Magento\Catalog\Model\ProductRepository $productRepository,
                                \Magento\Checkout\Model\Session $checkoutSession,
                                \Magento\Checkout\Model\Cart $cart,
                                PageFactory $resultPageFactory,
                                \Magento\Catalog\Model\ProductFactory $_productloader,
                                \Magento\Quote\Api\CartRepositoryInterface $cartRepository,
                                \Magento\Quote\Api\CartManagementInterface $quoteManagement,
                                \Magento\Customer\Model\Session $customerSession,
                                \Magento\Customer\Model\CustomerFactory $customerFactory,
                                \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
                                \Magento\Quote\Model\QuoteFactory $quoteFactory)
    {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->productRepository = $productRepository;
        $this->_storeManager = $storeManager;
        $this->_checkoutSession = $checkoutSession;
        $this->cart = $cart;
        $this->cartRepository = $cartRepository;
        $this->_productloader = $_productloader;
        $this->quoteManagement = $quoteManagement;
        $this->_customerSession = $customerSession;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->quoteFactory = $quoteFactory;
    }

    public function execute()
    {
         // Note : $products peramater contain all product information.
        $quote = $this->_checkoutSession->getQuote();
        $products = $this->getRequest()->getParam('data');
        foreach($products as $params)
        {
            $cartparams = array();  
            $productId = $params['id'];
           $product = $this->_productloader->create()->load($productId);
            if (!$product) {
                return false;
            }
            $cartparams['product'] = $product->getId();            
            $cartparams['product'] = $product->getPrice(); 
            if (isset($params['qty'])) {
                $cartparams['qty'] = $params['qty'];
            } else {
                $cartparams['qty'] = 1;
            }
            try {


                $request = new \Magento\Framework\DataObject();
                $request->setData($cartparams);
                $this->cart->addProduct($product,$request);
            
            }catch (\Magento\Framework\Exception\LocalizedException $e) {
                if ($this->_checkoutSession->getUseNotice(true)) {
                    $this->messageManager->addNotice(
                        $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml($e->getMessage())
                    );
                } else {
                    $messages = array_unique(explode("\n", $e->getMessage()));
                    foreach ($messages as $message) {
                        $this->messageManager->addError(
                            $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml($message)
                        );
                    }
                }

            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t add this item to your shopping cart right now.'));
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            }
            unset($params['product']);


        }
         $this->cart->save();
        

        //return true;
    }

}