<?php

namespace Shirts\Tool\Controller\Men;

use Magento\Framework\Controller\ResultFactory;

class Shirtbuttonfabric extends \Magento\Framework\App\Action\Action
{

  public function __construct(
		\Magento\Backend\App\Action\Context $context,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
		parent::__construct($context);
		$this->resultJsonFactory = $resultJsonFactory;
	}

  public function DBConnect(){
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
    	$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
    	return $resource->getConnection();
  }

  public function basePath(){
  	$om = \Magento\Framework\App\ObjectManager::getInstance();
  	$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
  	$currentStore = $storeManager->getStore();
  	return $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
  }

  public function execute()
  {
    $sql = " SELECT * FROM shirt_button_fabric";
    $rows = $this->DBConnect()->fetchAll($sql);
    // print_r($rows); die;

    $fabrics = array();
  foreach ($rows as $fabric) {
      echo $id = $fabric['button_fabric_id'];
      $name = $fabric['title'];
      $thumb = $fabric['fabric_thumb'];
      $real_img = $fabric['fabric_real_image'];
      $shirt_type_name = "Cotton";

      $fabrics[] = array('id' => $id, 'price' => '1', 'name' => $name, 'real_img' => $this->basePath() . $real_img, 'img' => $this->basePath() . $thumb);

  }

      return  $this->resultJsonFactory->create()->setData($fabrics);


}

}
