<?php
namespace PartFinder\Extension\Block\Adminhtml\Catalog\Product\Form;

class Gallery extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'group/gallery.phtml';
    
}
