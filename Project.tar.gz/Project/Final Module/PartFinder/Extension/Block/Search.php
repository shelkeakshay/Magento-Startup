<?php
namespace PartFinder\Extension\Block;
/**
    * Created By:Nisha Jadhav
    * Created On:14th June 2018
    * Purpose:Create block for search product
*/
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\Result\Json;
use Magento\Search\Helper\Data as SearchHelper;
use Magento\Search\Model\AutocompleteInterface;
use Magento\Search\Model\QueryFactory;

class Search extends \Magento\Framework\View\Element\Template {

    protected $_registry;
    protected $_productloader;
    protected $_storeManager;

    public function __construct
    (\Magento\Store\Model\StoreManagerInterface $storeManager, 
    \Magento\Catalog\Model\ProductFactory $_productloader, 
    \Magento\Framework\Registry $registry,
    \Magento\Catalog\Block\Product\Context $context,
    array $data = []) {
                    $this->_registry = $registry;
                    $this->_storeManager = $storeManager;
                    $this->_productloader = $_productloader;
                    parent::__construct($context, $data);
    }

    protected function _prepareLayout() {

        return parent::_prepareLayout();
    }

    public function getLoadProduct() {

        return $this->_productloader->create()->load($this->getProductId());
    }

    protected function getStoreId() {

        return $this->_storeManager->getStore()->getId();
    }


}
