<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Shirts\ShirtFabric\Model\ResourceModel;

class ShirtCategory extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    protected function _construct()
    {
        $this->_init('shirtcategory', 'shirtcategory_id');
    }
}