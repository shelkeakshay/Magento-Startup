<?php
    /**
    * Created By:Nisha Jadhav
    * Created On:13th June 2018
    * Purpose:Display Product list by using block
    */
namespace PartFinder\Extension\Block\Rewrite\Product;

class ListProduct extends \Magento\Catalog\Block\Product\ListProduct//extends ListProduct Class
{
	public function demo(){
        
        return "Demo****************";
    }
}
