<?php

namespace Akshay\Tab\Controller\Index;

class Upload extends \Magento\Framework\App\Action\Action {

    protected $_filesystem;

    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Framework\Filesystem $fileSystem
    ) {
        $this->_filesystem = $fileSystem;
        parent::__construct($context);
    }

    /**
     * Upload and save image
     *
     */
    public function execute() {
        $result = array();
        if ($_FILES['test_image']['name']) {
            try {
                // init uploader model.
                $uploader = $this->_objectManager->create(
                        'Magento\MediaStorage\Model\File\Uploader', ['fileId' => 'test_image']
                );
                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                $uploader->setAllowRenameFiles(true);
                $uploader->setFilesDispersion(true);
                // get media directory
                $mediaDirectory = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA);
                // save the image to media directory
                $result = $uploader->save($mediaDirectory->getAbsolutePath());
            } catch (Exception $e) {
                \Zend_Debug::dump($e->getMessage());
            }
        }
        return $result;
    }

}
