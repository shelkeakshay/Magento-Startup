<?php

namespace Mageplaza\HelloWorld\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerLogin implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        // echo "Customer Registered ";
        $customer = $observer->getEvent()->getCustomer();
        // echo $customer->getName(); //Get customer name
        // echo $customer->getEmail();
        // echo get_class($customer);
        exit;
    }
}
