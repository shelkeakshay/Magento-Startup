/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var config = {
    map: {
        '*': {
            ExtensionSearchJs: 'PartFinder_Extension/js/ajaxsearch',
            ExtensionFilterJs: 'PartFinder_Extension/js/ajaxfilter',
            ExtensionCartupdateJs: 'PartFinder_Extension/js/ajaxcartupdate',
           
                       
        }
    }
};
