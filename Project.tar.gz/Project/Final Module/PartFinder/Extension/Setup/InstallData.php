<?php
namespace PartFinder\Extension\Setup;
/**
    * Created By:Nisha Jadhav
    * Created On:13th June 2018
    * Purpose:Create Image attribute for product
*/
 
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
 
/**
 * @codeCoverageIgnore
 */
 class InstallData implements InstallDataInterface
    {

    /**
     * Customer setup factory
     *
     * @var \Magento\Customer\Setup\CustomerSetupFactory
     */
    private $_eavSetupFactory;

    /**
     * Init
     *
     * @param \Magento\Customer\Setup\CustomerSetupFactory
     * $customerSetupFactory
     */
    public function __construct(
        \Magento\Eav\Setup\EavSetupFactory $eavSetupFactory
    ) {
        $this->_eavSetupFactory = $eavSetupFactory;
    }

    /**
     * Installs DB schema for a module
     *
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        /** @var EavSetup $eavSetup */
        $eavSetup = $this->_eavSetupFactory->create([
            'setup' => $setup
        ]);
      $eavSetup->addAttribute(\Magento\Catalog\Model\Product::ENTITY,
            'newPartFinder', [
                'group'                   => 'General',
                'type'                    => 'varchar',
                'backend'                 => '',
                'frontend'                => '',
                'label'                   => 'New Tab Image',
                'input'                   => 'file',
                'source'                  =>
                    'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                'visible'                 => true,
                'default'                 => '0',
                'frontend'                => \Magento\Catalog\Model\Product\Attribute\Frontend\Image::class,
                'input_renderer' => \Magento\Catalog\Block\Adminhtml\Product\Helper\Form\BaseImage::class,
                'unique'                  => false,
                'note'                    => '',
                'required'                => false,
                'sort_order'              => '5',
                'global'                  =>
                   \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                'used_in_product_listing' => true,
                'visible_on_front'        => true
            ]);
    }
}
