<?php
namespace Test\Ajax\Controller\Index;
use \Magento\Framework\App\Action\Action;
use \Magento\Framework\App\Action\Context;
use \Magento\Framework\View\Result\PageFactory;



class Filter extends Action
{

    /**
    * @var PageFactory
    */
    protected $_pageFactory;
    protected $_request;
    protected $_registry;
    protected $_productCollectionFactory;

    public function __construct(\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory, \Magento\Catalog\Model\ProductFactory $_productloader, \Magento\Framework\Registry $registry, \Magento\Framework\App\Request\Http $request, \Magento\Framework\App\Action\Context $context, \Magento\Framework\View\Result\PageFactory $pageFactory) {
        $this->_request = $request;
        $this->_productloader = $_productloader;
        $this->_registry = $registry;
        $this->_pageFactory = $pageFactory;
        $this->_productCollectionFactory = $productCollectionFactory;
        return parent::__construct($context);
    }

    public function getLoadProduct($groupPId) {
        return $this->_productloader->create()->load($groupPId);
    }

    public function execute() {
        $groupPId = $this->_request->getParam('grouped_pid');
        $searchKey = $this->_request->getParam('search') ? $this->_request->getParam('q') : "";
        $sortby = $this->_request->getParam('sort');
        $grouped_product = $this->getLoadProduct($groupPId)->getTypeInstance(true)->getAssociatedProducts($this->getLoadProduct($groupPId));
        $product_collection = $this->getSearchResult($grouped_product, $searchKey, $sortby);
        $layout = $this->_view->getLayout();
        $block = $layout->createBlock(\Test\Ajax\Block\Search::class);
        $block->setTemplate('Test_Ajax::searchlist.phtml');
        $block->setData('product_collection', $product_collection);
        $this->getResponse()->setBody($block->toHtml());
    }

    protected function getSearchResult($grouped_product, $searchKey, $sortby) {
        foreach ($grouped_product as $_product) {
            $productIds[] = $_product->getId();
        }
        $product_collection = $this->_productCollectionFactory->create();
        $product_collection->addAttributeToFilter(
                [
                        ['attribute' => 'name', 'like' => '%' . $searchKey . '%'],
                        ['attribute' => 'sku', 'like' => '%' . $searchKey . '%'],
                        ['attribute' => 'reference', 'like' => '%' . $searchKey . '%'],
        ]);
        

        if ($sortby == "sku") {
            $product_collection->addAttributeToSort('sku', 'ASC');
        } else if ($sortby == "refid") {
            $product_collection->addAttributeToSort('reference', 'ASC');
        } else if ($sortby == "name") {
            $product_collection->addAttributeToSort('name', 'ASC');
        }

        return $product_collection;
    }

}
