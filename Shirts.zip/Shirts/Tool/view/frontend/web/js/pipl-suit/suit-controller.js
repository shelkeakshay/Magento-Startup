var style, currentId;
var removeSpace;
var jacketImage;
var lapelImage;
var basePath;//jQuery("#basePath").val()
var custom_ajax;
var productId;
var genderId;
var fabricId = '0';
var style_ID;
var tempPj;
var currStyleName = "Style";
var linid_active_id = "1";

//for fabric change 
var tempJk;
var tempPt;
var tempVst;
var tempAccnt;
var temptopCoat;
var currentThreadsId = "1";
//end
var temp = {};

//
var jacketFabricName = 'Upper Side';
var pantFabricName = 'Upper Side';
var vestFabricName = 'Upper Side';
var jacketFabricId = '1';
var pantFabricId = '1';
var vestFabricId = '1';
//


angular.module("Suit").controller("suitController", function ($scope, $filter, designService, viewService, fabricService, vestService, pantService, topCoatService, fabricAllDataService, suitAccentService, $http, measurementDataService) {//measurementDataService

    $scope.isActive = false;
    $scope.IsVisible = true;
    $scope.IsJacket = true;
    $scope.IsVest = false;
    $scope.myClassForZoom = [];
    $scope.activeView = 1;
    $scope.IsImage = false;
    $scope.IsZoom = true;
    $scope.jacketView = false;
    $scope.myClassForZoom = [];
    $scope.fabricId = "1";
    $scope.backcollfabId = "1";
    $scope.backelbofabId = "1";
    $scope.partOption = "all";
    $scope.selStyleArr = [];

    $scope.sleeveBtnCnt = "2";
    $scope.styleBtnCnt = "1";
    $scope.styleBtnType = "1";
    $scope.vestStyleBtnType = "1";
    $scope.actCatName = "";

    $scope.actStyleJKArr = {};
    $scope.actStylePantArr = {};
    $scope.actStyleVestArr = {};
    $scope.actStyleData = {};

    productId = angular.element("#productId").val();
    genderId = angular.element("#genderId").val();
    basePath = angular.element("#basePath").val();


    $scope.activeProduct = productId; //suit
    $scope.activeModel = genderId; //male


    //mesuarement data
    $scope.measureFlg = true;
    $scope.scanSizeFlg = false;
    $scope.stdSizeFlg = false;
    $scope.unitVal = 1;
    $scope.unitName = "in";
    $scope.unitScanName = "in";
    $scope.jacketSizes = measurementDataService.getJacketSizes();
    $scope.pantSizes = measurementDataService.getPantSizes();
    //load views
    $scope.views = viewService.getSuitView();
    //add more fit in standard size
    $scope.addMoreFit = function () {
        jQuery("#fit-holder").append('<div class="row offset-top-10"><label class="col-xs-3 control-label" for="inputPassword3"> <i class="fa fa-arrow-circle-right text-success"> </i>  Select Your Fit </label><div class="col-xs-3"><select class="form-control fit-select-box"><option value="-">Select</option><option value="S">S</option><option value="M">M</option><option value="L">L</option><option value="XL">XL</option><option value="XXL">XXL</option><option value="3XL">3XL</option><option value="4XL">4XL</option></select></div><label class="col-xs-2 control-label" for="inputPassword3">  Quantity </label><div class="col-xs-2"><select class="form-control"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div><div class="col-xs-2" onclick="removeFit(this);" ><a class="btn btn-primary btn-xs" href="javascript:void(0);" > <span class="glyphicon glyphicon-minus"></span></a></div></div>');
    }

    $scope.showScanSize = function () {
        console.log("in scan..")
        $scope.scanSizeFlg = true;
        $scope.stdSizeFlg = false;
        $scope.measureFlg = false;
    }

    $scope.showStdSize = function () {

        console.log("in std..")
        $scope.scanSizeFlg = false;
        $scope.stdSizeFlg = true;
        $scope.measureFlg = false;
    }
//change Unit
    $scope.changeUnit = function (val) {
        if (val == "in") {
            $scope.unitVal = 1;
        } else {
            $scope.unitVal = 2.54;
        }
    }
// change unit scan
    $scope.changeScanUnit = function (unitVal) {
        $scope.unitScanName = unitVal;
        var convertVal = 0;
        if (unitVal == "cm") {
            convertVal = 2.54;
        } else {
            convertVal = 0.393701;
        }

        jQuery(".scan_number").each(function (e) {
            if (jQuery(this).val() != "") {
                var res = parseFloat(parseFloat(jQuery(this).val()) * convertVal).toFixed(2);
                jQuery(this).val(res);
            }
        });
    }
    //mesuarement data end


    $scope.addClassOfZoom = function () {

        $scope.myClassForZoom.push('zoomOut');
        $scope.IsVisible = false;
    }

    $scope.hideFabricDiv = function () {
        $scope.IsImage = false;
    }

    $scope.showFabricDiv = function () {
        $scope.IsImage = true;
    }

    $scope.jacketVisiblefalse = function (obj) {


        $scope.IsJacket = true;
        hideJacket();
    }


    $scope.jacketVisibletrue = function () {
//angular.element("#jacketHide").css({"margine-left": "11px"});
        $scope.IsJacket = false;
        hideJacket();
    }


    $scope.vestVisiblefalse = function (obj) {
        $scope.IsVest = true;
        hideVest();
    }

    $scope.vestVisibletrue = function () {

//angular.element("#jacketHide").css({"margine-left": "11px"});
        $scope.IsVest = false;
        hideVest();
    }

    function hideVest()
    {
        if ($scope.IsVest)
        {
            angular.element("#mainImageHolder").find(".shirt_part[rel=veststyle]").hide();
            angular.element("#mainImageHolder").find(".shirt_part[rel=vestlapel]").hide();
            angular.element("#mainImageHolder").find(".shirt_part[rel=vestbuttons]").hide();
            angular.element("#mainImageHolder").find(".shirt_part[rel=breastpocket]").hide();
            angular.element("#mainImageHolder").find(".shirt_part[rel=vestpockets]").hide();
            angular.element("#mainImageHolder").find(".shirt_part[rel=backveststyle]").hide();
        } else {
            angular.element("#mainImageHolder").find(".shirt_part[rel=veststyle]").show();
            angular.element("#mainImageHolder").find(".shirt_part[rel=vestlapel]").show();
            angular.element("#mainImageHolder").find(".shirt_part[rel=vestbuttons]").show();
            angular.element("#mainImageHolder").find(".shirt_part[rel=breastpocket]").show();
            angular.element("#mainImageHolder").find(".shirt_part[rel=vestpockets]").show();
            angular.element("#mainImageHolder").find(".shirt_part[rel=backveststyle]").show();
        }
    }





    function hideJacket()
    {

        if ($scope.IsJacket)
        {

//jacket view
            jQuery("#mainImageHolder").find("[rel=Style]").show();
            jQuery("#mainImageHolder").find("[rel=Lapel]").show();
            jQuery("#mainImageHolder").find("[rel=Pockets]").show();
            jQuery("#mainImageHolder").find("[rel=buttons]").show();
            //back
            jQuery("#mainImageHolder").find("[rel=Vents]").show();
            jQuery("#mainImageHolder").find("[rel=BackStyle]").show();
            jQuery("#mainImageHolder").find("[rel=sleeve_buttons]").show();
            jQuery("#mainImageHolder").find("[rel=threads]").show();
            jQuery("#mainImageHolder").find("[rel=pocketsquare]").show();
            //show lining vest
            jQuery("#mainImageHolder").find("[rel=collarstyle]").show();
            jQuery("#mainImageHolder").find("[rel=jacketlining]").show();
            jQuery("#mainImageHolder").find("[rel=lining]").show();
            jQuery("#mainImageHolder").find("[rel=vestlining]").hide();
        } else
        {

//front view
            jQuery("#mainImageHolder").find("[rel=Style]").hide();
            jQuery("#mainImageHolder").find("[rel=Lapel]").hide();
            jQuery("#mainImageHolder").find("[rel=Pockets]").hide();
            jQuery("#mainImageHolder").find("[rel=buttons]").hide();
            //back view
            jQuery("#mainImageHolder").find("[rel=BackStyle]").hide();
            jQuery("#mainImageHolder").find("[rel=Vents]").hide();
            jQuery("#mainImageHolder").find("[rel=sleeve_buttons]").hide();
            jQuery("#mainImageHolder").find("[rel=threads]").hide();
            jQuery("#mainImageHolder").find("[rel=pocketsquare]").hide();
            //hide lining vest
            jQuery("#mainImageHolder").find("[rel=collarstyle]").hide();
            jQuery("#mainImageHolder").find("[rel=jacketlining]").hide();
            jQuery("#mainImageHolder").find("[rel=lining]").hide();
            jQuery("#mainImageHolder").find("[rel=vestlining]").show();
        }

    }


    function zoomOutProdImage()
    {
        $scope.IsVisible = true;
        $scope.isActive = false;
        if ($scope.myClassForZoom[0] == "zoomOut")
        {
            $scope.myClassForZoom.pop('zoomOut');
        } else {

            document.getElementById("prev-holder").innerHTML = "";

            if (jQuery(window).width() <= 900) {//for respnsive 

                jQuery(".loaderText").css({"display": "none"});
                jQuery("#theInitialProgress").css({"display": "block"});
                jQuery('#zoomOfTool').modal('show');
                jQuery('#mainImageHolder').css("height", jQuery("#view1 img:first").css("height").replace(/[^-\d\.]/g, ''));
                jQuery('#mainImageHolder').css("width", jQuery("#view1 img:first").css("width").replace(/[^-\d\.]/g, ''));

                jQuery('.modal-backdrop').css("display", "none");
                html2canvas(jQuery('#mainImageHolder'), {
                    onrendered: function (can) {
                        jQuery('.modal-backdrop').css("display", "none");
                        var data = can.toDataURL('image/png');
                        var image = new Image();
                        image.src = data;
                        image.height = jQuery("#view1 img:first").css("height").replace(/[^-\d\.]/g, '');
                        image.width = jQuery("#view1 img:first").css("width").replace(/[^-\d\.]/g, '');
                        var myEl = angular.element(document.querySelector('#prev-holder'));
                        myEl.append(image);

                        jQuery("#theInitialProgress").css({"display": "none"});
                        jQuery(".loaderText").css({"display": "block"});

                    }
                });
            } else {

                jQuery("#theInitialProgress").css({"display": "block"});
                jQuery(".container-fluid").css({"opacity": "0.3"});
                jQuery(".mainToolarea").css({"height": "1320px"});
                jQuery(".mainToolarea").css({"width": "1080px"});

                jQuery("#zoomOfTool").modal("show");

                jQuery("#mainImageHolder img").css({"width": "unset"});
                jQuery("#mainImageHolder img").css({"max-width": "unset"});
                setTimeout(function () {

                    jQuery('.modal-backdrop').remove();
                    html2canvas(document.getElementsByClassName("mainToolarea"), {
                        onrendered: function (can) {



                            var data = can.toDataURL('image/png');
                            var image = new Image();
                            image.height = 1320;
                            image.width = 1080;

                            image.src = data;
                            var myEl = angular.element(document.querySelector('#prev-holder'));
                            myEl.append(image);
                            jQuery("#mainImageHolder img").css({"width": "100%"});
                            jQuery("#mainImageHolder img").css({"max-width": "100%"});
                            jQuery("#theInitialProgress").css({"display": "none"});
                        }
                    });
                }, 500);

            }
        }
    }

    $scope.takeScreenShot = function () {

        zoomOutProdImage();
    }


    $scope.leftNavFabCat = function ($event, actCatName)
    {
        jQuery(".leftpanelsection .sidebar-options").hide();
        jQuery("#divOptionFilter").hide();
        jQuery("#div4").show();




        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign")
        angular.element($event.currentTarget).addClass("activeDesign");

        angular.element('#fabircCatName').html(actCatName + " Fabrics");

        $scope.searchFabric = actCatName;



        var fabricFilterData = tempPj.fabric;

        if ($scope.searchFabric == "All" || $scope.searchFabric == "ALL" || $scope.searchFabric == "all")
        {
            var data = fabricFilterData;

        } else {
            var data = $filter('filter')(fabricFilterData, {category_parent: $scope.searchFabric});
        }

        $scope.fabricData.fabric = data;




        updateInItZoom();

    }

    $scope.leftNavFabCatFilterClose = function ($event)
    {
//        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign")
//        angular.element($event.currentTarget).addClass("activeDesign");
        jQuery("#divOptionFilter").hide();

        //leftMainNav_fabricCat
        setTimeout(function () {
            jQuery(".leftpanelsection #div4").show();

            jQuery('#accordian').accordion("refresh");
        }, 50);
    }


    $scope.leftNavFabCatFilter = function ($event)
    {
//        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign")
//        angular.element($event.currentTarget).addClass("activeDesign");

        jQuery(".leftpanelsection .sidebar-options").hide();
        //leftMainNav_fabricCat
        setTimeout(function () {

            jQuery("#divOptionFilter").show();
            jQuery('#accordian').accordion("refresh");
        }, 50);
    }

    $scope.leftNavFabCatMulti = function ($event)
    {
        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign")
        angular.element($event.currentTarget).addClass("activeDesign");
        jQuery(".leftpanelsection .sidebar-options").hide();
        //leftMainNav_fabricCat
        setTimeout(function () {
            jQuery("#divOptionMulti").show();
        }, 50);
    }

    $scope.leftNavFabCatInfo = function ($event)
    {
        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign")
        angular.element($event.currentTarget).addClass("activeDesign");

        jQuery(".leftpanelsection .sidebar-options").hide();
        //leftMainNav_fabricCat
        setTimeout(function () {
            jQuery("#divOptionInfo").show();
        }, 50);
    }

    $scope.changeSameDifferentFabric = function (part)
    {
        jQuery(".leftpanelsection .sidebar-options").hide();
        jQuery("#div4").show();

        //divOptionMulti
        angular.element("#divOptionMulti").find(".activeDesign").removeClass("activeDesign")


        if (part == 'same')
        {
            jQuery("#divOptionDifferentParts").hide();
            $scope.partOption = 'all';
            angular.element("#divOptionMulti .same").addClass("activeDesign");

        } else {
            jQuery("#divOptionDifferentParts").show();
            $scope.partOption = 'jacket';
            angular.element("#divOptionMulti .different").addClass("activeDesign");
        }


    }


    /*$scope.applyFilter = function ()
     {
     jQuery(".leftpanelsection .sidebar-options").hide();
     jQuery("#div4").show();
     
     
     /*remove n init fabirc zoom*/
    /*  angular.element(".zoomContainer").remove();
     jQuery(".fabvie img").elevateZoom();*/

    /* updateInItZoom();
     }*/

    $scope.applyFilter = function ()
    {
        jQuery(".leftpanelsection .sidebar-options").hide();
        jQuery("#div4").show();

        setTimeout(function () {
            jQuery('.back-btn').trigger('click');
        }, 200)


        console.log("sdasd")



        jQuery('body').addClass('open-fabric');

        nullfabricTxt();

    }

    function nullfabricTxt() {

        console.log($scope.fabricData.fabric)

        if (jQuery(".fabricGene").children().length) {
            jQuery("#nullTxt").hide()
        } else {
            jQuery("#nullTxt").show()
        }

    }

    $scope.search = {};
    $scope.filterCheckedFabric = function ($event, ind, actObj) {

        $scope.fabricData.fabric = [];

        for (var data in tempPj.fabric) {

            for (var prop in $scope.search) {

                if ($scope.search[prop] == true) {

                    if (tempPj.fabric[data].material_parent == prop || tempPj.fabric[data].pattern_parent == prop || tempPj.fabric[data].season_parent == prop || tempPj.fabric[data].color_parent == prop || tempPj.fabric[data].category_parent == prop) {
                        $scope.fabricData.fabric.push(tempPj.fabric[data]);
                    }
                }
            }

        }


        //if all then display all fabirc 
        if ($scope.search['All'] == true)
        {
            $scope.fabricData.fabric = [];
            for (var data in tempPj.fabric) {
                $scope.fabricData.fabric.push(tempPj.fabric[data]);
            }
        }

        /*//init fabirc zoom
         angular.element(".zoomContainer").remove();
         jQuery(".fabvie img").elevateZoom();*/

//        updateInItZoom();
        allFab()
    }

    function allFab() {
        var count = 0;
        var numFab = jQuery('.fabricFilterCat').find('li').length;
//        console.log("numFab == " + numFab)
        jQuery('.fabricFilterCat input').each(function () {

            var ckk = jQuery(this).prop('checked');

            if (ckk == false) {
                count++;
            }


        })

        console.log("count = " + count + " numFab == " + numFab)


        //if all then display all fabirc 
        if (count == numFab)
        {
            console.log("allfab")
            $scope.fabricData.fabric = [];
            for (var data in tempPj.fabric) {
                if (tempPj.fabric.hasOwnProperty(data)) {
                    $scope.fabricData.fabric.push(tempPj.fabric[data]);
                }
            }
            /*
             jQuery('input[type="radio"]:checked').prop('checked', false)
             jQuery('.multi-fabric-block').find('ul').find('li').find('input[id="user04"]').prop('checked', true)
             return true;
             */

        }
    }

    $scope.leftNav = function ($event, obj, ind) {

        currStyleName = '';
        angular.element(".suit-preloader").show();
        angular.element(".mainToolarea").css({"opacity": "0"});
        $scope.actLeftNav = angular.element($event.currentTarget).find("a").attr("target") ? angular.element($event.currentTarget).find("a").attr("target") : "1";
        angular.element($event.currentTarget).parent().find(".active").removeClass("active");
        console.log($scope.actLeftNav)
        angular.element(".sidebar-options").hide();
        angular.element("#div" + $scope.actLeftNav).show();
        angular.element($event.currentTarget).addClass("active");
        //customize pant n hide jacket
        var styleType = angular.element($event.currentTarget).attr("type")
//        console.log(styleType)

        if (styleType == "pant")
        {


            if (jQuery(window).width() <= 767) {
                $scope.isActive = false;
            } else {
                if ($scope.activeView == 1 || $scope.activeView == 2)
                {
                    jQuery('#mainImageHolder').find('[rel=veststyle]').hide();
                    jQuery('#mainImageHolder').find('[rel=vestlapel]').hide();
                    jQuery('#mainImageHolder').find('[rel=vestpockets]').hide();
                    jQuery('#mainImageHolder').find('[rel=breastpocket]').hide();
                    jQuery('#mainImageHolder').find('[rel=vestbuttons]').hide();
                    //vest back
                    jQuery('#mainImageHolder').find('[rel=backveststyle]').hide();
                    //lining
                    jQuery('#mainImageHolder').find('[rel=collarstyle]').show();
                    jQuery('#mainImageHolder').find('[rel=lining]').show();
                    jQuery('#mainImageHolder').find('[rel=vestcollar]').hide();
                    jQuery('#mainImageHolder').find('[rel=vestlining]').hide();
                    $scope.isActive = true;
                } else {
                    jQuery('#mainImageHolder').find('[rel=veststyle]').show();
                    jQuery('#mainImageHolder').find('[rel=vestlapel]').show();
                    jQuery('#mainImageHolder').find('[rel=vestpockets]').hide();
                    jQuery('#mainImageHolder').find('[rel=breastpocket]').hide();
                    jQuery('#mainImageHolder').find('[rel=vestbuttons]').show();
                    //vest back
                    jQuery('#mainImageHolder').find('[rel=backveststyle]').hide();
                    //lining
                    jQuery('#mainImageHolder').find('[rel=collarstyle]').show();
                    jQuery('#mainImageHolder').find('[rel=lining]').show();
                    jQuery('#mainImageHolder').find('[rel=vestcollar]').hide();
                    jQuery('#mainImageHolder').find('[rel=jacketlining]').show();
                    $scope.isActive = false;
                }
            }


            //check for view 3
            if ($scope.activeView == 3)
            {
                //show jacket
                $scope.IsJacket = true;
            } else {
                //hide jacket
                $scope.IsJacket = false;
            }


            hideJacket();
            //hide vest



        } else if (styleType == "vest")
        {


            if (jQuery(window).width() <= 767) {

                $scope.isActive = false;
            } else {
                $scope.isActive = false;
            }

            //hide jacket
            $scope.IsJacket = false;
            //hide vest
            jQuery('#mainImageHolder').find('[rel=veststyle]').show();
            jQuery('#mainImageHolder').find('[rel=vestlapel]').show();
            jQuery('#mainImageHolder').find('[rel=vestpockets]').show();
            jQuery('#mainImageHolder').find('[rel=breastpocket]').show();
            jQuery('#mainImageHolder').find('[rel=vestbuttons]').show();
            //vest back
            jQuery('#mainImageHolder').find('[rel=backveststyle]').show();
            //lining
            jQuery('#mainImageHolder').find('[rel=collarstyle]').hide();
            jQuery('#mainImageHolder').find('[rel=lining]').hide();
            jQuery('#mainImageHolder').find('[rel=vestcollar]').show();
            jQuery('#mainImageHolder').find('[rel=jacketlining]').hide();
            jQuery('#mainImageHolder').find('[rel=vestlining]').show();
            hideJacket();
        } else {


            $scope.isActive = false;
            //show jacket
            $scope.IsJacket = true;
            //hide vest
            jQuery('#mainImageHolder').find('[rel=veststyle]').show();
            jQuery('#mainImageHolder').find('[rel=vestlapel]').show();
            jQuery('#mainImageHolder').find('[rel=vestpockets]').show();
            jQuery('#mainImageHolder').find('[rel=breastpocket]').show();
            jQuery('#mainImageHolder').find('[rel=vestbuttons]').show();
            //vest back
            jQuery('#mainImageHolder').find('[rel=backveststyle]').show();
            //lining
            jQuery('#mainImageHolder').find('[rel=collarstyle]').show();
            jQuery('#mainImageHolder').find('[rel=lining]').show();
            jQuery('#mainImageHolder').find('[rel=vestcollar]').hide();
            jQuery('#mainImageHolder').find('[rel=vestlining]').hide();
            jQuery('#mainImageHolder').find('[rel=jacketlining]').show();
            hideJacket();
        }



        imageLoaded();
        //hide name
        if (jQuery(".sidebar-options").hasClass("min"))
        {
            jQuery(".shorttext").show();
        } else {
            jQuery(".shorttext").hide();
        }

    }

    $scope.categoryClick = function ($event, obj, ind) {
        currStyleName = "";

        var navType = jQuery(".topmenu ul li.active").find("a").attr("target");
        jQuery(".shorttext").show();

        if (navType == "5") {
            $scope.actLeftNav = 5;
            $scope.activeView = 3;
        } else {
            if ($scope.actLeftNav == "5") {
                $scope.actLeftNav = 1;
            }
        }

        var designStyle = obj.name.replace(/\s+|&/g, "");

        console.log("categoryClick = " + designStyle);

        $scope.actCatName = designStyle;

        var actCon = angular.element("#div" + $scope.actLeftNav + " .box_option:first").attr("id") ? angular.element("#div" + $scope.actLeftNav + " .box_option:first").attr("id").split("_")[0] : "divs";
        angular.element("#div" + $scope.actLeftNav + " ul li ").removeClass("active");
        angular.element($event.currentTarget).addClass("active");
        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign")
        angular.element($event.currentTarget).addClass("activeDesign");
        angular.element(".sidebar-options").addClass("min");
        angular.element(".box_options .box_option").removeClass("active");
        angular.element(".box_options #" + actCon + "_" + obj.id).addClass("active");
        setTimeout(function () {
            if (navType == "1") {
                jQuery(".leftMainNav").find(".active").trigger("click");
            }
        }, 50);


        if (designStyle == "Vents" || designStyle == "sleeve_buttons")
        {
            $scope.activeView = 2;
        } else if (designStyle == "Lining") {

            $scope.activeView = 3;
        } else if (designStyle == "Style" || designStyle == "Lapel" || designStyle == "Pockets" || designStyle == "buttons")
        {
            $scope.activeView = 1;
        } else if (designStyle == "BackCollar") {
            $scope.activeView = 2;
            if (!angular.element('#divaccent_5 ul:first').find('.activeDesign').attr('id'))
            {
                angular.element('#divaccent_5 ul:first li:first').addClass('activeDesign');
                angular.element('#divaccent_5 ul.BackCollar').css("display", "none");
            }

        } else if (designStyle == "ElbowPatch") {
            $scope.activeView = 2;
            if (!angular.element('#divaccent_6 ul:first').find('.activeDesign').attr('id'))
            {
                angular.element('#divaccent_6 ul:first li:first').addClass('activeDesign');
                angular.element('#divaccent_6 ul.ElbowPatch').css("display", "none");
            }
        }


        /*else {
         
         $scope.activeView = 1;
         
         }*/


        setTimeout(function () {
            angular.element(".fabricInfo").find("a").trigger("click");
        }, 500);

        changeView();
    }

    function changeView()
    {
        currStyleName = "";
        angular.element("#main-container .view-thumb button").removeClass("active");
        var actCat = jQuery(".topmenu .active a").html();
        if ($scope.activeView == "1")
        {
            jQuery("#arrowUP,#arrowDown").show();
            if (angular.element(".leftMainNav").children().find(".active").attr("type") == "pant" && actCat == "Style")
            {

                if (jQuery(window).width() <= 767) {

                    $scope.isActive = false;
                } else {
                    $scope.isActive = true;
                }


                $scope.IsJacket = false;
            } else if (angular.element(".leftMainNav").children().find(".active").attr("type") == "vest") {

                $scope.IsJacket = false;
            } else
            {

                if ($scope.IsJacket) {

                    $scope.IsJacket = true;
                } else {
                    $scope.IsJacket = false;
                }

            }

            angular.element("#Front").addClass("active");
            angular.element(".jH").show();
            if (angular.element(".leftMainNav").children().find(".active").attr("type") == "pant") {


                jQuery('#mainImageHolder').find('[rel=veststyle]').hide();
                jQuery('#mainImageHolder').find('[rel=vestlapel]').hide();
                jQuery('#mainImageHolder').find('[rel=vestpockets]').hide();
                jQuery('#mainImageHolder').find('[rel=breastpocket]').hide();
                jQuery('#mainImageHolder').find('[rel=vestbuttons]').hide();
                //vest back
                jQuery('#mainImageHolder').find('[rel=backveststyle]').hide();
                //lining
                jQuery('#mainImageHolder').find('[rel=collarstyle]').hide();
                jQuery('#mainImageHolder').find('[rel=lining]').hide();
                jQuery('#mainImageHolder').find('[rel=vestcollar]').hide();
                jQuery('#mainImageHolder').find('[rel=vestlining]').hide();
            }
            angular.element("#jacketHide").css({"display": "inline-block"});
            angular.element(".navigate-menu").find("li.jV").show()

        } else if ($scope.activeView == "2")
        {

            jQuery("#arrowUP,#arrowDown").show();
            angular.element("#Back").addClass("active");
            angular.element(".jH").show();
            if (angular.element(".leftMainNav").children().find(".active").attr("type") == "pant" && actCat == "Style")
            {
                if (jQuery(window).width() <= 767) {

                    $scope.isActive = false;
                } else {
                    $scope.isActive = true;
                }

                $scope.IsJacket = false;
            } else if (angular.element(".leftMainNav").children().find(".active").attr("type") == "vest") {
                $scope.IsJacket = false;
            } else {
                if ($scope.IsJacket) {
                    $scope.IsJacket = true;
                } else {
                    $scope.IsJacket = false;
                }
            }

            if (angular.element(".leftMainNav").children().find(".active").attr("type") == "pant") {

                jQuery('#mainImageHolder').find('[rel=veststyle]').hide();
                jQuery('#mainImageHolder').find('[rel=vestlapel]').hide();
                jQuery('#mainImageHolder').find('[rel=vestpockets]').hide();
                jQuery('#mainImageHolder').find('[rel=breastpocket]').hide();
                jQuery('#mainImageHolder').find('[rel=vestbuttons]').hide();
                //vest back
                jQuery('#mainImageHolder').find('[rel=backveststyle]').hide();
                //lining
                jQuery('#mainImageHolder').find('[rel=collarstyle]').hide();
                jQuery('#mainImageHolder').find('[rel=lining]').hide();
                jQuery('#mainImageHolder').find('[rel=vestcollar]').hide();
                jQuery('#mainImageHolder').find('[rel=vestlining]').hide();
            }
            angular.element("#jacketHide").css({"display": "inline-block"});
            angular.element(".navigate-menu").find("li.jV").show()
        } else {

            angular.element("#Inside").addClass("active");
            angular.element(".jH").hide();
            angular.element(".navigate-menu").find("li.jV").hide()

            $scope.isActive = false;
            if (angular.element(".leftMainNav").children().find(".active").attr("type") == "vest" && actCat == "Style")
            {

                $scope.IsJacket = false;
            } else if (angular.element(".leftMainNav").children().find(".active").attr("type") == "vest") {
                $scope.IsJacket = false;
            } else {
                $scope.IsJacket = true;
            }
            if (angular.element(".leftMainNav").children().find(".active").attr("type") == "pant") {


                jQuery('#mainImageHolder').find('[rel=veststyle]').show();
                jQuery('#mainImageHolder').find('[rel=vestlapel]').show();
                jQuery('#mainImageHolder').find('[rel=vestpockets]').hide();
                jQuery('#mainImageHolder').find('[rel=breastpocket]').hide();
                jQuery('#mainImageHolder').find('[rel=vestbuttons]').show();
                //vest back
                jQuery('#mainImageHolder').find('[rel=backveststyle]').hide();
                //lining
                jQuery('#mainImageHolder').find('[rel=collarstyle]').show();
                jQuery('#mainImageHolder').find('[rel=lining]').show();
                jQuery('#mainImageHolder').find('[rel=vestcollar]').hide();
                jQuery('#mainImageHolder').find('[rel=jacketlining]').show();
            }

            jQuery("#arrowUP,#arrowDown").hide();
        }

        hideJacket();
        imageLoaded();
        //check for mobile
        if (jQuery(window).width() <= 900) {

            jQuery("#arrowUP,#arrowDown,#zoomButton,#zoomOutButton").hide();
        }
    }


    $scope.removemin = function ($event) {
        removeActnMin();
    }

    function removeActnMin() {


        if (jQuery(window).width() <= 767) {

            angular.element(".sidebar-options").removeClass("min");
            angular.element(".LeftpanemOpen .leftpanelsection").css("left", "0");
        }

        angular.element(".box_option").removeClass("active");
        //hide stle name
        var type = jQuery(".topmenu .active a").attr("target");
        setTimeout(function () {
            if (type == "5")
            {
                angular.element(".topmenu a[target=" + type + "]").trigger("click");
            } else {
                angular.element(".leftMainNav").find(".active a").trigger("click");
            }

            jQuery(".shorttext").hide();
        }, 100);
        //hide stle name end


    }



    //change Style of Jacket 
    $scope.designClick = function ($event, obj, ind, icon) {


        style_ID = jQuery(obj).attr("id");
        angular.element(".suit-preloader").show();
        angular.element(".mainToolarea").css({"opacity": "0"});

        var parent, styleImg, styleType, styleName, styleId;
        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign");
        angular.element($event.currentTarget).addClass("activeDesign");
        if (jQuery(window).width() <= 767) {

            angular.element(".sidebar-options").removeClass("min");
            angular.element(".LeftpanemOpen .leftpanelsection").css("left", "0");
        }

        angular.element("body").removeClass("LeftpanemOpen");
        $scope.activeStyle = obj;
        currStyleName = parent = $scope.activeStyle.parent.replace(/\s+|&/g, "");
        styleName = $scope.activeStyle.name.replace(/\s+|&/g, "");
        styleId = $scope.activeStyle.id;
        //get style type single or double
        styleType = $scope.activeStyle.designType; //angular.element("#view" + $scope.activeView).find('.shirt_part[rel=' + parent + ']').attr("type");

        temp[parent] = $scope.actStyleData[parent] = styleId;










        if ($scope.activeStyle.price) {
            stylePriceArr[parent] = $scope.activeStyle.price;
        } else {
            stylePriceArr[parent] = "0.0";
        }



        //check style
        if (styleName == "Mandarin")
        {
            angular.element(".theView").find('.shirt_part[rel=Lapel]').hide();
            angular.element(".theView").find('.shirt_part[rel=Tie]').hide();
            // $scope.activeView = 1;
            // changeView();
        } else
        {
            angular.element(".theView").find('.shirt_part[rel=Lapel]').show();
            $scope.activeView = 1;
            changeView();
        }


        //chnage View
        if (parent == "Vents" || parent == "sleeve_buttons")
        {
            $scope.activeView = 2;
            changeView();
        } else {

            /*$scope.activeView = 1;
             changeView();*/
        }



        if (parent == "Fit")
        {
            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + parent.toLowerCase() + "_" + styleId + ".png";
        } else if (parent == "Lapel")
        {
            var styleTypeId = angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") : "1";
            var LapelTypeId = angular.element("#lapelSize").prev().prev().find(".activeDesign").attr("id");
            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "style_" + styleTypeId + "_size_" + styleId + "_" + parent.toLowerCase() + "type_" + LapelTypeId + "_view_1.png";

        } else if (parent == "Vents")
        {
            styleImg = $scope.activeStyle.main_img;
        } else if (parent == "sleeve_buttons")
        {
            $scope.sleeveBtnCnt = $scope.activeStyle.btn_count;
            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.activeStyle.btn_count + "_color_1.png";
        } else if (parent == "buttons")
        {
            var styleTypeId = angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") : "1";
            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + styleTypeId + "_" + parent.toLowerCase() + "_" + $scope.activeStyle.btn_count + "_color_1.png";
            //update btn count in style
            angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount", $scope.activeStyle.btn_count);
            $scope.actStyleJKArr['threads'] = basePath + "media/jacket_images/threads/" + currentThreadsId + "_threads_" + styleTypeId + "_btn_" + $scope.activeStyle.btn_count + "_view_1.png";

        } else if (parent == "pantfit")
        {

            if (styleId == "2")
            {
                $scope.actStylePantArr['pantStyle'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/pantfit_2_view_1.png";
                $scope.actStylePantArr['pantBackStyle'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/pantfit_2_view_2.png";
            } else {

                styleImg = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                var styleImg1 = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_2.png";
                $scope.actStylePantArr['pantStyle'] = basePath + "media/default_tool_img/blank.png";
                $scope.actStylePantArr['pantBackStyle'] = basePath + "media/default_tool_img/blank.png";
                $scope.actStylePantArr['backpantfit'] = styleImg1;
            }

        } else if (parent == "pantpleats" || parent == "pantcuff")
        {



            if ($scope.activeView == 3) {


                if (jQuery("#divpant_5").find(".activeDesign").attr("id") == "2")
                {

                    $scope.actStylePantArr['pantFoldCuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_pantcuff_2_view_3.png";
                } else {


                    $scope.actStylePantArr['pantFoldCuff'] = basePath + "media/default_tool_img/blank.png";
                }

                var CurrentPleats = jQuery("#divpant_2").find(".activeDesign").attr("id");
                if (CurrentPleats == "1") {

                    $scope.actStylePantArr['foldPantPleats'] = basePath + "media/default_tool_img/blank.png";
                } else {
                    $scope.actStylePantArr['foldPantPleats'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_pantpleats_" + CurrentPleats + "_view_3.png";
                }

            }

            if (styleName == "NoPleates" || styleName == "NoCuffs") {

                styleImg = basePath + "media/default_tool_img/blank.png";
                $scope.actStylePantArr['backpantcuff'] = styleImg;
                $scope.actStylePantArr['pantFoldCuff'] = styleImg;
                $scope.actStylePantArr['pantcuff'] = styleImg;
                $scope.actStylePantArr['foldPantPleats'] = styleImg;
                $scope.actStylePantArr['pantpleats'] = styleImg;
                $scope.actStylePantArr['Pleats'] = styleImg;
            } else
            {



                if ($scope.activeView == 1)
                {
                    styleImg = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_" + $scope.activeView + ".png";
                }



                if (parent == "pantcuff")
                {

                    if ($scope.activeView == 1)
                    {

                        $scope.actStylePantArr['backpantcuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_2.png";
                        $scope.actStylePantArr['pantFoldCuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_3.png";
                    } else if ($scope.activeView == 2) {

                        $scope.actStylePantArr['backpantcuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_2.png";
                        $scope.actStylePantArr['pantcuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                    } else {

                        $scope.actStylePantArr['backpantcuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_2.png";
                        $scope.actStylePantArr['pantcuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                    }
                }

            }


        } else if (parent == "fastening" || parent == "pantpockets")
        {
            if ($scope.activeView == 3) {
                var activePocketId = angular.element("#divpant_4").find(".activeDesign").attr("id") ? angular.element("#divpant_4").find(".activeDesign").attr("id") : "1";
                $scope.actStylePantArr['foldedPantPocket'] = basePath + "media/pant_images/pantpocket/Folded-Pant_Front-Pockets_" + activePocketId + ".png";
            }

            styleImg = $scope.activeStyle.main_img;
        } else if (parent == "veststyle" || parent == "vestedge")
        {

            if (parent == "vestedge")
            {
                var vestStyleId = angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";
                var vestEdgeId = styleId; //angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") : "1";

                styleImg = basePath + "media/default_tool_img/blank.png";
                if ($scope.activeView == 3) {
                    $scope.actStyleVestArr['veststyle'] = basePath + "media/vest_images/veststyle/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_1.png";
                } else {
                    $scope.actStyleVestArr['veststyle'] = basePath + "media/vest_images/veststyle/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_" + $scope.activeView + ".png";
                }
            } else {
                var vestStyleId = styleId; // angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";
                var vestEdgeId = angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") : "1";

                $scope.vestStyleBtnType = vestStyleId;

                if ($scope.activeView == 3) {
                    styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_1.png";
                } else {
                    styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_" + $scope.activeView + ".png";
                }


                $scope.actStyleVestArr['veststyle'] = styleImg;
                $scope.actStyleVestArr['backveststyle'] = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_2.png";
                //update vestbutton image


                var vestStyleBtCnt = angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("btnCount");
                if (vestStyleId == "1")
                {
                    $scope.actStyleVestArr['vestbuttons'] = basePath + "media/vest_images/vestbuttons/" + vestStyleId + "_buttons_3_color_1.png";
                } else {
                    $scope.actStyleVestArr['vestbuttons'] = basePath + "media/vest_images/vestbuttons/" + vestStyleId + "_buttons_4_color_1.png";
                }



                //end


                dispStyleBtn(styleId);
            }




        } else if (parent == "vestlapel")
        {
            var vestStyleId = angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";
            var vestLapelId = styleId; //angular.element("#view1").find('.shirt_part[rel=vestlapel]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=vestlapel]').attr("id") : "1";

            if ($scope.activeView == 3) {
                styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_lapel_" + vestLapelId + "_view_1.png";
            } else {
                styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_lapel_" + vestLapelId + "_view_" + $scope.activeView + ".png";
            }

        } else if (parent == "vestbuttons")
        {
            var vestStyleId = angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";
            angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("btnCount", $scope.activeStyle.btn_count);
            styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + vestStyleId + "_buttons_" + $scope.activeStyle.btn_count + "_color_1.png";
        } else if (parent == "vestpockets" || parent == "breastpocket")
        {
            if (parent == "breastpocket")
            {

                if (styleId == "2")
                {
                    styleImg = basePath + "media/default_tool_img/blank.png";
                } else
                {
                    if ($scope.activeView == 3) {
                        styleImg = basePath + "media/vest_images/vestpockets/" + $scope.fabricId + "_" + parent.toLowerCase() + "_view_1.png";
                    } else {
                        styleImg = basePath + "media/vest_images/vestpockets/" + $scope.fabricId + "_" + parent.toLowerCase() + "_view_" + $scope.activeView + ".png";
                    }
                }
            } else
            {
                if ($scope.activeView == 3) {
                    styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                } else {
                    styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_" + $scope.activeView + ".png";
                }

            }


        } else
        {
            if (parent == "Style")//update Lapel design Style
            {


                var LapelTypeId = angular.element("#lapelSize").prev().prev().find(".activeDesign").attr("id") ? angular.element("#lapelSize").prev().prev().find(".activeDesign").attr("id") : "1";
                var LapelSizeId = angular.element("#lapelSize").find(".activeDesign").attr("id") ? angular.element("#lapelSize").find(".activeDesign").attr("id") : "1";
                ///update style buttons
                var styleTypeId = angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") : "1";
                var styleBtnCnt;

                var image = new Image();
                if ($scope.activeStyle.type == "1")
                {



                    angular.element(".theView").find('.shirt_part[rel=Tie]').show();
                    styleBtnCnt = angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") : "1";
                    image.src = basePath + "media/jacket_images/buttons/" + $scope.activeStyle.type + "_buttons_" + styleBtnCnt + "_color_1.png";
                    if (image.width == 0) {

                        angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount", "1");
                        $scope.actStyleJKArr['buttons'] = basePath + "media/jacket_images/buttons/" + $scope.activeStyle.type + "_buttons_1_color_1.png";
                        $scope.actStyleJKArr['threads'] = basePath + "media/jacket_images/threads/" + currentThreadsId + "_threads_" + $scope.activeStyle.type + "_btn_1_view_1.png";
                        $scope.actStyleJKArr['collarstyle'] = basePath + "media/jacket_images/collar/" + $scope.fabricId + "_collarstyle_" + $scope.activeStyle.id + "_view_3.png";
                        $scope.actStyleJKArr['vestcollar'] = basePath + "media/vest_images/vestlining/" + $scope.fabricId + "_vestcollar_view_3.png";
                        $scope.actStyleJKArr['lining'] = basePath + "media/jacket_images/lining/1_liningstyle_" + $scope.activeStyle.id + "_view_3.png";
                    } else {
                        $scope.actStyleJKArr['buttons'] = basePath + "media/jacket_images/buttons/" + $scope.activeStyle.type + "_buttons_" + styleBtnCnt + "_color_1.png";
                        $scope.actStyleJKArr['threads'] = basePath + "media/jacket_images/threads/" + currentThreadsId + "_threads_" + $scope.activeStyle.type + "_btn_" + styleBtnCnt + "_view_1.png";
                        $scope.actStyleJKArr['collarstyle'] = basePath + "media/jacket_images/collar/" + $scope.fabricId + "_collarstyle_" + $scope.activeStyle.id + "_view_3.png";
                        $scope.actStyleJKArr['vestcollar'] = basePath + "media/vest_images/vestlining/" + $scope.fabricId + "_vestcollar_view_3.png";
                    }

                } else if ($scope.activeStyle.type == "2") {

                    styleBtnCnt = angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") : "2";
                    angular.element(".theView").find('.shirt_part[rel=Tie]').show();
                    image.src = basePath + "media/jacket_images/buttons/" + $scope.activeStyle.type + "_buttons_" + styleBtnCnt + "_color_1.png";
                    if (image.width == 0) {

                        angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount", "2");
                        $scope.actStyleJKArr['buttons'] = basePath + "media/jacket_images/buttons/2_buttons_2_color_1.png";
                        $scope.actStyleJKArr['threads'] = basePath + "media/jacket_images/threads/" + currentThreadsId + "_threads_4_btn_2_view_1.png";
                        $scope.actStyleJKArr['collarstyle'] = basePath + "media/jacket_images/collar/" + $scope.fabricId + "_collarstyle_" + $scope.activeStyle.id + "_view_3.png";
                        $scope.actStyleJKArr['vestcollar'] = basePath + "media/vest_images/vestlining/" + $scope.fabricId + "_vestcollar_view_3.png";
                        $scope.actStyleJKArr['lining'] = basePath + "media/jacket_images/lining/1_liningstyle_" + $scope.activeStyle.id + "_view_3.png";
                    } else {

                        $scope.actStyleJKArr['buttons'] = basePath + "media/jacket_images/buttons/2_buttons_" + styleBtnCnt + "_color_1.png";
                        $scope.actStyleJKArr['threads'] = basePath + "media/jacket_images/threads/" + currentThreadsId + "_threads_4_btn_" + styleBtnCnt + "_view_1.png";
                    }


                } else {//Mandarin
                    styleBtnCnt = "5";
                    angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount", "5");
                    $scope.actStyleJKArr['buttons'] = basePath + "media/jacket_images/buttons/3_buttons_" + styleBtnCnt + "_color_1.png";
                    $scope.actStyleJKArr['threads'] = basePath + "media/jacket_images/threads/" + currentThreadsId + "_threads_7_btn_" + styleBtnCnt + "_view_1.png";
                    $scope.actStyleJKArr['collarstyle'] = basePath + "media/jacket_images/collar/" + $scope.fabricId + "_collarstyle_" + $scope.activeStyle.id + "_view_3.png";
                    $scope.actStyleJKArr['vestcollar'] = basePath + "media/vest_images/vestlining/" + $scope.fabricId + "_vestcollar_view_3.png";
                    $scope.actStyleJKArr['lining'] = basePath + "media/jacket_images/lining/1_liningstyle_" + $scope.activeStyle.id + "_view_3.png";
                }
                ///update style buttons


                $scope.styleBtnCnt = styleBtnCnt;
                $scope.styleBtnType = styleTypeId;


                if ($scope.activeView == 3)
                {
                    //$scope.activeView = 1;

                    $scope.actStyleJKArr['Lapel'] = basePath + "media/jacket_images/lapel/" + $scope.fabricId + "_lapelstyle_" + styleId + "_size_" + LapelSizeId + "_lapeltype_" + LapelTypeId + "_view_1.png";
                } else {


                    $scope.actStyleJKArr['Lapel'] = basePath + "media/jacket_images/lapel/" + $scope.fabricId + "_lapelstyle_" + styleId + "_size_" + LapelSizeId + "_lapeltype_" + LapelTypeId + "_view_1.png";
                }




                //back image
                if (styleName != "Mandarin")
                {

                    jQuery("#mainImageHolder").find("[rel=Lapel]").show();
                    jQuery("#div1").find("[target=3]").parent().show();
                    $scope.actStyleJKArr['BackStyle'] = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_1_view_2.png";
                } else {

                    setTimeout(function () {
                        jQuery("#div1").find("[target=3]").parent().hide();
                        jQuery("#mainImageHolder").find("[rel=Lapel]").hide();
                    }, 100);
                }

                dispStyleBtn(styleId);
            }


            if ($scope.activeView == 3)
            {

                styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
            } else {

                styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_" + $scope.activeView + ".png";
            }



        }




        if (styleType == "jacket")
        {
            if (parent == "Lapel")
            {
                var LapelActSize = angular.element("#lapelSize").find(".activeDesign .ng-binding:first").text().trim() ? angular.element("#lapelSize").find(".activeDesign .ng-binding:first").text().trim() : angular.element("#lapelSize").find("li:first .ng-binding:first").text().trim();
                styleName = angular.element("#lapelSize").parent().find("ul:first").find(".activeDesign .ng-binding:first").text().trim();
                $scope.actStyleJKArr[parent + "_styleName"] = styleName + "_" + LapelActSize;
            } else {
                $scope.actStyleJKArr[parent + '_styleName'] = styleName;
            }

            $scope.actStyleJKArr[parent] = styleImg;
            $scope.actStyleJKArr[parent + "_index"] = ind;
            $scope.actStyleJKArr[parent + '_id'] = styleId;
            $scope.actStyleJKArr[parent + '_btnCount'] = $scope.activeStyle.btn_count;
            $scope.actStyleJKArr[parent + '_icon'] = icon;


        } else if (styleType == "pant") {

            $scope.actStylePantArr[parent] = styleImg;
            $scope.actStylePantArr[parent + "_index"] = ind;
            $scope.actStylePantArr[parent + '_styleName'] = styleName;
            $scope.actStylePantArr[parent + '_id'] = styleId;
            $scope.actStylePantArr[parent + '_icon'] = icon;
        } else if (styleType == "vest") {

            $scope.actStyleVestArr[parent] = styleImg;
            $scope.actStyleVestArr[parent + "_index"] = ind;
            $scope.actStyleVestArr[parent + '_styleName'] = styleName;
            $scope.actStyleVestArr[parent + '_id'] = styleId;
            $scope.actStyleVestArr[parent + '_btnCount'] = $scope.activeStyle.btn_count;
            $scope.actStyleVestArr[parent + '_icon'] = icon;
        }




        updatePrice();
        updateProduct();
        hideJacket();
        imageLoaded();
    }

    //change Accent of Suit 
    $scope.accentClick = function ($event, obj, ind) {

        angular.element(".suit-preloader").show();
        angular.element(".mainToolarea").css({"opacity": "0"});
        var parent, styleImg, styleType, styleName, styleId;

        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass("activeDesign");
        angular.element($event.currentTarget).addClass("activeDesign");

        if (jQuery(window).width() <= 767) {
            jQuery("body").removeClass("LeftpanemOpen")
            jQuery(".leftpanelsection").css("left", "0");
        }

        $scope.activeStyle = obj;
        currStyleName = parent = $scope.activeStyle.parent.replace(/\s+|&/g, "");
        styleName = $scope.activeStyle.name.replace(/\s+|&/g, "");
        styleId = $scope.activeStyle.id;

        var liningCurrentId;



        if (parent == "lining")
        {
            var liningCurrentId = angular.element($event.currentTarget).attr("id");
            linid_active_id = liningCurrentId;
        }


        if ($scope.activeStyle.price) {
            stylePriceArr[parent] = $scope.activeStyle.price;
        } else {
            stylePriceArr[parent] = "0.0";
        }




        //get style type single or double
        styleType = $scope.activeStyle.designType; //angular.element("#view" + $scope.activeView).find('.shirt_part[rel=' + parent + ']').attr("type");

        var styleTypeId = angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") : "1";

        if (parent == "brassbuttons")
        {
            var styleBtnCount = angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") : "1";
            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + styleTypeId + "_" + parent.toLowerCase() + "_" + styleBtnCount + "_color_" + styleId + ".png";
            parent = "buttons";
        } else if (parent == "threads")
        {
            var styleBtnCount = angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") : "1";
            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + styleId + "_" + parent.toLowerCase() + "_" + styleTypeId + "_btn_" + styleBtnCount + "_view_1.png";
            currentThreadsId = styleId
        } else if (parent == "pocketsquare")
        {

            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + styleId + "_" + parent.toLowerCase() + ".png";
        } else if (parent == "lining")
        {


            if (styleTypeId == "1") {

                styleImg = basePath + "media/jacket_images/lining/" + liningCurrentId + "_liningstyle_1_view_3.png";

            } else if (styleTypeId == "4") {


                styleImg = basePath + "media/jacket_images/lining/" + liningCurrentId + "_liningstyle_4_view_3.png";
            }



            $scope.actStyleJKArr['vestlining'] = basePath + "media/vest_images/vestlining/" + liningCurrentId + "_vestlining_view_3.png";
            $scope.actStyleJKArr['jacketlining'] = basePath + "media/vest_images/vestlining/" + liningCurrentId + "_vestlining_view_3.png";
        } else if (parent == "backcollar") {
            styleId = angular.element('#divaccent_5 ul:first').find('.activeDesign').attr('id') ? angular.element('#divaccent_5 ul:first').find('.activeDesign').attr('id') : "1";

            if (styleId == 2)
            {
                angular.element('#divaccent_5 ul.BackCollar').css("display", "block");
                styleImg = $scope.actStyleJKArr['backcollar'] = basePath + "media/jacket_images/back_collar/" + $scope.backcollfabId + "_backCollar_view_2.png";
            } else
            {
                angular.element('#divaccent_5 ul.BackCollar').css("display", "none");
                styleImg = $scope.actStyleJKArr['backcollar'] = basePath + "media/default_tool_img/blank.png";
            }
        } else if (parent == "elbowpatches") {

            styleId = angular.element('#divaccent_6 ul:first').find('.activeDesign').attr('id') ? angular.element('#divaccent_6 ul:first').find('.activeDesign').attr('id') : "1";
            if (styleId == 2)
            {
                angular.element('#divaccent_6 ul.ElbowPatch').css("display", "block");
                styleImg = $scope.actStyleJKArr['backelbow'] = basePath + "media/jacket_images/elbow_patches/" + $scope.backelbofabId + "_elbowPatches_view_2.png";
            } else
            {
                angular.element('#divaccent_6 ul.ElbowPatch').css("display", "none");
                styleImg = $scope.actStyleJKArr['backelbow'] = basePath + "media/default_tool_img/blank.png";
            }
        }







        //check style
        if (styleTypeId == "3")//Mandarin
        {

            angular.element(".theView").find('.shirt_part[rel=Lapel]').hide();
        } else {



            angular.element(".theView").find('.shirt_part[rel=Lapel]').show();
        }


        if (parent == "elbowpatches" || parent == "elbowpatches")
        {

        } else {
            if (styleType == "jacket")
            {

                $scope.actStyleJKArr[parent] = styleImg;
                $scope.actStyleJKArr[parent + "_index"] = ind;
                $scope.actStyleJKArr[parent + '_styleName'] = styleName;
                $scope.actStyleJKArr[parent + '_id'] = styleId;


            } else if (styleType == "pant") {

                $scope.actStylePantArr[parent] = styleImg;
                $scope.actStylePantArr[parent + "_index"] = ind;
                $scope.actStylePantArr[parent + '_styleName'] = styleName;
                $scope.actStylePantArr[parent + '_id'] = styleId;

            } else if (styleType == "vest") {

                $scope.actStyleVestArr[parent] = styleImg;
                $scope.actStyleVestArr[parent + "_index"] = ind;
                $scope.actStyleVestArr[parent + '_styleName'] = styleName;
                $scope.actStyleVestArr[parent + '_id'] = styleId;
            }
        }

        updatePrice();
        updateProduct();
        hideJacket();
        imageLoaded();
    }

    /*code for back collar*/
    $scope.changebackcolfab = function ($event, fabric) {

        var styleImg, styleId;




        currStyleName = "fabric";

        angular.element(".suit-preloader").show();
        angular.element(".mainToolarea").css({"opacity": "0"});

        angular.element($event.currentTarget).parent().find(".activeDesign").removeClass('activeDesign');
        angular.element($event.currentTarget).find(".fabvie").addClass("activeDesign");
        var parent;

        if ($scope.actCatName == "BackCollar") {
            parent = "backcollar";

            $scope.backcollfabId = angular.element($event.currentTarget).attr("id");


            styleId = angular.element('#divaccent_5 ul > li.activeDesign').attr('id') ? angular.element('#divaccent_5 ul > li.activeDesign').attr('id') : "1";

            if (styleId == 2)
            {

                styleImg = $scope.actStyleJKArr['backcollar'] = basePath + "media/jacket_images/back_collar/" + $scope.backcollfabId + "_backCollar_view_2.png";
            } else
            {

                styleImg = $scope.actStyleJKArr['backcollar'] = basePath + "media/default_tool_img/blank.png";
            }
        } else if ($scope.actCatName == "ElbowPatch") {

            parent = "backelbow";

            $scope.backelbofabId = angular.element($event.currentTarget).attr("id");
            styleId = angular.element('#divaccent_6 ul > li.activeDesign').attr('id') ? angular.element('#divaccent_6 ul > li.activeDesign').attr('id') : "1";


            if (styleId == 2)
            {

                styleImg = $scope.actStyleJKArr['backelbow'] = basePath + "media/jacket_images/elbow_patches/" + $scope.backelbofabId + "_elbowPatches_view_2.png";
            } else
            {

                styleImg = $scope.actStyleJKArr['backelbow'] = basePath + "media/default_tool_img/blank.png";
            }
        }



        $scope.actStyleJKArr[parent] = styleImg;
        $scope.actStyleJKArr[parent + '_styleName'] = fabric.name;




        updateProduct();
        updatePrice();

        angular.element(".suit-preloader").hide();
        angular.element(".mainToolarea").css({"opacity": "1"});

    };


    /*code for back collar ends here*/


    function dispStyleBtn(styleId)
    {

        jQuery("#divs_7 li").each(function () {

            if (jQuery(this).attr("style_id") == styleId) {
                jQuery(this).show();
            } else {
                jQuery(this).hide();
            }
        });
        jQuery("#divvest_7 li").each(function () {

            if (jQuery(this).attr("style_id") == styleId) {
                jQuery(this).show();
            } else {
                jQuery(this).hide();
            }
        });
    }

    function updateProduct()
    {

        //check this use view id dynamic
        jQuery("#view1 img").each(function () {

            var parent = jQuery(this).attr('rel');
            var type = jQuery(this).attr('type');

            if (type == "jacket")
            {
                if ($scope.actStyleJKArr[parent])
                {

                    jQuery(this).attr('src', $scope.actStyleJKArr[parent]);
                    jQuery(this).attr("index", $scope.actStyleJKArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStyleJKArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStyleJKArr[parent + '_id']);
                    jQuery(this).attr('btnCount', $scope.actStyleJKArr[parent + '_btnCount']);
                    jQuery(this).attr('label', $scope.actStyleJKArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStyleJKArr[parent + '_icon']);

                }



            } else if (type == "pant") {
                if ($scope.actStylePantArr[parent])
                {
                    jQuery(this).attr('src', $scope.actStylePantArr[parent]);
                    jQuery(this).attr("index", $scope.actStylePantArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStylePantArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStylePantArr[parent + '_id']);
                    jQuery(this).attr('label', $scope.actStylePantArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStylePantArr[parent + '_icon']);
                }

            } else if (type == "vest") {

                if ($scope.actStyleVestArr[parent])
                {
                    jQuery(this).attr('src', $scope.actStyleVestArr[parent]);
                    jQuery(this).attr("index", $scope.actStyleVestArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStyleVestArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStyleVestArr[parent + '_id']);
                    jQuery(this).attr('btnCount', $scope.actStyleVestArr[parent + '_btnCount']);
                    jQuery(this).attr('label', $scope.actStyleVestArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStyleVestArr[parent + '_icon']);
                }



            }

        });
        jQuery("#view2 img").each(function () {

            var parent = jQuery(this).attr('rel');
            var type = jQuery(this).attr('type');

            if (type == "jacket")
            {
                if ($scope.actStyleJKArr[parent])
                {

                    jQuery(this).attr('src', $scope.actStyleJKArr[parent]);
                    jQuery(this).attr("index", $scope.actStyleJKArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStyleJKArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStyleJKArr[parent + '_id']);
                    jQuery(this).attr('label', $scope.actStyleJKArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStyleJKArr[parent + '_icon']);
                }

            } else if (type == "pant") {

                if ($scope.actStylePantArr[parent])
                {
                    jQuery(this).attr('src', $scope.actStylePantArr[parent]);
                    jQuery(this).attr("index", $scope.actStylePantArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStylePantArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStylePantArr[parent + '_id']);
                    jQuery(this).attr('label', $scope.actStylePantArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStylePantArr[parent + '_icon']);
                }
            } else if (type == "vest") {
                if ($scope.actStyleVestArr[parent])
                {

                    jQuery(this).attr('src', $scope.actStyleVestArr[parent]);
                    jQuery(this).attr("index", $scope.actStyleVestArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStyleVestArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStyleVestArr[parent + '_id']);
                    jQuery(this).attr('label', $scope.actStyleVestArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStyleVestArr[parent + '_icon']);
                }
            }




        });
        //check this use view id dynamic
        jQuery("#view3 img").each(function () {

            var parent = jQuery(this).attr('rel');
            var type = jQuery(this).attr('type');
            if (type == "jacket")
            {
                if ($scope.actStyleJKArr[parent])
                {

                    jQuery(this).attr('src', $scope.actStyleJKArr[parent]);
                    jQuery(this).attr("index", $scope.actStyleJKArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStyleJKArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStyleJKArr[parent + '_id']);
                    jQuery(this).attr('btnCount', $scope.actStyleJKArr[parent + '_btnCount']);
                    jQuery(this).attr('label', $scope.actStyleJKArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStyleJKArr[parent + '_icon']);



                }

            } else if (type == "pant") {
                if ($scope.actStylePantArr[parent])
                {
                    jQuery(this).attr('src', $scope.actStylePantArr[parent]);
                    jQuery(this).attr("index", $scope.actStylePantArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStylePantArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStylePantArr[parent + '_id']);
                    jQuery(this).attr('label', $scope.actStylePantArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStylePantArr[parent + '_icon']);
                }
            } else if (type == "vest") {
                if ($scope.actStyleVestArr[parent])
                {
                    jQuery(this).attr('src', $scope.actStyleVestArr[parent]);
                    jQuery(this).attr("index", $scope.actStyleVestArr[parent + "_index"]);
                    jQuery(this).attr('name', $scope.actStyleVestArr[parent + '_styleName']);
                    jQuery(this).attr('id', $scope.actStyleVestArr[parent + '_id']);
                    jQuery(this).attr('label', $scope.actStyleVestArr[parent + '_label']);
                    jQuery(this).attr('icon', $scope.actStyleVestArr[parent + '_icon']);
                }
            }

        });
    }


//load fabric for suit
    $scope.fabricClick = function ($event, obj) {
        //hide default image
        angular.element("#view1").find('.shirt_part[rel=ViewStatic]').hide();

        currStyleName = "fabric";

        angular.element(".suit-preloader").show();
        angular.element(".mainToolarea").css({"opacity": "0"});

        angular.element("#div4").find(".activeDesign").removeClass('activeDesign');
        angular.element($event.currentTarget).find(".fabvie").addClass("activeDesign");



        fabricId = $scope.fabricId = obj.id;
        $scope.fabricName = obj.name;
        $scope.fabricBtnId = obj.button_color ? obj.button_color : "1";
        $scope.tieColorId = obj.tie_color ? obj.tie_color : "1";
        $scope.shoesColorId = obj.shoes_color ? obj.shoes_color : "1";




        //update fabric preview image
        var fabricVal = angular.element($event.currentTarget).find("img").attr("data-zoom-image");
        angular.element('#slide').attr('src', fabricVal);

        angular.element('.fabricName').html(obj.name);
        angular.element('.fabricType').html(obj.type);
        angular.element('.fabricPrice').html(obj.price);

        //for responsive
        if (jQuery(window).width() <= 767) {
            jQuery("body").removeClass("LeftpanemOpen")
            jQuery(".leftpanelsection").css("left", "0");
        }



        applyFabricOnSuit();
        updatePrice();


    }

    function updateTieButtonShoes()
    {

        angular.element("#view1").find('.shirt_part[rel=Tie]').attr('src', basePath + "media/jacket_images/tie_images/tie_color_" + $scope.tieColorId + ".png");


        angular.element("#view1").find('.shirt_part[rel=ManShoes]').attr('src', basePath + "media/jacket_images/shoes_images/shoes_color_" + $scope.shoesColorId + "_view_1.png");
        angular.element("#view2").find('.shirt_part[rel=ManShoes]').attr('src', basePath + "media/jacket_images/shoes_images/shoes_color_" + $scope.shoesColorId + "_view_2.png");

        angular.element("#view1").find('.shirt_part[rel=ManShoes]').attr("name", $scope.shoesColorId);
        angular.element("#view1").find('.shirt_part[rel=ButtonsColor]').attr("name", $scope.fabricBtnId);
        angular.element("#view1").find('.shirt_part[rel=Tie]').attr("name", $scope.tieColorId);

        //style button
        angular.element("#view1").find('.shirt_part[rel=buttons]').attr('src', basePath + "media/jacket_images/buttons/" + $scope.styleBtnType + "_buttons_" + $scope.styleBtnCnt + "_color_" + $scope.fabricBtnId + ".png");
        angular.element("#view2").find('.shirt_part[rel=sleeve_buttons]').attr('src', basePath + "media/jacket_images/sleeve_buttons/" + $scope.sleeveBtnCnt + "_color_" + $scope.fabricBtnId + ".png");

        /*jQuery().attr('src', $scope.actStyleJKArr[parent]);
         jQuery(this).attr("index", $scope.actStyleJKArr[parent + "_index"]);
         jQuery(this).attr('name', $scope.actStyleJKArr[parent + '_styleName']);
         jQuery(this).attr('id', $scope.actStyleJKArr[parent + '_id']);
         jQuery(this).attr('label', $scope.actStyleJKArr[parent + '_label']);*/
    }







    $scope.changeView = function ($event, viewId) {

        angular.element(".suit-preloader").show();
        angular.element(".mainToolarea").css({"opacity": "0"});
        /*$scope.activeView = viewId;
         //remove active and add active to current obj
         angular.element(".view-thumb button").removeClass("active");
         angular.element($event.currentTarget).addClass("active");*/

        $scope.activeView = viewId;
        changeView();
    }

    $scope.changePart = function ($event) {
        console.log($scope.partOption)
    }




    /*
     * load data static way
     $scope.fabricData = fabricService.getFabricData();
     */

    /*
     * load data dynamic way
     $scope.fabricData = fabricService.getFabricData();
     */
    //get fabric data
    var handleSuccessFabric = function (data, status) {

        if (data)
        {
            //for clone data
            var strData = JSON.stringify(data);
            $scope.fabricData = JSON.parse(strData);

            tempPj = JSON.parse(strData);

            $scope.backColElboFabricData = tempPj.fabric;

            //call designData
            designService.getDesignData().success(handleSuccessDesign).error(function (data, status) {
                console.log(status);
            });
        } else {
            console.log(data.error);
        }
    }

//    console.log("in dddd")
    fabricService.getFabricData().success(handleSuccessFabric).error(function (data, status) {
        console.log(status);
    });
    //get design data
    var handleSuccessDesign = function (data, status) {

        if (data)
        {
            $scope.designData = data;
            tempJk = $scope.designData;

            //call vest data
            vestService.getVestData().success(handleSuccessVest).error(function (data, status) {
                console.log(status);
            });
        } else {
            console.log(data.error);
        }
    }


    //load suit vest data
    var handleSuccessVest = function (data, status) {

        if (data)
        {
            $scope.vestData = data;
            tempVst = data;

            //call pant data
            // $scope.pantData = pantService.getPantsData();
            pantService.getPantsData().success(handleSuccessPant).error(function (data, status) {
                console.log(status);
            });
        } else {
            console.log(data.error);
        }
    }


    //load suit vest data
    var handleSuccessPant = function (data, status) {

        if (data)
        {
            $scope.pantData = data;
            tempPt = data;

            //call accent data
            suitAccentService.getSuitAccentData().success(handleSuccessSuitAccent).error(function (data, status) {
                console.log(status);
            });
        } else {
            console.log(data.error);
        }
    }

//    //load suit vest data
//    var handleSuccessTopcoat = function (data, status) {
//
//        if (data)
//        {
//            $scope.topCoat = data;
//            temptopCoat = data;
//
//            //call pant data
//            // $scope.pantData = pantService.getPantsData();
//            topCoatService.gettopCoatData().success(handleSuccessTopcoat).error(function (data, status) {
//                console.log(status);
//            });
//
//        } else {
//            console.log(data.error);
//        }
//    }

    $scope.topCoat = topCoatService.gettopCoatData()

    //load suit vest data
    var handleSuccessSuitAccent = function (data, status) {

        if (data)
        {
            $scope.suitAccentData = data;
            tempAccnt = data;



            applyFabricOnSuitInit();
            updatePrice();

        } else {
            console.log(data.error);
        }
    }


    function applyFabricOnSuit()
    {


        var first = tempJk;
        var second = tempPt;
        var third = tempVst;
        var forth = tempAccnt;
        var data = jQuery.merge(jQuery.merge([], first), second);
        var data1 = jQuery.merge(jQuery.merge([], data), third);
        var suitDesignData = jQuery.merge(jQuery.merge([], data1), forth);
        var parent, styleImg, styleType, styleName, styleId, labelName;

        $scope.allDesignStyles = "";

        var styleCnt = "0";
        for (var design in suitDesignData)
        {
            if (suitDesignData.hasOwnProperty(design))
            {
                $scope.allDesignStyles = suitDesignData[design]["style"][0];
                if ($scope.allDesignStyles)
                {
                    var designType = $scope.allDesignStyles.designType;
                    if ($scope.partOption == designType || $scope.partOption == 'all')
                    {

                        if ($scope.partOption == "jacket")
                        {
                            jacketFabricId = $scope.fabricId;
                            jacketFabricName = $scope.fabricName;
                        } else if ($scope.partOption == "pant")
                        {
                            pantFabricId = $scope.fabricId;
                            pantFabricName = $scope.fabricName;
                        } else if ($scope.partOption == "vest")
                        {
                            vestFabricId = $scope.fabricId;
                            vestFabricName = $scope.fabricName;

                        } else {
                            vestFabricId = $scope.fabricId;
                            pantFabricId = $scope.fabricId;
                            jacketFabricId = $scope.fabricId;

                            jacketFabricName = $scope.fabricName;
                            pantFabricName = $scope.fabricName;
                            vestFabricName = $scope.fabricName;
                        }


                        if (!$scope.allDesignStyles.parent)
                        {
                            continue;
                        }


                        parent = $scope.allDesignStyles.parent.replace(/\s+|&/g, "");
                        styleName = $scope.allDesignStyles.name.replace(/\s+|&/g, "");
                        labelName = $scope.allDesignStyles.parent;
                        styleId = $scope.allDesignStyles.id;

                        //check style
                        if (styleName == "Mandarin" || styleId == "7")
                        {
                            angular.element(".theView").find('.shirt_part[rel=Lapel]').hide();
                        } else {
                            angular.element(".theView").find('.shirt_part[rel=Lapel]').show();
                        }


                        //get style type single or double
                        styleType = $scope.allDesignStyles.designType; //angular.element("#view" + $scope.activeView).find('.shirt_part[rel=' + parent + ']').attr("type");


                        if ($scope.actStyleData[parent]) {
                            styleId = $scope.actStyleData[parent];
                        }

                        if (parent == "Fit")
                        {
                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + parent.toLowerCase() + "_" + styleId + ".png";
                        } else if (parent == "Lapel")
                        {
                            var styleTypeId = ($scope.actStyleData["Style"]) ? $scope.actStyleData["Style"] : "1";
                            var LapelTypeId = ($scope.actStyleData["Lapel"]) ? $scope.actStyleData["Lapel"] : "1";
                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "style_" + styleTypeId + "_size_" + styleId + "_" + parent.toLowerCase() + "type_" + LapelTypeId + "_view_1.png";
                        } else if (parent == "Vents")
                        {
                            styleImg = $scope.allDesignStyles.main_img;
                        } else if (parent == "sleeve_buttons")
                        {
                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.allDesignStyles.btn_count + "_color_1.png";
                        } else if (parent == "buttons")
                        {
                            var styleTypeId = ($scope.actStyleData["Style"]) ? $scope.actStyleData["Style"] : "1";
                            if (styleTypeId == "3")
                            {
                                styleId = "5";
                            } else if (styleTypeId == "2") {
                                styleId = "2";
                            } else {
                                styleId = "1";
                            }

                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + styleTypeId + "_" + parent.toLowerCase() + "_" + styleId + "_color_1.png";
                        } else if (parent == "vestbuttons")
                        {

                            styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/1_buttons_3_color_1.png";
                        } else if (parent == "pantfit")
                        {

                            $scope.actStylePantArr['pantfit_straight'] = basePath + "media/pant_images/pantfit/" + $scope.fabricId + "_pantfit_straight_1_view_3.png";
                            $scope.actStylePantArr['pantfit_tilt'] = basePath + "media/pant_images/pantfit/" + $scope.fabricId + "_pantfit_tilt_1_view_3.png";
                            if (styleId == "2")
                            {

                                $scope.actStylePantArr['pantStyle'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/pantfit_2_view_1.png";
                                $scope.actStylePantArr['pantBackStyle'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/pantfit_2_view_2.png";
                            } else {

                                styleImg = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                                var styleImg1 = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_2.png";
                                $scope.actStylePantArr['pantStyle'] = basePath + "media/default_tool_img/blank.png";
                                $scope.actStylePantArr['pantBackStyle'] = basePath + "media/default_tool_img/blank.png";
                                $scope.actStylePantArr['backpantfit'] = styleImg1;
                            }



                        } else if (parent == "pantpleats")
                        {

                            styleImg = basePath + "media/default_tool_img/blank.png";
                            $scope.actStylePantArr['foldPantPleats'] = styleImg;
                            $scope.actStylePantArr['pantpleats'] = styleImg;
                            $scope.actStylePantArr['Pleats'] = styleImg;
                        } else if (parent == "pantcuff")
                        {
                            if (jQuery("#divpant_5").find(".activeDesign").attr("id") == "2") {

                                styleImg = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_2_view_1.png"; //" + styleId + "
                                angular.element("#view1 .shirt_part[rel='pantcuff']").attr("src", styleImg)
                                $scope.actStylePantArr['pantcuff'] = styleImg;
                                $scope.actStylePantArr['backpantcuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_2_view_2.png";
                                $scope.actStylePantArr['pantFoldCuff'] = basePath + "media/pant_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_2_view_3.png";
                            } else
                            {

                                styleImg = basePath + "media/default_tool_img/blank.png";
                                $scope.actStylePantArr['backpantcuff'] = styleImg;
                                $scope.actStylePantArr['pantFoldCuff'] = styleImg;
                                $scope.actStylePantArr['pantcuff'] = styleImg;
                            }



                            //pantFoldCuff

                        } else if (parent == "fastening" || parent == "pantpockets")
                        {
                            styleImg = $scope.allDesignStyles.main_img;
                        } else if (parent == "veststyle" || parent == "vestedge")
                        {

                            if (parent == "vestedge")
                            {
                                var vestStyleId = angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";
                                var vestEdgeId = styleId; //angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") : "1";



                                styleImg = basePath + "media/default_tool_img/blank.png";
                                $scope.actStyleVestArr['veststyle'] = basePath + "media/vest_images/veststyle/" + $scope.fabricId + "_style_" + vestEdgeId + "_bottom_" + vestStyleId + "_view_1.png";
                            } else {
                                var vestStyleId = styleId; //angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";
                                var vestEdgeId = angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=vestedge]').attr("id") : "1";
                                styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_1.png";
                                $scope.actStyleVestArr['veststyle'] = styleImg;
                                $scope.actStyleVestArr['backveststyle'] = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_bottom_" + vestEdgeId + "_view_2.png";
                                dispStyleBtn(styleId);
                            }




                        } else if (parent == "vestlapel")
                        {
                            var vestStyleId = styleId; //angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=veststyle]').attr("id") : "1";

                            var vestLapelId = angular.element("#view1").find('.shirt_part[rel=vestlapel]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=vestlapel]').attr("id") : "1";
                            styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_style_" + vestStyleId + "_lapel_" + vestLapelId + "_view_1.png";
                        } else if (parent == "vestpockets" || parent == "breastpocket")
                        {
                            if (parent == "breastpocket")
                            {

                                if (styleId == "2")
                                {
                                    styleImg = basePath + "media/default_tool_img/blank.png";
                                } else
                                {
                                    styleImg = basePath + "media/vest_images/vestpockets/" + $scope.fabricId + "_" + parent.toLowerCase() + "_view_1.png";
                                }
                            } else
                            {
                                styleImg = basePath + "media/vest_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                            }


                        } /*else if (parent == "brassbuttons")
                         {
                         var styleBtnCount = angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("btnCount") : "1";
                         
                         styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + styleTypeId + "_" + parent.toLowerCase() + "_" + styleBtnCount + "_color_" + styleId + ".png";
                         parent = "buttons";
                         
                         }*/ else if (parent == "threads")
                        {
                            var styleTypeId = ($scope.actStyleData["Style"]) ? $scope.actStyleData["Style"] : "1";

                            if (styleTypeId == "3")
                            {
                                styleId = "5";
                            } else if (styleTypeId == "2") {
                                styleId = "2";
                            } else {
                                styleId = "1";
                            }

                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/1_" + parent.toLowerCase() + "_" + styleTypeId + "_btn_" + styleId + "_view_1.png";


                        } else if (parent == "pocketsquare")
                        {

                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/1_" + parent.toLowerCase() + ".png";
                        } else if (parent == "lining")
                        {
                            var styleTypeId = angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") : "1";
                            if ($scope.activeView == 3) {

                                if (styleTypeId == "1") {

                                    styleImg = basePath + "media/jacket_images/lining/" + linid_active_id + "_liningstyle_1_view_3.png";
                                } else if (styleTypeId == "4") {

                                    styleImg = basePath + "media/jacket_images/lining/1_liningstyle_4_view_3.png";
                                }
                            }






                        } else if (parent == "vestlining")
                        {

                            var styleTypeId = angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") ? angular.element("#view1").find('.shirt_part[rel=Style]').attr("id") : "1";
                            if (styleTypeId == "1") {

                                styleImg = basePath + "media/jacket_images/lining/1_liningstyle_1_view_3.png";
                            } else if (styleTypeId == "4") {

                                styleImg = basePath + "media/jacket_images/lining/1_liningstyle_4_view_3.png";
                            }
                        } else if (parent == "backcollar")
                        {

                            styleId = angular.element('#divaccent_5 ul > li.activeDesign').attr('id') ? angular.element('#divaccent_5 ul > li.activeDesign').attr('id') : "1";

                            if (styleId == 2)
                            {

                                styleImg = $scope.actStyleJKArr['backcollar'] = basePath + "media/jacket_images/back_collar/" + $scope.backcollfabId + "_backCollar_view_2.png";
                            } else
                            {

                                styleImg = $scope.actStyleJKArr['backcollar'] = basePath + "media/default_tool_img/blank.png";
                            }


                        } else if (parent == "elbowpatches") {


                            styleId = angular.element('#divaccent_6 ul > li.activeDesign').attr('id') ? angular.element('#divaccent_6 ul > li.activeDesign').attr('id') : "1";


                            if (styleId == 2)
                            {

                                styleImg = $scope.actStyleJKArr['backelbow'] = basePath + "media/jacket_images/elbow_patches/" + $scope.backelbofabId + "_elbowPatches_view_2.png";
                            } else
                            {

                                styleImg = $scope.actStyleJKArr['backelbow'] = basePath + "media/default_tool_img/blank.png";
                            }
                        } else
                        {

                            if (parent == "Style")//update Lapel design Style
                            {
                                var LapelTypeId = angular.element("#lapelSize").prev().prev().find(".activeDesign").attr("id") ? angular.element("#lapelSize").prev().prev().find(".activeDesign").attr("id") : "1";
                                var LapelSizeId = angular.element("#lapelSize").find(".activeDesign").attr("id") ? angular.element("#lapelSize").find(".activeDesign").attr("id") : "1";
                                $scope.actStyleJKArr['Lapel'] = basePath + "media/jacket_images/lapel/" + $scope.fabricId + "_lapelstyle_1_size_" + LapelSizeId + "_lapeltype_1_view_1.png";
                                $scope.actStyleJKArr['collarstyle'] = basePath + "media/jacket_images/collar/" + $scope.fabricId + "_collarstyle_1_view_3.png";
                                $scope.actStyleJKArr['vestcollar'] = basePath + "media/vest_images/vestlining/" + $scope.fabricId + "_vestcollar_view_3.png";
                                $scope.actStyleJKArr['pantfit_straight'] = basePath + "media/pant_images/pantfit/" + $scope.fabricId + "_pantfit_straight_1_view_3.png";
                                $scope.actStyleJKArr['pantfit_tilt'] = basePath + "media/pant_images/pantfit/" + $scope.fabricId + "_pantfit_tilt_1_view_3.png";
                                $scope.actStyleJKArr['lining'] = basePath + "media/jacket_images/lining/1_liningstyle_1_view_3.png";
                                //back image
                                $scope.actStyleJKArr['BackStyle'] = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_1_view_2.png";
                                dispStyleBtn(styleId);
                                dispStyleBtn(styleId);
                            }

                            styleImg = basePath + "media/jacket_images/" + parent.toLowerCase() + "/" + $scope.fabricId + "_" + parent.toLowerCase() + "_" + styleId + "_view_1.png";
                        }


                        var designStyleId = suitDesignData[design].id;
                        if (styleType == "jacket")
                        {


                            var hClass = jQuery("#divs_" + designStyleId + " li").hasClass("activeDesign");
                            if (!hClass)
                            {
                                jQuery("#divs_" + designStyleId + " li:first").addClass("activeDesign");
                            }


                            $scope.actStyleJKArr[parent] = styleImg;
//                        $scope.actStyleJKArr[parent + "_index"] = ind;
                            $scope.actStyleJKArr[parent + '_styleName'] = styleName;
                            $scope.actStyleJKArr[parent + '_id'] = styleId;
                            $scope.actStyleJKArr[parent + '_btnCount'] = $scope.allDesignStyles.btn_count;
                            $scope.actStyleJKArr[parent + '_label'] = labelName;

                        } else if (styleType == "pant") {

                            /* if (jQuery("#mCSB_14_container").children().children().hasClass("activeDesign") == true) {
                             } else {
                             jQuery("#divpant_" + designStyleId + " li:first").addClass("activeDesign");
                             }*/




                            var hClass = jQuery("#divpant_" + designStyleId + " li").hasClass("activeDesign");
                            if (!hClass)
                            {
                                jQuery("#divpant_" + designStyleId + " li:first").addClass("activeDesign");
                            }


                            $scope.actStylePantArr[parent] = styleImg;
//                        $scope.actStylePantArr[parent + "_index"] = ind;
                            $scope.actStylePantArr[parent + '_styleName'] = styleName;
                            $scope.actStylePantArr[parent + '_id'] = styleId;
                            $scope.actStylePantArr[parent + '_label'] = labelName;
                        } else if (styleType == "vest") {


                            var hClass = jQuery("#divvest_" + designStyleId + " li").hasClass("activeDesign");
                            if (!hClass)
                            {
                                jQuery("#divvest_" + designStyleId + " li:first").addClass("activeDesign");
                            }


                            $scope.actStyleVestArr[parent] = styleImg;
//                    $scope.actStyleVestArr[parent + "_index"] = ind;
                            $scope.actStyleVestArr[parent + '_styleName'] = styleName;
                            $scope.actStyleVestArr[parent + '_id'] = styleId;
                            $scope.actStyleVestArr[parent + '_btnCount'] = $scope.allDesignStyles.btn_count;
                            $scope.actStyleVestArr[parent + '_label'] = labelName;
                        }

                    }
                }
            }
        }


        updateProduct();
        hideJacket();
        imageLoaded();
        updateTieButtonShoes();
    }

    function applyFabricOnSuitInit()
    {
        var first = tempJk;
        var second = tempPt;
        var third = tempVst;
        var forth = tempAccnt;

        var data = jQuery.merge(jQuery.merge([], first), second);
        var data1 = jQuery.merge(jQuery.merge([], data), third);
        var suitDesignData = jQuery.merge(jQuery.merge([], data1), forth);
        var parent, styleImg, styleType, styleName, styleId, labelName;

        $scope.allDesignStyles = "";

        var styleCnt = "0";

        for (var design in suitDesignData)
        {
            if (suitDesignData.hasOwnProperty(design))
            {
                $scope.allDesignStyles = suitDesignData[design]["style"][0];
                if ($scope.allDesignStyles) {

                    if (!$scope.allDesignStyles.parent)
                    {
                        continue;
                    }


                    parent = $scope.allDesignStyles.parent.replace(/\s+|&/g, "");
                    styleName = $scope.allDesignStyles.name.replace(/\s+|&/g, "");
                    labelName = $scope.allDesignStyles.parent;
                    styleId = $scope.allDesignStyles.id;
                    if ($scope.allDesignStyles.price) {
                        stylePriceArr[parent] = $scope.allDesignStyles.price;
                    } else {
                        stylePriceArr[parent] = "0.0";
                    }


                    //get style type single or double
                    styleType = $scope.allDesignStyles.designType;
                    if ($scope.actStyleData[parent]) {
                        styleId = $scope.actStyleData[parent];
                    }

                    var designStyleId = suitDesignData[design].id;
                    var designStyleId = suitDesignData[design].id;
                    //act fab end
                    var hClass = jQuery("#div4 .fabvie").hasClass("activeDesign");
                    if (!hClass)
                    {

                        jQuery("#div4 .fabvie:first").addClass("activeDesign");
                    }

                    //act fab end



                    if (styleType == "jacket")
                    {
                        var hClass = jQuery("#divs_" + designStyleId + " li").hasClass("activeDesign");
                        if (!hClass)
                        {
                            jQuery("#divs_" + designStyleId + " li:first").addClass("activeDesign");
                        }
                    } else if (styleType == "pant") {


                        var hClass = jQuery("#divpant_" + designStyleId + " li").hasClass("activeDesign");
                        if (!hClass)
                        {
                            jQuery("#divpant_" + designStyleId + " li:first").addClass("activeDesign");
                        }
                    } else if (styleType == "vest") {


                        var hClass = jQuery("#divvest_" + designStyleId + " li").hasClass("activeDesign");
                        if (!hClass)
                        {
                            jQuery("#divvest_" + designStyleId + " li:first").addClass("activeDesign");
                        }
                    }
                }
            }
        }


        currStyleName = "";

        imageLoaded();


        jQuery("#displayLargeImg").html('<img id="slide" src="' + basePath + 'media/fabric_images/01.png">');

        setTimeout(function () {
            jQuery("#divs_2 li:first").trigger("click");

            setTimeout(function () {

                jQuery("#divvest_1 li:first").trigger("click");

                setTimeout(function () {
                    console.log("in fabric loaded ");
                    angular.element("#view1").find('.shirt_part[rel=ViewStatic]').hide();
                    updateInItZoom();
                }, 2500);

            }, 200);
        }, 200);
    }



    function imageLoaded() {

        if (currStyleName == "fabric")
        {
            if ($scope.partOption == "all" || $scope.partOption == "jacket") {
                angular.element('.shirt_part[rel="Style"]').load(function () {
                    angular.element(".mainToolarea").fadeIn("slow", function (e) {
                        setTimeout(function () {
                            angular.element(".suit-preloader").hide();
                            angular.element(".mainToolarea").css({"opacity": "1"});
                            angular.element("#theInitialProgress").hide();
                            currStyleName = "";
                        }, 500);
                    });
                });
            } else if ($scope.partOption == "pant") {
                angular.element('.shirt_part[rel="pantStyle"]').load(function () {

                    angular.element(".mainToolarea").fadeIn("slow", function (e) {
                        setTimeout(function () {
                            angular.element(".suit-preloader").hide();
                            angular.element(".mainToolarea").css({"opacity": "1"});
                            angular.element("#theInitialProgress").hide();
                            currStyleName = "";
                        }, 500);
                    });
                });
            } else if ($scope.partOption == "vest") {
                angular.element('.shirt_part[rel="veststyle"]').load(function () {

                    angular.element(".mainToolarea").fadeIn("slow", function (e) {
                        setTimeout(function () {
                            angular.element(".suit-preloader").hide();
                            angular.element(".mainToolarea").css({"opacity": "1"});
                            angular.element("#theInitialProgress").hide();
                            currStyleName = "";
                        }, 500);
                    });
                });
            }



        } else if (currStyleName != "") {


            if (currStyleName == "Style")//threads
            {
                angular.element('.shirt_part[rel="Style"]').load(function () {

                    angular.element(".mainToolarea").fadeIn("slow", function (e) {
                        currStyleName = "";
                        setTimeout(function () {
                            //alert("in style")
                            angular.element(".suit-preloader").hide();
                            angular.element(".mainToolarea").css({"opacity": "1"});
                            angular.element("#theInitialProgress").hide();
                        }, 500);
                    });
                });
            } else if (currStyleName == "brassbuttons" || currStyleName == "buttons" || currStyleName == "threads" || currStyleName == "lining" || currStyleName == "pocketsquare" || currStyleName == "pantfit" || currStyleName == "BackCollar" || currStyleName == "backcollar" || currStyleName == "elbowpatches" || currStyleName == "ElbowPatch")//threads
            {


                setTimeout(function () {
                    currStyleName = "";
                    angular.element(".suit-preloader").hide();
                    angular.element(".mainToolarea").css({"opacity": "1"});
                    angular.element("#theInitialProgress").hide();
                }, 500);

            } else
            {

                angular.element('.shirt_part[rel="' + currStyleName + '"]').load(function () {

                    angular.element(".mainToolarea").fadeIn("slow", function (e) {
                        currStyleName = "";
                        setTimeout(function () {
                            angular.element(".suit-preloader").hide();
                            angular.element(".mainToolarea").css({"opacity": "1"});
                            angular.element("#theInitialProgress").hide();
                        }, 100);
                    });
                });
            }

        } else {
            angular.element(".suit-preloader").hide();
            angular.element(".mainToolarea").css({"opacity": "1"});
            angular.element("#theInitialProgress").hide();
        }


        if (jQuery("#divs_2 li.activeDesign").attr("id") == "7") {
            jQuery("#mainImageHolder").find("[rel=Lapel]").hide();
        }
    }

});

function CurrentActiveClass(obj) {
    var currentAttr;
    jQuery("#toolHeader").find(".active").removeClass("active");
    jQuery(obj).addClass("active");
    currentAttr = jQuery(obj).attr("id");
    if (currentAttr == "stylSec")
    {
        jQuery("#stylePartOfTool").css({"display": "block"});
        jQuery("#fabricPartOfTool").css({"display": "none"});
        jQuery("#accentPartOfTool").css({"display": "blobk"});
    } else if (currentAttr == "febSec")
    {

        //trigger to active fab if not trig first
        if (fabricId != "0")
        {
            //check active if not act then only trigger
            var fabId = angular.element("#fabricInnerPart fabricview").find(".activeDesign").parent().attr("id");
            if (!fabId) {
                angular.element("#fabricInnerPart fabricview[id=" + fabricId + "]").trigger("click");
            }

        } else {
            angular.element("#fabricInnerPart fabricview:first").trigger("click");
        }
        //end

        jQuery("#fabricPartOfTool").css({"display": "block"});
        jQuery("#stylePartOfTool").css({"display": "none"});
        jQuery("#accentPartOfTool").css({"display": "blobk"});
    } else if (currentAttr == "accSec")
    {
        jQuery("#accentPartOfTool").css({"display": "blobk"});
        jQuery("#stylePartOfTool").css({"display": "none"});
        jQuery("#fabricPartOfTool").css({"display": "none"});
        //
    }

}
function closeButton() {

    jQuery(".container-fluid").css({"opacity": "1"});
    jQuery(".mainToolarea").css({"height": "0px"});
    jQuery(".mainToolarea").css({"width": "0px"});
}

function zoomButtonHide() {

    jQuery("#zoomButton").css({"display": "none"});
}
function zoomButtonShow() {

    jQuery("#zoomButton").css({"display": "block"});
    jQuery("#zoomButton").css({"margin-left": "10px"});
}



function imageLoadedTemp() {

    angular.element('.shirt_part[rel=Pockets]').load(function () {
        angular.element(".mainToolarea").fadeIn("slow", function (e) {

            setTimeout(function () {
                jQuery(".preloader").hide();
                angular.element(".suit-preloader").hide();
                angular.element(".mainToolarea").css({"opacity": "1"});
                jQuery(".container-fluid").css({"opacity": "1"});
            }, 500);
        });
    });
    setTimeout(function () {
        angular.element(".suit-preloader").hide();
        angular.element(".mainToolarea").css({"opacity": "1"});
    }, 500);
    if (jQuery("#divs_2 li.activeDesign").attr("id") == "7") {
        jQuery("#mainImageHolder").find("[rel=Lapel]").hide();
    }

}

/* call after DOM loaded */
angular.element(window).load(function () {
    return false;
    //trigger to first design ele
    angular.element("#theMainInitialProgress").trigger("click");
    angular.element("#theInitialProgress").hide();
    angular.element(".container-fluid").css({"opacity": "1"});
});




function updateInItZoom()
{
    if (jQuery(window).width() > 767) {

        jQuery('.zoomContainer').remove();
        jQuery('.fabvie img').removeData('elevateZoom');

        inZoomEvalate();
    }
}

function inZoomEvalate()
{
    jQuery('.fabvie img').data('zoom-image', jQuery('.fabvie img').attr("data-image")).elevateZoom({
        responsive: true
    });

}
