<?php

namespace Shirts\Tool\Controller\Men;

use Magento\Framework\Controller\ResultFactory;

class Shirtfabric extends \Magento\Framework\App\Action\Action
{

  public function __construct(
		\Magento\Backend\App\Action\Context $context,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
		parent::__construct($context);
		$this->resultJsonFactory = $resultJsonFactory;
	}

  public function DBConnect(){
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
    	$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
    	return $resource->getConnection();
  }

  public function basePath(){
  	$om = \Magento\Framework\App\ObjectManager::getInstance();
  	$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');
  	$currentStore = $storeManager->getStore();
  	return $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
  }

  public function execute()
  {
    $sqlmaterial = "SELECT * FROM shirtmaterial WHERE status='1'";
    $material_collection = $this->DBConnect()->fetchAll($sqlmaterial);
    $materials = array();
    foreach ($material_collection as $material) {
        $id = $material['shirtmaterial_id'];
        $name = $material['title'];
        $status = $material['status'];
        if ($status) {
            $materials[] = array('id' => $id, 'name' => $name, 'parent' => 'material');
        }
    }
    $sqlpattern = "SELECT * FROM shirtpattern WHERE status='1'";
    $pattern_collection = $this->DBConnect()->fetchAll($sqlpattern);
    $patterns = array();
    foreach ($pattern_collection as $pattern) {
        $id = $pattern['shirtpattern_id'];
        $name = $pattern['title'];
        if ($status) {
            $patterns[] = array('id' => $id, 'name' => $name, 'parent' => 'pattern');
        }
    }
    $sqlseason = "SELECT * FROM shirtseason WHERE status='1'";
    $season_collection = $this->DBConnect()->fetchAll($sqlseason);
    $seasons = array();
    foreach ($season_collection as $season) {
        $id = $season['shirtseason_id'];
        $name = $season['title'];
        if ($status) {
            $seasons[] = array('id' => $id, 'name' => $name, 'parent' => 'seasons');
        }
    }
    $sqlcolor = "SELECT * FROM shirtcolor WHERE status='1'";
    $color_collection = $this->DBConnect()->fetchAll($sqlcolor);
    $colors = array();
    foreach ($color_collection as $color) {
        $id = $color['shirtcolor_id'];
        $name = $color['title'];
        if ($status) {
            $colors[] = array('id' => $id, 'name' => $name, 'parent' => 'color');
        }
    }
    $sqlcategory = "SELECT * FROM shirtcategory WHERE status='1'";
    $category_collection = $this->DBConnect()->fetchAll($sqlcategory);
    $categorys = array();
    foreach ($category_collection as $category) {
        $id = $category['shirtcategory_id'];
        $name = $category['title'];
        $class = $category['class'];
        if ($status) {
            $categorys[] = array('id' => $id, 'name' => $name, 'parent' => 'category', "class" => $class);
        }
    }

    $categories = array($materials, $patterns, $seasons, $colors, $categorys);

    $sqlfab = "SELECT * FROM shirt_shirtfabric WHERE status='1' ORDER BY title ASC";
    $fabrics_collection = $this->DBConnect()->fetchAll($sqlfab);
    // print_r($fabrics_collection); die;

    $fabrics = array();


    foreach ($fabrics_collection as $fabric) {

        $id = $fabric['fabric_id'];
        $name = $fabric['title'];
        $thumb = $fabric['display_fabric_thumb'];
        $price = $fabric['price'];
        $real_img = $fabric['fabric_large_image']; //changes made here farbic_real_image as fabric_large_image
        $shirt_type_name = "Cotton";
        $status = $fabric['status'];

        // $shirt_material_id = $fabric['shirt_material_id'];
        // $sqlmaterial = "SELECT * FROM shirtmaterial WHERE status='1' AND shirtmaterial_id='" . $shirt_material_id . "'";
        // $material_collection = $this->DBConnect()->fetchAll($sqlmaterial);
        //
        // $shirt_pattern_id = $fabric['shirt_pattern_id'];
        // $sqlpattern = "SELECT * FROM shirtpattern WHERE status='1' AND shirtpattern_id='" . $shirt_pattern_id . "' ";
        // $pattern_collection = $this->DBConnect()->fetchAll($sqlpattern);
        //
        // $shirt_season_id = $fabric['shirt_season_id'];
        // $sqlseason = "SELECT * FROM shirtseason WHERE status='1' AND shirtseason_id='" . $shirt_season_id . "'";
        //
        // $shirt_color_id = $fabric['shirt_color_id'];
        // $sqlcolor = "SELECT * FROM shirtcolor WHERE status='1' AND shirtcolor_id='" . $shirt_color_id . "'";
        // $color_collection = $this->DBConnect()->fetchAll($sqlcolor);
        //
        // $shirt_category_id = $fabric['shirt_category_id'];
        // $sqlcategory = "SELECT * FROM shirtcategory WHERE status='1' AND shirtcategory_id='" . $shirt_category_id . "'";
        // $category_collection = $this->DBConnect()->fetchAll($sqlcategory);

        if ($status) {
            $shirt_fab_type_name = $material_collection[0]['title'];
            $fabrics[] = array('id' => $id,
                'name' => $name,
                'fabric_thumb' => $this->basePath() . $thumb,
                'real_img' => $this->basePath(). $real_img,
                'price' => $price,
                'material_parent' => $material_collection[0]['title'],
                'pattern_parent' => $pattern_collection[0]['title'],
                'season_parent' => $season_collection[0]['title'],
                'color_parent' => $color_collection[0]['title'],
                'category_parent' => $category_collection[0]['title']
            );
        }
    }

            $fabricInfo = array('fabric' => $fabrics, 'category' => $categories);
            return  $this->resultJsonFactory->create()->setData($fabricInfo);
  }

}