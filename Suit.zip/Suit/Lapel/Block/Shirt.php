<?php
namespace Suit\Lapel\Block;
/**
* @author Akshay Shelke    
*/


// use Magento\Framework\View\Element\Template;
// use Magento\Framework\App\Filesystem\DirectoryList;
// use Magento\Framework\ObjectManagerInterface;

class Shirt extends \Magento\Framework\View\Element\Template
{
    // public function execute(){
    //     echo "inside block execute"; 
    // }
        
    public function Demo(){
        return "inside Block";
    }    

    public function test(){
        echo "test block";
    }
}