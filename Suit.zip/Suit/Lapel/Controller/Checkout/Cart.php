<?php
namespace Suit\Lapel\Controller\Checkout;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
  
class Cart extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $_cart;
    protected $_productRepositoryInterface;
    protected $_url;
    protected $_responseFactory;
    protected $_logger;
 
    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Psr\Log\LoggerInterface $logger
        )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_cart = $cart;
        $this->_productRepositoryInterface = $productRepositoryInterface;
        $this->_responseFactory = $responseFactory;
        $this->_url = $context->getUrl();
        $this->_logger = $logger;
        $this->_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $this->connection = $this->resource->getConnection();

        parent::__construct($context);
    }

    // public function array_map_assoc( $callback , $array ){
    //     $r = array();
    //     foreach ($array as $key=>$value)
    //         $r[$key] = $callback($key,$value);

    //     return $r;
    // }

    // public function getArray($array){
    //     $str = implode(',',$this->array_map_assoc(function($k,$v){return "$k $v";},$array));
    //     $coma = explode(",", $str);
    //     $arr = array();

    //     for($i = 0; $i < sizeof($coma); $i++){

    //         $tempVar = explode(' ', $coma[$i]);
    //         $t = "";
    //         // print_r($tempVar);
    //         for($j = 1; $j< sizeof($tempVar); $j++){
    //             if($tempVar[$j] != ' '){
    //                 $t .= $tempVar[$j]." ";    
    //             }      
    //         }
    //         trim($t);
    //         $arr[$tempVar[0]] =  $t;
    //     }
    //     return $arr;
    // }
 
    public function execute()
    {
        // $post = $this->getArray($this->getRequest()->getParam('style_data'));
        $productid = 182;
        
        $_product = $this->_productRepositoryInterface->getById($productid);

        $postStyle = $this->getRequest()->getParam('style_data');
        $postSize = $this->getRequest()->getParam('size_Data_Arr');

        $post = json_encode(array('style' =>$postStyle, 'size' =>$postSize));

        $storeId = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface')->getStore()->getId();

        /* @var \Magento\Checkout\Model\Cart $cart */
        $cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
        
        $params = array (
            'product'   => $_product->getId(),
            'qty'       => $this->getRequest()->getParam('qty'),
            'json'      => array('style' =>$postStyle, 'size' =>$postSize)
        );

        $this->_cart->addProduct($_product,$params);        
        $data = "fail";
        if($this->_cart->save()){
            $this->messageManager->addSuccessMessage('You added product to your shopping cart.');
            $sql = "UPDATE `quote_item` SET `json` = '".$post."' where `product_id` = ".$productid;
            if($this->connection->query($sql)){
                $data = "done";    
            }
        }

        echo $data;
    }
}