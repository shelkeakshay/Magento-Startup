<?php

namespace Shirts\Tool\Controller\Men;
// 'design_tool/shirts/tool'....url for this action.

use Magento\Framework\Controller\ResultFactory;

class Tool extends \Magento\Framework\App\Action\Action
{

  // public function __construct(
	// 	\Magento\Backend\App\Action\Context $context,
  //   \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	// ) {
	// 	parent::__construct($context);
	// 	$this->resultJsonFactory = $resultJsonFactory;
	// }
  //
	// public function execute()
	// {
  //   $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
	// 	$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
	// 	$connection = $resource->getConnection();
  //
	// 	$shirts_fit = $resource->getTableName('shirts_fit');
  //   $shirts_fadedesign = $resource->getTableName('shirts_fadedesign');
  //   $shirts_texture = $resource->getTableName('shirts_texture');
  //
	// 	$fit_sql = "Select * FROM " . $shirts_fit;
	// 	$result = $connection->fetchAll($fit_sql);
  //
  //   $fadedesign_sql = "Select * FROM " . $shirts_fadedesign;
	// 	$fadeResult = $connection->fetchAll($fadedesign_sql);
  //
  //   $texture_sql = "Select * FROM " . $shirts_texture;
	// 	$textureResult = $connection->fetchAll($texture_sql);
  //
  //   $json_data = array();
  //
  //   $textures = array();
  //   $fades = array();
  //
  //   $i1 = 1;
  //   $i2 = 1;
  //   $i3 = 1;
  //
  //   foreach ($result as $fit) {
  //       $fits['style'.$i1++] =  array('id' => $fit['shirts_fit_id'],'title'=>$fit['title'],'price'=>$fit['price'],'shirts_fitimage'=>$fit['shirts_fitimage'],'shirts_fitmtl'=>$fit['shirts_fitmtl'],'shirts_fitobj'=>$fit['shirts_fitobj'],'shirts_fitjs'=>$fit['shirts_fitjs'] );
  //   }
  //
  //   foreach ($fadeResult as $fade) {
  //       $fades[] =  array('id' => $fade['shirts_fadedesign_id'],'title'=>$fade['title'],'price'=>$fade['price'],'type'=>$fade['type'],'parent_category'=>$fade['parent_category'],'thumbnail_image'=>$fade['thumbnail_image'],'glow_image'=>$fade['glow_image']);
  //   }
  //
  //   foreach ($textureResult as $texture) {
  //       $textures[] =  array('id' => $texture['shirts_texture_id'],'title'=>$texture['title'],'price'=>$texture['price'],'parent_category'=>$texture['parent_category'],'texture_image'=>$texture['texture_image'],'thumbnail_image'=>$texture['thumbnail_image']);
  //   }
  //
  //   $json_data = array('styles'=>$fits,'fadedesign'=>$fades,'texture'=>$textures);
	// 	return  $this->resultJsonFactory->create()->setData($json_data);
  //
	// }

}
