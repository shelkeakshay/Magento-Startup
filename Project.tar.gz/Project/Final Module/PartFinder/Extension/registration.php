<?php
/**
* Created By:Nisha Jadhav    
* Created On:14th June 2018
* Purpose:Registered the module
*/
	\Magento\Framework\Component\ComponentRegistrar::register(
		\Magento\Framework\Component\ComponentRegistrar::MODULE,
		'PartFinder_Extension',
		__DIR__
	);
