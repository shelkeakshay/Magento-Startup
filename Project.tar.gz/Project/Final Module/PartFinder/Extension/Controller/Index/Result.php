<?php
namespace PartFinder\Extension\Controller\Index;
/**
    * Created By:Nisha Jadhav
    * Created On:13th June 2018
    * Purpose:Group Product details  
*/
use \Magento\Framework\App\Action\Action;
use \Magento\Framework\App\Action\Context;
use \Magento\Framework\View\Result\PageFactory;

class Result extends Action
{

    /**
    * @var PageFactory
    */
    protected $resultPageFactory;


    /**
    * Result constructor.
    * @param Context $context
    * @param PageFactory $pageFactory
    */
    public function __construct(Context $context, PageFactory $pageFactory , \Magento\Framework\Registry $registry)
    {
        $this->resultPageFactory = $pageFactory;
        $this->registry     = $registry;
        parent::__construct($context);
    }


    /**
    * The controller action
    *
    * @return \Magento\Framework\View\Result\Page
    */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $this->registry->register('custom', $id);
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }
}

