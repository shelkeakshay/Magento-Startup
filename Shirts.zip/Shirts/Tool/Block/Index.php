<?php
namespace Shirts\Tool\Block;

class Index extends \Magento\Framework\View\Element\Template
{

}
