<?php

namespace Mageplaza\HelloWorld\Plugin;

class ExamplePlugin2
{


  public function beforeSetName(\Mageplaza\HelloWorld\Block\Index $subject, $name)
  {
    $name = $name . " before plugin";
  // echo __METHOD__ . "</br>";

    return $name;
  }


  public function afterGetName(\Mageplaza\HelloWorld\Block\Index $subject, $result)
  {

    // echo __METHOD__ . "</br>";

    return '<h1>'. $result . ' after plugin' .'</h1>';

  }


  public function aroundGetTitle(\Mageplaza\HelloWorld\Controller\Index\Example $subject, callable $proceed)
	{

		echo __METHOD__ . " - Before proceed() </br>";
		 $result = $proceed();
		echo __METHOD__ . " - After proceed() </br>";


		return $result;
	}


}
