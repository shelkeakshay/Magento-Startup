<?php
namespace PartFinder\Extension\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

/**
 * Class UpgradeSchema
 * @package Vendor\ModuleName\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup->startSetup();

        if (version_compare($context->getVersion(), '0.0.2') < 0) {
            $this->createTableWithForeignKeys($installer);
        }
    }

    /**
     * Create tables for keeping track of many of each product a customer has on backorder
     * @param SchemaSetupInterface $installer
     */
    protected function createTableWithForeignKeys(SchemaSetupInterface $installer)
    {
        $table = $installer->getConnection()
            ->newTable('custom_tab')
            ->addColumn(
                'pkey',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Unique ID'
            )
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned'=>true, 'nullable'=>false, 'default' => '0'],
                'Product Id'
            )
           ->addColumn(
                    'tab_value',
                    Table::TYPE_TEXT,
                    200,
                    ['nullable' => false, 'default' => ''],
                    'Tab From Block'
                    )
            ->addIndex(
                $installer->getIdxName(
                    'custom_tab',
                    ['id'],
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            )
            ->addForeignKey( // Add foreign key for table entity
                $installer->getFkName(
                    'custom_tab', // New table
                    'id', // Column in New Table
                    'catalog_product_entity', // Reference Table
                    'entity_id' // Column in Reference table
                ),
                'id', // New table column
                $installer->getTable('catalog_product_entity'), // Reference Table
                'entity_id', // Reference Table Column
                // When the parent is deleted, delete the row with foreign key
                Table::ACTION_CASCADE
            )
            
            ->setComment('A comment about your table');

        $installer->getConnection()->createTable($table);
    }
}