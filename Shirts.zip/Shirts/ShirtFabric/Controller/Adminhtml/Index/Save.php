<?php

/**
 * @author Dhirajkumar Deore
 * Copyright © 2018 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Shirts\ShirtFabric\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Shirts\ShirtFabric\Model\ShirtFabric;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action {

    protected $fabric_id = "";
    protected $fabric_0 = "";
    protected $fabric_90 = "";
    protected $finalImage_new = "";
    protected $fileName = "";

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;
    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;

    //protected $_modelNewsFactory;
    //  protected $collectionFactory;
    //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
    Context $context, DataPersistorInterface $dataPersistor, \Magento\Framework\Escaper $escaper, \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
        // $this->filter = $filter;
        // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
        $this->scopeConfig = $scopeConfig;
        $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
        $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function homepath()
    {
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

      $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');

      return $directory->getPath('media');
    }

    public function getDb(){
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
      $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
      return $resource->getConnection();
    }


    public function execute() {



        $finalImage_new = "";
        $fileName = "";

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        if ($data) {

            $id = $this->getRequest()->getParam('shirtfabric_id');

            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['shirtfabric_id'])) {
                $data['shirtfabric_id'] = null;
            }


            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Shirts\ShirtFabric\Model\ShirtFabric')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This shirts_shirtfabric no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }


            if (isset($data['thumbnail_image'][0]['name']) && isset($data['thumbnail_image'][0]['tmp_name'])) {
                $data['thumbnail_image'] = '/shirts_shirtfabric/' . $data['thumbnail_image'][0]['name'];
            } elseif (isset($data['thumbnail_image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['thumbnail_image'] = $data['thumbnail_image'][0]['name'];
            } else {
                $data['thumbnail_image'] = null;
            }

            if (isset($data['fabric_thumbnail'][0]['name']) && isset($data['fabric_thumbnail'][0]['tmp_name'])) {

                $userfile_extn = explode(".", $data['fabric_thumbnail'][0]['name']);

                $data['fabric_thumbnail'] = '/shirts_shirtfabric/' . $data['fabric_thumbnail'][0]['name'];

                $fileName = $userfile_extn[0];
            } elseif (isset($data['fabric_thumbnail'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['fabric_thumbnail'] = $data['fabric_thumbnail'][0]['name'];
            } else {
                $data['fabric_thumbnail'] = null;
            }

            if (isset($data['fabric_large_image'][0]['name']) && isset($data['fabric_large_image'][0]['tmp_name'])) {

                // $finalImage_new = $data['fabric_large_image'][0]['name'];

                $data['fabric_large_image'] = '/shirts_shirtfabric/' . $data['fabric_large_image'][0]['name'];
            } elseif (isset($data['fabric_large_image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['fabric_large_image'] = $data['fabric_large_image'][0]['name'];
            } else {
                $data['fabric_large_image'] = null;
            }




            // $path  =  $directory->getPath('media').'/shirts_shirtfabric/';

            $model->setData($data);





            $this->inlineTranslation->suspend();
            try {
                //////////////////// email
                $model->save();
                $this->messageManager->addSuccess(__('shirts_shirtfabric Saved successfully'));
                $this->dataPersistor->clear('shirts_shirtfabric');




                if ($data['fabric_thumbnail'] != '') {

                    $this->fabric_id = $model->getId();
                    // echo $this->fabric_id; die;
                    $fabric_thumb_name = $data['fabric_thumbnail'];
                    /* color image creation start */


                    //echo $fabricThumbImgpath;
                    //================  Shirt Image Generator START ================================

                    $fabricThumbImgpath = $this->homePath() . '/' . $fabric_thumb_name;
                    $fabricName = "fabric_main.png";
                    $this->fabric_0 = $this->homePath() . '/fab_shirt_images/' . $fabricName;

                    //back

                    $fabricName_90 = "fabric_main_90.png";
                    $fabric_90 = $this->homePath() . '/fab_shirt_images/' . $fabricName_90;

                    //for zoom view
                    $fabric_zoom = $this->homePath() . "/fab_shirt_images/fabric_zoom.png";
                    $shirtFabImgPath = $this->homePath() . '/fab_shirt_images/';
                    $fabric_vest_thumb_name = $this->homePath() . "/fab_shirt_images/fabric_vest_thu.png";

                    exec('convert ' . $fabricThumbImgpath . ' -rotate 90 ' . $fabric_90);

                    exec('convert -size 1080x1320 tile:' . $fabric_90 . ' ' . $shirtFabImgPath . 'fabric_main_back.png');


                    exec('convert -size 1080x1320 tile:' . $fabricThumbImgpath . ' ' . $this->fabric_0);
                    //        exec('convert -size 300x300 tile:' . $fabricThumbImgpath . ' ' . $this->homePath() . '/fab_shirt_images/fabric_' . $this->fabric_id . '_show.png');
                    //created for collar


                    exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT 80 ' . $shirtFabImgPath . 'fabric_cuff_side.png');

                    //zoom view fabirc
                    exec('convert -size 1200x900 tile:' . $fabricThumbImgpath . ' ' . $fabric_zoom);
                    //created for collar
                    exec('convert ' . $fabric_zoom . ' -background "rgba(0,0,0,0.5)" -distort SRT 90 ' . $shirtFabImgPath . 'fabric_main_back_zoom.png');

                    /* END create fabric image */

                    /* Create plain fabric image */

                    $vestfabricThumbImgpath = $this->homePath() . '/' . $fabric_vest_thumb_name;
                    $vestfabricName = "fabric_vestmain.png";
                    $vestfabric_0 = $this->homePath() . '/fab_shirt_images/' . $vestfabricName;
                    exec('convert -size 1080x1320 tile:' . $vestfabricThumbImgpath . ' ' . $vestfabric_0);

              // =====================================end plain fabric ===================================

                  // $this->elboPatches(); die;

                  // $this->shirtFit(); die;

                  $this->styleCollor(); die;


                  // $this->cuffImages();

                  // $this->shirtSleeves();

                  // $this->shirtPlackates();

                    //================  Shirt Image Generator END ==================================
                }


                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['shirtfabric_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the shirts_shirtfabric.'));
                // print_r($e); die;
                echo $e; die;
            }
            $this->dataPersistor->set('shirts_shirtfabric', $data);
            return $resultRedirect->setPath('*/*/edit', ['shirtfabric_id' => $this->getRequest()->getParam('shirtfabric_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function elboPatches()
    {


      /* Elbow patches images */
      $sqlelbowpatches = "SELECT * FROM shirt_accent_elbowpatches WHERE status='1'";
      $elbowpatches_collection = $this->getDb()->fetchAll($sqlelbowpatches);
      // print_r($elbowpatches_collection); die;
      foreach ($elbowpatches_collection as $elbowpatches) {
          $elbowpatches_id = $elbowpatches['elbowpatches_id'];

          $elbowpatchesLeft_glow = $this->homePath() . '/' . $elbowpatches['glow_back_image'];
          $elbowpatchesLeft_mask = $this->homePath() . '/' . $elbowpatches['mask_back_image'];
          $elbowpatchesLeft_highlighted = $this->homePath() . '/' . $elbowpatches['highlighted_back_image'];

          if ($elbowpatches['glow_back_image'] != '' && $elbowpatches['mask_back_image'] != '') {
              //left
              // echo 'composite -compose Dst_In -gravity center ' . $elbowpatchesLeft_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png'; die;
              exec('composite -compose Dst_In -gravity center ' . $elbowpatchesLeft_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png');

//                            echo '<br>composite -compose Dst_In -gravity center ' . $elbowpatchesLeft_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png';

              exec('convert ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png');

              exec('convert ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png ' . $elbowpatchesLeft_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png');
              //highlighted
              exec('composite ' . $elbowpatchesLeft_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png');
              // echo 'composite ' . $elbowpatchesLeft_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png ' . $this->homePath() . '/shirt_images/elbowpatches/' . $this->fabric_id . '_elbowPatches_view_3.png'; die;
          }

          unset($elbowpatches_collection);
      }

    }

    public function shirtFit(){
      //shirt fit start
      $sql_fit = "SELECT * FROM shirtfit";
      $rows_fit = $this->getDb()->fetchAll($sql_fit);
      // print_r($rows_fit); die;

      foreach ($rows_fit as $fit) {

          $shirtfit_id = $fit['shirtfit_id'];
          $style_type = '';
          $cuff_size = '';
          $cuff_type = '';

          $fit_glow = $this->homePath() . '/' . $fit['glow_front_image'];
          $fit_mask = $this->homePath() . '/' . $fit['mask_front_image'];
          $fit_highlighted = $this->homePath() . '/' . $fit['highlighted_front_image'];

          if ($fit['glow_front_image'] != '' && $fit['mask_front_image'] != '' && $fit['highlighted_front_image'] != '') {
              //mask changed
              exec('composite -compose Dst_In  -gravity center ' . $fit_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png');
              // echo 'composite -compose Dst_In  -gravity center ' . $fit_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png'; die;
              //crop
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png');
              //glow
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png ' . $fit_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png');
              //highlighted
              exec('composite ' . $fit_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_1.png');

          }

          $glow_fit_image = $this->homePath() . '/' . $fit['glow_side_image'];
          $mask_fit_image = $this->homePath() . '/' . $fit['mask_side_image'];
          $highlighted_fit_image = $this->homePath() . '/' . $fit['highlighted_side_image'];

          if ($fit['glow_side_image'] != '' && $fit['mask_side_image'] != '' && $fit['highlighted_side_image'] != '') {

              exec('composite -compose Dst_In  -gravity center ' . $mask_fit_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png');
              //crop
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png');
              //glow
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png ' . $glow_fit_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png');
              //highlighted
              exec('composite ' . $highlighted_fit_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png');
              // echo 'composite ' . $highlighted_fit_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_2.png'; die;
          }

          $glow_back_image = $this->homePath() . '/' . $fit['glow_back_image'];
          $mask_back_image = $this->homePath() . '/' . $fit['mask_back_image'];
          $highlighted_back_image = $this->homePath() . '/' . $fit['highlighted_back_image'];

          if ($fit['glow_back_image'] != '' && $fit['mask_back_image'] != '' && $fit['highlighted_back_image'] != '') {
              exec('composite -compose Dst_In  -gravity center ' . $mask_back_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png');
              //crop
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png');
              //glow
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png ' . $glow_back_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png');
              //highlighted
              exec('composite ' . $highlighted_back_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png');
              // echo 'composite ' . $highlighted_back_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_3.png'; die;
          }

          $glow_fold_image = $this->homePath() . '/' . $fit['glow_fold_image'];
          $mask_fold_image = $this->homePath() . '/' . $fit['mask_fold_image'];
          $highlighted_fold_image = $this->homePath() . '/' . $fit['highlighted_fold_image'];

          if ($fit['glow_fold_image'] != '' && $fit['mask_fold_image'] != '' && $fit['highlighted_fold_image'] != '') {
              exec('composite -compose Dst_In  -gravity center ' . $mask_fold_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png');
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png');
              //glow
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png ' . $glow_fold_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png');
              //highlighted
              exec('composite ' . $highlighted_fold_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png');
              // echo 'composite ' . $highlighted_fold_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_4.png'; die;
          }

          //25-10-2017 Zoom View Code START....issue here for shirtfit..!!
          $glow_zoom_image = $this->homePath() . '/' . $fit['glow_zoom_image'];
          $mask_zoom_image = $this->homePath() . '/' . $fit['mask_zoom_image'];
          $highlighted_zoom_image = $this->homePath() . '/' . $fit['highlighted_zoom_image'];
          if ($fit['glow_zoom_image'] != '' && $fit['mask_zoom_image'] != '' && $fit['highlighted_zoom_image'] != '') {
              exec('composite -compose CopyOpacity ' . $mask_zoom_image . ' ' . $fabric_zoom . ' ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png');
              // echo 'composite -compose CopyOpacity ' . $mask_zoom_image . ' ' . $fabric_zoom . ' ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png'; die;
              //glow
              exec('convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png ' . $glow_zoom_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png');
              // echo 'convert ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png ' . $glow_zoom_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png'; die;
              //highlighted
              exec('composite ' . $highlighted_zoom_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png');

              // echo 'composite ' . $highlighted_zoom_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png ' . $this->homePath() . '/shirt_images/fit/' . $this->fabric_id . '_fitstyle_' . $style_type . '_size_' . $cuff_size . '_fittype_' . $cuff_type . '_' . $shirtfit_id . '_view_5.png'; die;
          }

          //25-10-2017 Zoom View Code END
      }

      unset($rows_fit);


      //shirt fit end
    }



    public function styleCollor(){

      /* Create style collor images */

      $sql = "SELECT * FROM shirtstyle";
      $rows = $this->getDb()->fetchAll($sql);
     // echo "<pre>";print_r($rows);die;
      foreach ($rows as $style) {

          $style_id = $style['shirtstyle_id'];

          /* view 1 start */


          $view1_glow_left_image = $this->homePath() . '/' . $style['view1_glow_left_image'];
          $view1_mask_left_image = $this->homePath() . '/' . $style['view1_mask_left_image'];
          $view1_highlighted_left_image = $this->homePath() . '/' . $style['view1_highlighted_left_image'];

          $view1_glow_right_image = $this->homePath() . '/' . $style['view1_glow_right_image'];
          $view1_mask_right_image = $this->homePath() . '/' . $style['view1_mask_right_image'];
          $view1_highlighted_right_image = $this->homePath() . '/' . $style['view1_highlighted_right_image'];

          $view2_glow_left_image = $this->homePath() . '/' . $style['view2_glow_left_image'];
          $view2_mask_left_image = $this->homePath() . '/' . $style['view2_mask_left_image'];
          $view2_highlighted_left_image = $this->homePath() . '/' . $style['view2_highlighted_left_image'];

          $view2_glow_right_image = $this->homePath() . '/' . $style['view2_glow_right_image'];
          $view2_mask_right_image = $this->homePath() . '/' . $style['view2_mask_right_image'];
          $view2_highlighted_right_image = $this->homePath() . '/' . $style['view2_highlighted_right_image'];

          $view4_glow_left_image = $this->homePath() . '/' . $style['view4_glow_left_image'];
          $view4_mask_left_image = $this->homePath() . '/' . $style['view4_mask_left_image'];
          $view4_highlighted_left_image = $this->homePath() . '/' . $style['view4_highlighted_left_image'];

          $view4_glow_right_image = $this->homePath() . '/' . $style['view4_glow_right_image'];
          $view4_mask_right_image = $this->homePath() . '/' . $style['view4_mask_right_image'];
          $view4_highlighted_right_image = $this->homePath() . '/' . $style['view4_highlighted_right_image'];

          $view4_glow_inner_image = $this->homePath() . '/' . $style['view4_glow_inner_image'];
          $view4_mask_inner_image = $this->homePath() . '/' . $style['view4_mask_inner_image'];
          $view4_highlighted_inner_image = $this->homePath() . '/' . $style['view4_highlighted_inner_image'];

          $view5_glow_left_image = $this->homePath() . '/' . $style['view5_glow_left_image'];
          $view5_mask_left_image = $this->homePath() . '/' . $style['view5_mask_left_image'];
          $view5_highlighted_left_image = $this->homePath() . '/' . $style['view5_highlighted_left_image'];

          $view5_glow_right_image = $this->homePath() . '/' . $style['view5_glow_right_image'];
          $view5_mask_right_image = $this->homePath() . '/' . $style['view5_mask_right_image'];
          $view5_highlighted_right_image = $this->homePath() . '/' . $style['view5_highlighted_right_image'];

          $view5_glow_inner_image = $this->homePath() . '/' . $style['view5_glow_inner_image'];
          $view5_mask_inner_image = $this->homePath() . '/' . $style['view5_mask_inner_image'];
          $view5_highlighted_inner_image = $this->homePath() . '/' . $style['view5_highlighted_inner_image'];

          //step-1: left
          //roate fabric image
          exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT 45 ' . $shirtFabImgPath . 'fabric_main_left.png');
          // echo 'convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT 45 ' . $shirtFabImgPath . 'fabric_main_left.png'; die;

          //mask
          exec('composite -compose Dst_In -gravity center ' . $view1_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png  ' . $view1_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png');
          //highlighted
          exec('composite ' . $view1_highlighted_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png');


          //step-2: right
          //roate fabric image
          exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT -45 ' . $shirtFabImgPath . 'fabric_main_right.png');
          //mask
          exec('composite -compose Dst_In -gravity center ' . $view1_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png  ' . $view1_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png');
          //highlighted
          exec('composite ' . $view1_highlighted_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png');

          //Combine
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_1.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png');




          //step 3: Front
          //mask  image
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Styles/Commonpart_Front_mask.png ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_front_view_1.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png  ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Styles/Commonpart_Front_shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Styles/Commonpart_Front_hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png');


          //step 5: back
          //fabric image
          //            exec('convert ' . $shirtFabImgPath . 'fabric_main_back.png -wave 10x300 -gravity South -chop 0x10 ' . $shirtFabImgPath . 'fabric_main_back.png');
          //mask image
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Styles/Shirt_Commoncollar_Back_Mask.png  ' . $shirtFabImgPath . 'fabric_main_back_wave.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Styles/Shirt_Commoncollar_Back_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Styles/Shirt_Commoncollar_Back_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_1.png');


          //step 4: compose all images
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_1.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_1.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_1.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_1.png');

          /* view 1 end */

          /* view 2 start */
          //step-1: left
          //roate fabric image
          exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT 45 ' . $shirtFabImgPath . 'fabric_main_left.png');

          //mask
          exec('composite -compose Dst_In -gravity center ' . $view2_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png  ' . $view2_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png');
          //highlighted
          exec('composite ' . $view2_highlighted_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png');

          //step-2: right
          //roate fabric image
          exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT -45 ' . $shirtFabImgPath . 'fabric_main_right.png');
          //mask
          exec('composite -compose Dst_In -gravity center ' . $view2_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png  ' . $view2_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png');
          //highlighted
          exec('composite ' . $view2_highlighted_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png');

          //Combine
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_2.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png');

          //step 3: Front
          //mask  image
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Styles/Commonpart_Side_mask.png ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png  ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Styles/Commonpart_Side_shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Styles/Commonpart_Side_hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png');

          //step 5: back
          //fabric image
          exec('convert ' . $shirtFabImgPath . 'fabric_main_back.png -wave 10x300 -gravity South -chop 0x10 ' . $shirtFabImgPath . 'fabric_main_back_wave.png');

          //mask image
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Back_View/Collar_Styles/Shirt_Commoncollar_Back_Mask.png  ' . $shirtFabImgPath . 'fabric_main_back_wave.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png ' . $this->homePath() . '/glow_mask_shirt/Back_View/Collar_Styles/Shirt_Commoncollar_Back_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Back_View/Collar_Styles/Shirt_Commoncollar_Back_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_back_view_2.png');

          //step 4: compose all images
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_front_view_2.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_2.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_2.png');



          /* view 2 end */

          /* view 3 start */
          //step 5: back
          //fabric image
          //mask image
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Back_View/Collar_Styles/Shirt_Commoncollar_Back_Mask.png  ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png ' . $this->homePath() . '/glow_mask_shirt/Back_View/Collar_Styles/Shirt_Commoncollar_Back_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Back_View/Collar_Styles/Shirt_Commoncollar_Back_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_3.png');


          /* view 3 end */

          /* view 4 start */

          //step-1: left
          //roate fabric image
          exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT 45 ' . $shirtFabImgPath . 'fabric_main_left.png');

          //mask
          exec('composite -compose Dst_In -gravity center ' . $view4_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png  ' . $view4_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png');
          //highlighted
          exec('composite ' . $view4_highlighted_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png');

          //step-2: right
          //roate fabric image
          exec('convert ' . $this->fabric_0 . ' -background "rgba(0,0,0,0.5)" -distort SRT -45 ' . $shirtFabImgPath . 'fabric_main_right.png');
          //mask
          exec('composite -compose Dst_In -gravity center ' . $view4_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png  ' . $view4_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png');
          //highlighted
          exec('composite ' . $view4_highlighted_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png');

          //Combine
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_4.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png');


          //step 3: common back
          //mask  image
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Folded_View/Collar_Styles/Commonbackpart_Folded_mask.png ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png  ' . $this->homePath() . '/glow_mask_shirt/Folded_View/Collar_Styles/Commonbackpart_Folded_shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Folded_View/Collar_Styles/Commonbackpart_Folded_hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png');

          //inner mask
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Collars/Folded/inner-fabric_mask.png ' . $shirtFabImgPath . 'fabric_' . $this->fabric_id . '_main.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png');

          //inner glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png  ' . $this->homePath() . '/glow_mask_shirt/Collars/Folded/inner-fabric_shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Collars/Folded/inner-fabric_hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_inner_view_4.png');

          //step 4: compose all images
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_4.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_4.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_4.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_4.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_4.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_4.png');

          /* view 4 end */
          //close collar end
          //open/casual collar start

          $view1_casual_glow_left_image = $this->homePath() . '/' . $style['view1_casual_glow_left_image'];
          $view1_casual_mask_left_image = $this->homePath() . '/' . $style['view1_casual_mask_left_image'];
          $view1_casual_highlighted_left_image = $this->homePath() . '/' . $style['view1_casual_highlighted_left_image'];

          $view1_casual_glow_right_image = $this->homePath() . '/' . $style['view1_casual_glow_right_image'];
          $view1_casual_mask_right_image = $this->homePath() . '/' . $style['view1_casual_mask_right_image'];
          $view1_casual_highlighted_right_image = $this->homePath() . '/' . $style['view1_casual_highlighted_right_image'];

          $view2_casual_glow_left_image = $this->homePath() . '/' . $style['view2_casual_glow_left_image'];
          $view2_casual_mask_left_image = $this->homePath() . '/' . $style['view2_casual_mask_left_image'];
          $view2_casual_highlighted_left_image = $this->homePath() . '/' . $style['view2_casual_highlighted_left_image'];

          $view2_casual_glow_right_image = $this->homePath() . '/' . $style['view2_casual_glow_right_image'];
          $view2_casual_mask_right_image = $this->homePath() . '/' . $style['view2_casual_mask_right_image'];
          $view2_casual_highlighted_right_image = $this->homePath() . '/' . $style['view2_casual_highlighted_right_image'];


          $commonbase_front_glow_left_image = $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/CommonBase_Left_shad.png';
          $commonbase_front_mask_left_image = $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/CommonBase_Left_mask.png';
          $commonbase_front_hi_left_image = $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/CommonBase_Left_hi.png';
          $commonbase_front_glow_right_image = $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/CommonBase_Right_shad.png';
          $commonbase_front_mask_right_image = $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/CommonBase_Right_mask.png';
          $commonbase_front_hi_right_image = $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/CommonBase_Right_hi.png';

          $commonbase_side_glow_left_image = $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/CommonBase_Left_shad.png';
          $commonbase_side_mask_left_image = $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/CommonBase_Left_mask.png';
          $commonbase_side_hi_left_image = $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/CommonBase_Left_hi.png';
          $commonbase_side_glow_right_image = $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/CommonBase_Right_shad.png';
          $commonbase_side_mask_right_image = $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/CommonBase_Right_mask.png';
          $commonbase_side_hi_right_image = $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/CommonBase_Right_hi.png';



          /* view 1 start */

          //step-1: left
          //mask
          exec('composite -compose Dst_In -gravity center ' . $view1_casual_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png  ' . $view1_casual_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png');
          //highlighted
          exec('composite ' . $view1_casual_highlighted_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png');

          //step-2: right
          //mask

          exec('composite -compose Dst_In -gravity center ' . $view1_casual_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png');


          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png  ' . $view1_casual_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png');
          //highlighted
          exec('composite ' . $view1_casual_highlighted_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png');

          //step-1: common left
          //mask
          exec('composite -compose Dst_In -gravity center ' . $commonbase_front_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png  ' . $commonbase_front_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png');
          //highlighted
          exec('composite ' . $commonbase_front_hi_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png');

          //step-2: common right
          //mask
          exec('composite -compose Dst_In -gravity center ' . $commonbase_front_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png  ' . $commonbase_front_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png');
          //highlighted
          exec('composite ' . $commonbase_front_hi_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png');

          //step-2: common torso
          //mask
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Torso_Bust/Casual-Bust_Front_Torso_mask.png ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png  ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Torso_Bust/Casual-Bust_Front_Torso_shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Torso_Bust/Casual-Bust_Front_Torso_hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png');


          //step-2: common placket
          //mask
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Placket/Casual-Bust_Front_Placket_Mask.png ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png  ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Placket/Casual-Bust_Front_Placket_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Placket/Casual-Bust_Front_Placket_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png');

          //step-2: compose all images
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_1.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_1.png  -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_1.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_1.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_1.png');


          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png ' . $this->homePath() . '/glow_mask_shirt/Front_View/Collar_Casual/Placket/Casual-Bust_Front_Button.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_1.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_1.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_1.png');

          /* view 1 end */

          /* view 2 start */


          //step-1: left
          //mask
          exec('composite -compose Dst_In -gravity center ' . $view2_casual_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png');

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png  ' . $view2_casual_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png');
          //highlighted
          exec('composite ' . $view2_casual_highlighted_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png');


          //step-2: right
          //mask
          exec('composite -compose Dst_In -gravity center ' . $view2_casual_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png  ' . $view2_casual_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png');
          //highlighted
          exec('composite ' . $view2_casual_highlighted_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png');

          //step-1: common left
          //mask
          exec('composite -compose Dst_In -gravity center ' . $commonbase_side_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png  ' . $commonbase_side_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png');
          //highlighted
          exec('composite ' . $commonbase_side_hi_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png');

          //step-2: common right
          //mask
          exec('composite -compose Dst_In -gravity center ' . $commonbase_side_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right.png -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png  ' . $commonbase_side_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png');
          //highlighted
          exec('composite ' . $commonbase_side_hi_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png');

          //step-2: common torso
          //mask
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Torso_Bust/Casual-Bust_Side_Torso_mask.png ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png  ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Torso_Bust/Casual-Bust_Side_Torso_shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Torso_Bust/Casual-Bust_Side_Torso_hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png');


          //step-2: common placket
          //mask
          exec('composite -compose Dst_In -gravity center ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Placket/Casual-Bust_Side_Placket_Mask.png ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png  ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Placket/Casual-Bust_Side_Placket_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Placket/Casual-Bust_Side_Placket_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png');



          //view 5 start
          //roate fabric image
          exec('convert ' . $fabric_zoom . ' -background "rgba(0,0,0,0.5)" -distort SRT 45 ' . $shirtFabImgPath . 'fabric_main_left_zoom.png');

          //mask
          exec('composite -compose CopyOpacity ' . $view5_mask_left_image . ' ' . $shirtFabImgPath . 'fabric_main_left_zoom.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png  ' . $view5_glow_left_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png');
          //highlighted
          exec('composite ' . $view5_highlighted_left_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png');


          //step-2: right
          //roate fabric image
          exec('convert ' . $fabric_zoom . ' -background "rgba(0,0,0,0.5)" -distort SRT -45 ' . $shirtFabImgPath . 'fabric_main_right_zoom.png');
          //mask
          exec('composite -compose CopyOpacity ' . $view5_mask_right_image . ' ' . $shirtFabImgPath . 'fabric_main_right_zoom.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png  ' . $view5_glow_right_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png');
          //highlighted
          exec('composite ' . $view5_highlighted_right_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png');

          //mask image
          exec('composite -compose CopyOpacity ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Back_Mask.png  ' . $shirtFabImgPath . 'fabric_main_back_zoom.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_5.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_5.png ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Back_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_5.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Back_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_back_view_5.png');

          exec('convert ' . $fabric_zoom . ' -background "rgba(0,0,0,0.5)" -distort SRT 80 ' . $shirtFabImgPath . 'fabric_main_left_basecollar.png');
          exec('convert ' . $fabric_zoom . ' -background "rgba(0,0,0,0.5)" -distort SRT -80 ' . $shirtFabImgPath . 'fabric_main_right_basecollar.png');
          //left
          exec('composite -compose CopyOpacity ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Left_Mask.png  ' . $shirtFabImgPath . 'fabric_main_left_basecollar.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png');

          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Left_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Left_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png');

          //right
          exec('composite -compose CopyOpacity ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Right_Mask.png  ' . $shirtFabImgPath . 'fabric_main_right_basecollar.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png');
          //glow image
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Right_Shad.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png');
          //highlighted
          exec('composite ' . $this->homePath() . '/glow_mask_shirt/Zoom_View/Collar_Styles/CollarBase_Right_Hi.png -compose Overlay  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png');

          //innner combine
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninner_view_5.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerRight_view_5.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninnerLeft_view_5.png');


          //inner collar end
          //step 4: compose all images
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png  ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_5.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_commoninner_view_5.png ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_5.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_view_5.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_right_view_5.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/' . $this->fabric_id . '_style_' . $style_id . '_left_view_5.png');
          /* view 5 end */

          //step-2: compose all images

          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_2.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_left_view_2.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_right_view_2.png');


          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_2.png  -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_collar_view_2.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_left_view_2.png');
          unlink($this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_right_view_2.png');


          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_' . $style_id . '_casual_common_placket_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png');
          exec('convert ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png ' . $this->homePath() . '/glow_mask_shirt/Side_View/Collar_Casual/Placket/Casual-Bust_Side_Button.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/collarstyle/casual/' . $this->fabric_id . '_style_casual_common_torso_view_2.png');


      }

      unset($rows);
}


      public function cuffImages(){

                            /* Create cuff images */

                            $sql_cuff = "SELECT * FROM shirtcuff"; //WHERE gender='1'
                            $rows_cuff = $this->getDb()->fetchAll($sql_cuff);

                            $cuff_id = 1;
                            $style_type = 1;
                            $cuff_size = '';
                            $cuff_type = '';
                            //echo "<pre>";print_r($rows_cuff);die;
                            //open cuff images
                            $opencuff_left_glow = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Front/Casualcuff_Front_left_shad.png';
                            $opencuff_left_mask = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Front/Casualcuff_Front_left_mask.png';
                            $opencuff_left_highlighted = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Front/Casualcuff_Front_left_hi.png';
                            $opencuff_right_glow = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Front/Casualcuff_Front_right_shad.png';
                            $opencuff_right_mask = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Front/Casualcuff_Front_right_mask.png';
                            $opencuff_right_highlighted = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Front/Casualcuff_Front_right_hi.png';

                            exec('composite -compose Dst_In -gravity center ' . $opencuff_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');

                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png ' . $opencuff_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                            //highlight
                            exec('composite ' . $opencuff_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_1.png');

                            exec('composite -compose Dst_In -gravity center ' . $opencuff_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');

                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $opencuff_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                            //highlight
                            exec('composite ' . $opencuff_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                            //combine
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_final_front_cuff.png');
                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');



                            $opencuff_side_left_glow = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Side/CasualCuff_Side_left_shad.png';
                            $opencuff_side_left_mask = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Side/CasualCuff_Side_left_mask.png';
                            $opencuff_side_left_highlighted = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Side/CasualCuff_Side_left_hi.png';
                            $opencuff_side_right_glow = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Side/CasualCuff_Side_right_shad.png';
                            $opencuff_side_right_mask = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Side/CasualCuff_Side_right_mask.png';
                            $opencuff_side_right_highlighted = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Side/CasualCuff_Side_right_hi.png';

                            exec('composite -compose Dst_In -gravity center ' . $opencuff_side_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');

                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png ' . $opencuff_side_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                            //highlight
                            exec('composite ' . $opencuff_side_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_2.png');

                            exec('composite -compose Dst_In -gravity center ' . $opencuff_side_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');

                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $opencuff_side_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                            //highlight
                            exec('composite ' . $opencuff_side_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                            //combine
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_final_side_cuff.png');
                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');

                            $opencuff_back_left_glow = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Back/CasualCuffs_Back_Left_shad.png';
                            $opencuff_back_left_mask = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Back/CasualCuffs_Back_Left_mask.png';
                            $opencuff_back_left_highlighted = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Back/CasualCuffs_Back_Left_hi.png';
                            $opencuff_back_right_glow = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Back/CasualCuffs_Back_Right_shad.png';
                            $opencuff_back_right_mask = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Back/CasualCuffs_Back_Right_mask.png';
                            $opencuff_back_right_highlighted = $this->homePath() . '/glow_mask_shirt/Open_Cuffs/Back/CasualCuffs_Back_Right_hi.png';

                            exec('composite -compose Dst_In -gravity center ' . $opencuff_back_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');

                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png ' . $opencuff_back_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                            //highlight
                            exec('composite ' . $opencuff_back_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');

                            exec('composite -compose Dst_In -gravity center ' . $opencuff_back_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');

                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $opencuff_back_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                            //highlight
                            exec('composite ' . $opencuff_back_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                            //combine
                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_final_back_cuff.png');
                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');



                            foreach ($rows_cuff as $cuffs) {
                                $cuff_id = $cuffs['shirtcuff_id'];
                                $style_type = $cuffs['type'];
                                $cuff_size = '';
                                $cuff_type = '';

                                $cuff_left_glow = $this->homePath() . '/' . $cuffs['glow_front_left_image'];
                                $cuff_left_mask = $this->homePath() . '/' . $cuffs['mask_front_left_image'];
                                $cuff_left_highlighted = $this->homePath() . '/' . $cuffs['highlighted_front_left_image'];
                                $cuff_right_glow = $this->homePath() . '/' . $cuffs['glow_front_right_image'];
                                $cuff_right_mask = $this->homePath() . '/' . $cuffs['mask_front_right_image'];
                                $cuff_right_highlighted = $this->homePath() . '/' . $cuffs['highlighted_front_right_image'];


                                //                        $opencuff_left_glow = $this->homePath() . '/' . $cuffs['glow_front_opencuff_left_image'];
                                //                        $opencuff_left_mask = $this->homePath() . '/' . $cuffs['mask_front_opencuff_left_image'];
                                //                        $opencuff_left_highlighted = $this->homePath() . '/' . $cuffs['highlighted_front_opencuff_left_image'];
                                //                        $opencuff_right_glow = $this->homePath() . '/' . $cuffs['glow_front_opencuff_right_image'];
                                //                        $opencuff_right_mask = $this->homePath() . '/' . $cuffs['mask_front_opencuff_right_image'];
                                //                        $opencuff_right_highlighted = $this->homePath() . '/' . $cuffs['highlighted_front_opencuff_right_image'];
                                //view 1
                                if ($cuffs['glow_front_left_image'] != '' && $cuffs['mask_front_left_image'] != '') {

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png ' . $cuff_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                                    //highlight
                                    exec('composite ' . $cuff_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $cuff_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //highlight
                                    exec('composite ' . $cuff_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //combine
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_1.png');
                                    unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');


                                    //opencuff
                                    //                            exec('composite -compose Dst_In -gravity center ' . $opencuff_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                                    //
         //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png ' . $opencuff_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                                    //                            //highlight
                                    //                            exec('composite ' . $opencuff_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_1.png');
                                    //
         //                            exec('composite -compose Dst_In -gravity center ' . $opencuff_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //
         //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $opencuff_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //                            //highlight
                                    //                            exec('composite ' . $opencuff_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //                            //combine
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_view_1.png');
                                    //                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_1.png');
                                    //                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_1.png');
                                }

                                //view 2
                                $cuff_side_left_glow = $this->homePath() . '/' . $cuffs['glow_side_left_image'];
                                $cuff_side_left_mask = $this->homePath() . '/' . $cuffs['mask_side_left_image'];
                                $cuff_side_left_highlighted = $this->homePath() . '/' . $cuffs['highlighted_side_left_image'];
                                $cuff_side_right_glow = $this->homePath() . '/' . $cuffs['glow_side_right_image'];
                                $cuff_side_right_mask = $this->homePath() . '/' . $cuffs['mask_side_right_image'];
                                $cuff_side_right_highlighted = $this->homePath() . '/' . $cuffs['highlighted_side_right_image'];

                                //                        $opencuff_side_left_glow = $this->homePath() . '/' . $cuffs['glow_side_opencuff_left_image'];
                                //                        $opencuff_side_left_mask = $this->homePath() . '/' . $cuffs['mask_side_opencuff_left_image'];
                                //                        $opencuff_side_left_highlighted = $this->homePath() . '/' . $cuffs['highlighted_side_opencuff_left_image'];
                                //                        $opencuff_side_right_glow = $this->homePath() . '/' . $cuffs['glow_side_opencuff_right_image'];
                                //                        $opencuff_side_right_mask = $this->homePath() . '/' . $cuffs['mask_side_opencuff_right_image'];
                                //                        $opencuff_side_right_highlighted = $this->homePath() . '/' . $cuffs['highlighted_side_opencuff_right_image'];


                                if ($cuffs['glow_side_left_image'] != '' && $cuffs['mask_side_left_image'] != '') {

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_side_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png ' . $cuff_side_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                                    //highlight
                                    exec('composite ' . $cuff_side_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_2.png');

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_side_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $cuff_side_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //highlight
                                    exec('composite ' . $cuff_side_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //combine
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_2.png');
                                    unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');

                                    //opencuff
                                    //                            exec('composite -compose Dst_In -gravity center ' . $opencuff_side_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                                    //
         //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png ' . $opencuff_side_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                                    //                            //highlight
                                    //                            exec('composite ' . $opencuff_side_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cufftype_' . $cuff_id . '_left_view_2.png');
                                    //
         //                            exec('composite -compose Dst_In -gravity center ' . $opencuff_side_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //
         //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $opencuff_side_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //                            //highlight
                                    //                            exec('composite ' . $opencuff_side_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //                            //combine
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_view_2.png');
                                    //                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_2.png');
                                    //                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_2.png');
                                }


                                //view 3
                                $cuff_back_left_glow = $this->homePath() . '/' . $cuffs['glow_back_left_image'];
                                $cuff_back_left_mask = $this->homePath() . '/' . $cuffs['mask_back_left_image'];
                                $cuff_back_left_highlighted = $this->homePath() . '/' . $cuffs['highlighted_back_left_image'];
                                $cuff_back_right_glow = $this->homePath() . '/' . $cuffs['glow_back_right_image'];
                                $cuff_back_right_mask = $this->homePath() . '/' . $cuffs['mask_back_right_image'];
                                $cuff_back_right_highlighted = $this->homePath() . '/' . $cuffs['highlighted_back_right_image'];

                                //                        $opencuff_back_left_glow = $this->homePath() . '/' . $cuffs['glow_back_opencuff_left_image'];
                                //                        $opencuff_back_left_mask = $this->homePath() . '/' . $cuffs['mask_back_opencuff_left_image'];
                                //                        $opencuff_back_left_highlighted = $this->homePath() . '/' . $cuffs['highlighted_back_opencuff_left_image'];
                                //                        $opencuff_back_right_glow = $this->homePath() . '/' . $cuffs['glow_back_opencuff_right_image'];
                                //                        $opencuff_back_right_mask = $this->homePath() . '/' . $cuffs['mask_back_opencuff_right_image'];
                                //                        $opencuff_back_right_highlighted = $this->homePath() . '/' . $cuffs['highlighted_back_opencuff_right_image'];


                                if ($cuffs['glow_back_left_image'] != '' && $cuffs['mask_back_left_image'] != '') {

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_back_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png ' . $cuff_back_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                    //highlight
                                    exec('composite ' . $cuff_back_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_back_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $cuff_back_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //highlight
                                    exec('composite ' . $cuff_back_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //combine
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_3.png');
                                    unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');


                                    //opencuff
                                    //                            exec('composite -compose Dst_In -gravity center ' . $opencuff_back_left_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                    //
         //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png ' . $opencuff_back_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                    //                            //highlight
                                    //                            exec('composite ' . $opencuff_back_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                    //
         //                            exec('composite -compose Dst_In -gravity center ' . $opencuff_back_right_mask . ' ' . $shirtFabImgPath . 'fabric_main_back.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //
         //                            exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $opencuff_back_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //                            //highlight
                                    //                            exec('composite ' . $opencuff_back_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //                            //combine
                                    //                            exec('convert ' .$this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_view_3.png');
                                    //                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_right_view_3.png');
                                    //                            unlink($this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_opencuff_' . $cuff_type . '_' . $cuff_id . '_left_view_3.png');
                                }


                                //view 4
                                $cuff_fold_main_glow = $this->homePath() . '/' . $cuffs['glow_fold_main_image'];
                                $cuff_fold_main_mask = $this->homePath() . '/' . $cuffs['mask_fold_main_image'];
                                $cuff_fold_main_highlighted = $this->homePath() . '/' . $cuffs['highlighted_fold_main_image'];

                                $inner_fold_inner_glow = $this->homePath() . '/' . $cuffs['glow_fold_inner_image'];
                                $inner_fold_inner_mask = $this->homePath() . '/' . $cuffs['mask_fold_inner_image'];
                                $inner_fold_inner_highlighted = $this->homePath() . '/' . $cuffs['highlighted_fold_inner_image'];


                                if ($cuffs['mask_fold_main_image'] != '' && $cuffs['mask_fold_inner_image'] != '') {

                                    exec('composite -compose Dst_In -gravity center ' . $cuff_fold_main_mask . ' ' . $shirtFabImgPath . 'fabric_main.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png ' . $cuff_fold_main_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png');

                                    //highlight
                                    exec('composite ' . $cuff_fold_main_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_cufftype_' . $cuff_type . '_' . $cuff_id . '_view_4.png');


                                    //inner
                                    exec('composite -compose Dst_In -gravity center ' . $inner_fold_inner_mask . ' ' . $shirtFabImgPath . 'fabric_main.png -alpha Set ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png');
                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png');

                                    exec('convert ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png ' . $inner_fold_inner_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png');
                                    //highlight
                                    exec('composite ' . $inner_fold_inner_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png ' . $this->homePath() . '/shirt_images/cuffs/' . $this->fabric_id . '_cuffstyle_' . $style_type . '_size_' . $cuff_size . '_inner_' . $cuff_type . '_' . $cuff_id . '_inner_view_4.png');
                                }
                    }

                    unset($rows_cuff);
                }



            public function shirtSleeves(){


                                  $sql_sleeves = "SELECT * FROM shirtsleeves";
                                  $rows_sleeves = $this->getDb()->fetchAll($sql_sleeves);
                                  // print_r($rows_sleeves); die;
                                  foreach ($rows_sleeves as $sleeves) {

                                      $sleeve_id = $sleeves['shirtsleeves_id'];
                                      $style_type = $sleeves['type'];
                                      $cuff_size = '';
                                      $cuff_type = '';

                                      $sleeve_left_glow = $this->homePath() . '/' . $sleeves['glow_front_left_image'];
                                      $sleeve_left_mask = $this->homePath() . '/' . $sleeves['mask_front_left_image'];
                                      $sleeve_left_highlighted = $this->homePath() . '/' . $sleeves['highlighted_front_left_image'];
                                      $sleeve_right_glow = $this->homePath() . '/' . $sleeves['glow_front_right_image'];
                                      $sleeve_right_mask = $this->homePath() . '/' . $sleeves['mask_front_right_image'];
                                      $sleeve_right_highlighted = $this->homePath() . '/' . $sleeves['highlighted_front_right_image'];

                                      if ($sleeves['glow_front_left_image'] != '' && $sleeves['mask_front_left_image'] != '' && $sleeves['highlighted_front_left_image'] != '') {

                                          exec('composite -compose Dst_In -gravity center ' . $sleeve_left_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png ' . $sleeve_left_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png');
                                          //highlight
                                          exec('composite ' . $sleeve_left_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png');

                                          exec('composite -compose Dst_In -gravity center ' . $sleeve_right_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png ' . $sleeve_right_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png');
                                          //highlight
                                          exec('composite ' . $sleeve_right_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png');
                                          //combine two images
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_view_1.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_1.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_1.png');
                                      }


                                      $glow_left_sleeves_image = $this->homePath() . '/' . $sleeves['glow_side_left_image'];
                                      $mask_left_sleeves_image = $this->homePath() . '/' . $sleeves['mask_side_left_image'];
                                      $highlighted_left_sleeves_image = $this->homePath() . '/' . $sleeves['highlighted_side_left_image'];

                                      $glow_right_sleeves_image = $this->homePath() . '/' . $sleeves['glow_side_right_image'];
                                      $mask_right_sleeves_image = $this->homePath() . '/' . $sleeves['mask_side_right_image'];
                                      $highlighted_right_sleeves_image = $this->homePath() . '/' . $sleeves['highlighted_side_right_image'];

                                      if ($sleeves['glow_side_left_image'] != '' && $sleeves['mask_side_left_image'] != '' && $sleeves['highlighted_side_left_image'] != '') {

                                          exec('composite -compose Dst_In -gravity center ' . $mask_left_sleeves_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png ' . $glow_left_sleeves_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png');
                                          //highlight
                                          exec('composite ' . $highlighted_left_sleeves_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png');

                                          exec('composite -compose Dst_In -gravity center ' . $mask_right_sleeves_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png');
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png ' . $glow_right_sleeves_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png');
                                          //highlight
                                          exec('composite ' . $highlighted_right_sleeves_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png');
                                          //combine two images
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_view_2.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_2.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_2.png');
                                      }

                                      $glow_left_back_image = $this->homePath() . '/' . $sleeves['glow_back_left_image'];
                                      $mask_left_back_image = $this->homePath() . '/' . $sleeves['mask_back_left_image'];
                                      $highlighted_left_back_image = $this->homePath() . '/' . $sleeves['highlighted_back_left_image'];
                                      $glow_right_back_image = $this->homePath() . '/' . $sleeves['glow_back_right_image'];
                                      $mask_right_back_image = $this->homePath() . '/' . $sleeves['mask_back_right_image'];
                                      $highlighted_right_back_image = $this->homePath() . '/' . $sleeves['highlighted_back_right_image'];

                                      if ($sleeves['glow_back_left_image'] != '' && $sleeves['mask_back_left_image'] != '' && $sleeves['highlighted_back_left_image'] != '') {

                                          exec('composite -compose Dst_In -gravity center ' . $mask_left_back_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png');
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png ' . $glow_left_back_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png');
                                          //highlight
                                          exec('composite ' . $highlighted_left_back_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png');

                                          exec('composite -compose Dst_In -gravity center ' . $mask_right_back_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png');
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png ' . $glow_right_back_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png');
                                          //highlight
                                          exec('composite ' . $highlighted_right_back_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png');
                                          //combine two images
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_view_3.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_3.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_3.png');
                                      }


                                      $glow_left_fold_image = $this->homePath() . '/' . $sleeves['glow_fold_left_image'];
                                      $mask_left_fold_image = $this->homePath() . '/' . $sleeves['mask_fold_left_image'];
                                      $highlighted_left_fold_image = $this->homePath() . '/' . $sleeves['highlighted_fold_left_image'];
                                      $glow_right_fold_image = $this->homePath() . '/' . $sleeves['glow_fold_right_image'];
                                      $mask_right_fold_image = $this->homePath() . '/' . $sleeves['mask_fold_right_image'];
                                      $highlighted_right_fold_image = $this->homePath() . '/' . $sleeves['highlighted_fold_right_image'];


                                      if ($sleeves['glow_fold_image'] != '' && $sleeves['mask_fold_image'] != '' && $sleeves['highlighted_fold_left_image'] != '') {

                                          exec('composite -compose Dst_In -gravity center ' . $mask_left_fold_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png');
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png ' . $glow_left_fold_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png');
                                          //highlight
                                          exec('composite ' . $highlighted_right_back_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png');

                                          exec('composite -compose Dst_In -gravity center ' . $mask_right_fold_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png');
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png');

                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png ' . $glow_right_fold_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png');
                                          //highlight
                                          exec('composite ' . $highlighted_right_back_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png');
                                          //combine two images
                                          exec('convert ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_view_4.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_right_view_4.png');
                                          unlink($this->homePath() . '/shirt_images/sleeves/' . $this->fabric_id . '_sleevesstyle_' . $style_type . '_size_' . $cuff_size . '_sleevestype_' . $cuff_type . '_' . $sleeve_id . '_left_view_4.png');
                                      }
                                  }

                                  unset($rows_sleeves);

            }




        public function shirtplackates(){


                              //shirt plackets
                              $sql_plackets = "SELECT * FROM shirtplackets";
                              $rows_plackets = $this->getDb()->fetchAll($sql_plackets);
                              print_r($rows_plackets); die;
                              foreach ($rows_plackets as $plackets) {

                                  $shirtplackets_id = $plackets['shirtplackets_id'];
                                  $plackets_glow = $this->homePath() . '/' . $plackets['glow_front_image'];
                                  $plackets_mask = $this->homePath() . '/' . $plackets['mask_front_image'];
                                  $plackets_highlighted = $this->homePath() . '/' . $plackets['highlighted_front_image'];

                                  if ($plackets_glow != '' && $plackets_mask != '') {
                                      exec('composite -compose Dst_In -gravity center ' . $plackets_mask . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png');
                                      exec('convert ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png');

                                      exec('convert ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png ' . $plackets_glow . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png');
                                      //highlight
                                      exec('composite ' . $plackets_highlighted . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_1.png');
                                  }

                                  $glow_side_image = $this->homePath() . '/' . $plackets['glow_side_image'];
                                  $mask_side_image = $this->homePath() . '/' . $plackets['mask_side_image'];
                                  $highlighted_side_image = $this->homePath() . '/' . $plackets['highlighted_side_image'];

                                  if ($glow_side_image != '' && $mask_side_image != '') {
                                      exec('composite -compose Dst_In -gravity center ' . $mask_side_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png');
                                      exec('convert ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png');

                                      exec('convert ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png ' . $glow_side_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png');
                                      //highlight
                                      exec('composite ' . $highlighted_side_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_2.png');
                                  }

                                  $glow_fold_image = $this->homePath() . '/' . $plackets['glow_fold_image'];
                                  $mask_fold_image = $this->homePath() . '/' . $plackets['mask_fold_image'];
                                  $highlighted_fold_image = $this->homePath() . '/' . $plackets['highlighted_fold_image'];

                                  if ($glow_fold_image != '' && $mask_fold_image != '') {
                                      exec('composite -compose Dst_In -gravity center ' . $mask_fold_image . ' ' . $this->fabric_0 . ' -alpha Set ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png');

                                      exec('convert ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png -crop 500x1320+290+0  +repage ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png');

                                      exec('convert ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png ' . $glow_fold_image . ' -geometry +0+0 -composite ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png');
                                      //highlight
                                      exec('composite ' . $highlighted_fold_image . ' -compose Overlay  ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png ' . $this->homePath() . '/shirt_images/plackets/' . $this->fabric_id . '_plackets_' . $shirtplackets_id . '_view_4.png');
                                  }
                              }
                              unset($rows_plackets);
        }




}
