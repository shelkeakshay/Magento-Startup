<?php

namespace Suit\Lapel\Controller\Index;

class getShirtButtonFabric extends \Magento\Framework\App\Action\Action{
	

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory	
		)
	{
		$this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$this->resource = $this->objectManager->get('Magento\Framework\App\ResourceConnection');
		$this->connection = $this->resource->getConnection();
		$this->resultJsonFactory = $resultJsonFactory;
		return parent::__construct($context);
	}

	public function execute()
	{	
		
        return $this->getShirtButtonFabricAction();
	}

	
	public function getShirtButtonFabricAction() {
        // $basePath = $this->getBasePath();

        // $basePath = "http://192.168.2.104/Magentop/";

        $storeManager = $this->objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        $basePath = $storeManager->getStore()->getBaseUrl();  // get base url...

        $sql = " SELECT * FROM shirt_button_fabric ";
        $rows = $this->connection->fetchAll($sql);
        $fabrics = array();
        foreach ($rows as $fabric) {
            $id = $fabric['button_fabric_id'];
            $name = $fabric['title'];
            $thumb = $fabric['fabric_thumb'];
            $real_img = $fabric['fabric_real_image'];
            $shirt_type_name = "Cotton";
            $fabrics[] = array('id' => $id, 'price' => '1', 'name' => $name, 'real_img' => $basePath .
                        'media/' . $real_img, 'img' => $basePath . 'media/' . $thumb);
        }

        
        // echo json_encode($fabrics, true);
        // $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fabrics)); X1
        return $this->resultJsonFactory->create()->setData($fabrics);   // X2
    }
}