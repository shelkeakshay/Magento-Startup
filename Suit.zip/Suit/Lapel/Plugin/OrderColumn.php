<?php
/**
* Created By:Nisha Jadhav    
* Created On:29 April 2018
* Purpose:Create a block data for frontend which contain collection info and extends template
*/
namespace Suit\Lapel\Plugin;
class OrderColumn extends \Magento\Framework\View\Element\Template {
    
    public function beforeToHtml(\Magento\Sales\Block\Order\Item\Renderer\DefaultRenderer $originalBlock) {
        $originalBlock->setTemplate('Suit_Lapel::order/default.phtml');
        // return $result;
    }
}