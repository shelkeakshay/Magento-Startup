<?php

namespace Akshay\Tab\Observer;

use Magento\Framework\Event\ObserverInterface;

class AddCustomOption implements ObserverInterface {

    public function execute(\Magento\Framework\Event\Observer $observer) {



        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->get('Magento\Framework\Registry')->registry('current_product'); //get current product
        $id = $product->getId();

        $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
                ->get('Magento\Framework\App\ResourceConnection');
        $connection = $this->_resources->getConnection();
        $table = $this->_resources->getTableName('custom_tab');

        $sql = "Select * FROM " . $table . " where id=" . $id;
        //echo $sql;
        $result = $connection->fetchAll($sql);

//         echo "<pre>";
//         print_r($result);
//         if (isset($result[0]['id']))
//         {echo "yes";}
//         else 
//             {echo "no";}
//        die();
        // $afile=$_POST['product']['newfield'];
        // echo $afile;
        //die();
//        if(isset($result[0]['id'])){
//             echo "in if";//die();
//             $sql = "Update " . $table . " Set tab_value = '".$_POST['product']['newfield']."' where `id` = ".$id;
//             echo $sql;//die();
//             $connection->query($sql);
//         }
//         else {
//             echo "in else";//die();
//             $sql = "INSERT INTO ".$table." ( `tab_value`,`id` ) VALUES ('".$_POST['product']['newfield']."',".$id.")";
//             // echo $sql;die();
//             $connection->query($sql);
//         }
    }

}
