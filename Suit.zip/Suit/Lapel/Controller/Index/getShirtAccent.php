<?php

namespace Suit\Lapel\Controller\Index;

class getShirtAccent extends \Magento\Framework\App\Action\Action{
	

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory	
		)
	{
		$this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$this->resource = $this->objectManager->get('Magento\Framework\App\ResourceConnection');
		$this->connection = $this->resource->getConnection();
		$this->resultJsonFactory = $resultJsonFactory;
		return parent::__construct($context);
	}

	public function execute()
	{	
        return $this->getShirtAccentAction();
	}

	
	public function getShirtAccentAction() {
        // $basePath = $this->getBasePath();

        // $basePath = "http://192.168.2.104/Magentop/";

        $storeManager = $this->objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        $basePath = $storeManager->getStore()->getBaseUrl();  // get base url...

        $monogram_data = array('id' => 1, 'name' => 'Add Monogram', 'class' => 'icon-Add_Monogram', 'price' => '20', 'designType' => 'shirt', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Style_Main_Icon.png');

        // collar style

        $sqlCollarStyle = "SELECT * FROM shirt_accent_collarstyle 
                            WHERE status='1' ORDER BY collarstyle_id ASC";
        $collarstyle_collection = $this->connection->fetchAll($sqlCollarStyle);

        $collarstyleArr = array();
        foreach ($collarstyle_collection as $collarstyle) {

            $id = $collarstyle['collarstyle_id'];
            $title = $collarstyle['title'];
            $class = $collarstyle['class'];
            $price = $collarstyle['price'];
            $status = $collarstyle['status'];

            if ($status) {
                $collarstyleArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'CollarStyle',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => ''
                );
            }
        }

     
        $collarstyle_data = array('id' => 2, 'name' => 'Collar Style', 'designType' => 'shirt', 'class' => 'icon-Collar_Contrast_Main_Icon', 'img' => $basePath . 'images/Collar/all.svg', "style" => $collarstyleArr);

        // all.svg image not found.

        // cuff
        $sqlCuff = "SELECT * FROM shirt_accent_cuffs WHERE status='1' ORDER BY cuff_id ASC";
        $cuff_collection = $this->connection->fetchAll($sqlCuff);

        $cuffsArr = array();
        foreach ($cuff_collection as $cuff) {

            $id = $cuff['cuff_id'];
            $title = $cuff['title'];
            $class = $cuff['class'];
            $price = $cuff['price'];
            $status = $cuff['status'];

            if ($status) {
                $cuffsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Cuffs',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => ''
                );
            }
        }



        $cuff_data = array('id' => 3, 'name' => 'Cuffs', 'designType' => 'shirt', 'class' => 'icon-Cuff_Contrast_Main_Icon', 'price' => '10', 'img' => $basePath . 'images/Cuffs/all.png', "style" => $cuffsArr);

        // threads

        $sqlThreads = "SELECT * FROM shirt_shirtthreadfabric WHERE status='1' ORDER BY fabric_id ASC";
        $threads_collection = $this->connection->fetchAll($sqlThreads);

        $threadsArr = array();
        unset($class);


        foreach ($threads_collection as $threads) {

            $id = $threads['fabric_id'];
            $title = $threads['title'];
            if(isset($threads['class'])){
                $class = $threads['class'];    
            }else{
                $class = "";
            }
            
            $price = $threads['price'];
            $thumb = $threads['display_fabric_thumb'];
            $status = $threads['status'];

            if ($status) {
                $threadsColorArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Threads',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        //issue : class is not a column in table shirt_shirtfabric

        $sqlThreads = "SELECT * FROM shirt_accent_threads WHERE status='1' ORDER BY threads_id ASC";
        $threads_collection = $this->connection->fetchAll($sqlThreads);

        $threadsArr = array();
        foreach ($threads_collection as $threads) {

            $id = $threads['threads_id'];
            $title = $threads['title'];
            $class = $threads['class'];
            $price = $threads['price'];
            $status = $threads['status'];

            if ($status) {
                $threadsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Threads',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb,
                );
            }
        }



        $threads_data = array('id' => 4, 'name' => 'Threads', 'designType' => 'shirt', 'class' => 'icon-Thread_Main_Icon', 'price' => '10', "style" => $threadsArr);

        
        // elbowpatches


        $sqlElbowpatches = "SELECT * FROM shirt_accent_elbowpatches WHERE status='1' ORDER BY elbowpatches_id ASC";
        $elbowpatches_collection = $this->connection->fetchAll($sqlElbowpatches);

        $elbowpatchesArr = array();
        foreach ($elbowpatches_collection as $elbowpatches) {

            $id = $elbowpatches['elbowpatches_id'];
            $title = $elbowpatches['title'];
            $class = $elbowpatches['class'];
            $price = $elbowpatches['price'];
            $thumb = null;
            $status = $elbowpatches['status'];

            if ($status) {
                $elbowpatchesArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'ElbowPatch',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $elbowpatches_data = array('id' => 5, 'name' => 'Elbow Patch', 'designType' => 'shirt', 'class' => 'icon-Main_Icon2', 'price' => '10', 'img' => $basePath . 'media/jacket_img/thumbnail/00_Elbowpatch_Main_Icon.png', "style" => $elbowpatchesArr);

        // chest pleats

        $sqlChestpleats = "SELECT * FROM shirt_accent_chestpleats WHERE status='1' ORDER BY chestpleats_id ASC";
        $chestpleats_collection = $this->connection->fetchAll($sqlChestpleats);

        $chestpleatsArr = array();
        foreach ($chestpleats_collection as $chestpleats) {

            $id = $chestpleats['chestpleats_id'];
            $title = $chestpleats['title'];
            $class = $chestpleats['class'];
            $price = $chestpleats['price'];
            $status = $chestpleats['status'];

            if ($status) {
                $chestpleatsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Chest pleats',
                    'designType' => 'shirt',
                    'designRel' => 'lining',
                    'name' => $title,
                    'price' => $price,
                    'img' => ''
                );
            }
        }

        $chestpleats_data = array('id' => 6, 'name' => 'Chest Pleats', 'designType' => 'shirt', 'class' => 'icon-Main_Icon', 'price' => '10', 'img' => $basePath . 'media/jacket_img/thumbnail/00Fit_Main_Icon.png', "style" => $chestpleatsArr);

        // front placket


        $sqlPlacket = "SELECT * FROM shirt_accent_placket WHERE status='1' ORDER BY placket_id ASC";
        $placket_collection = $this->connection->fetchAll($sqlPlacket);

        $placketsArr = array();
        foreach ($placket_collection as $placket) {

            $id = $placket['placket_id'];
            $title = $placket['title'];
            $class = $placket['class'];
            $price = $placket['price'];
            $status = $placket['status'];

            if ($status) {
                $placketsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Front Placket',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price
                );
            }
        }

        $placket_data = array('id' => 7, 'name' => 'Front Placket', 'designType' => 'shirt', 'class' => 'icon-Front_Placket_Contrast_Main_Icon', 'price' => '10', 'img' => $basePath . 'images/Plackets/all.png', "style" => $placketsArr);

        $button_threads_data = array('id' => 8, 'name' => 'Button Threads', 'designType' => 'shirt', 'class' => 'icon-Thread_Main_Icon', 'price' => '10', "style" => $threadsColorArr);

        $shirtAccentInfo = array($monogram_data, $collarstyle_data, $cuff_data, $threads_data, $elbowpatches_data, $chestpleats_data, $placket_data, $button_threads_data);

        
        // $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($shirtAccentInfo)); // x1

        return $this->resultJsonFactory->create()->setData($shirtAccentInfo);   // X2
    }
}