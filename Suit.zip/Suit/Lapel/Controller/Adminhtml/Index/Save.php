<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Lapel\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Suit\Lapel\Model\Lapel;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;
    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;
    public $fabric_id;
    //protected $_modelNewsFactory;
  //  protected $collectionFactory;
   //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
       // $this->filter = $filter;
       // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
         $this->scopeConfig = $scopeConfig;
         $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
         $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
        $this->fabric_id = 1;
        


        $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->connection = $this->objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 
        

        $this->directory= $this->objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $this->rootPath1  =  $this->directory->getRoot();
        $this->rootPath   = $this->rootPath1."/pub/media";    

    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */


    public function createImage($table, $primaryId, $glow, $mask, $hi, $fabric, $destination){

        $result1 = $this->connection->fetchAll("SELECT * FROM ".$table);

            foreach ($result1 as $rs){

                $style_id = $rs[$primaryId].rand(1,500);

                $fit_glow = ''.$this->rootPath.'/'.$rs[$glow].'';  // Glow == Shad
                // echo $fit_glow; die;
                $fit_mask = ''.$this->rootPath.'/'.$rs[$mask].'';
                $fit_highlighted = ''.$this->rootPath.'/'.$rs[$hi].'';

                //front left
                if ($fit_glow != '' && $fit_mask != '' && $fit_highlighted != '') {
                        
                    //mask changed
                    $this->fabric_id++;
                    exec(
                        'composite -compose Dst_In  -gravity center ' . $fit_mask . 
                        ' ' . $fabric . ' -alpha Set '.
                        $this->rootPath. $destination .  
                        $this->fabric_id . '_style_' . $style_id . '_view_1.png'
                    );
                    $this->fabric_id++;
                    //crop
                    exec(
                        'convert '.$this->rootPath.$destination .
                         $this->fabric_id . '_style_' . $style_id . 
                         '_view_1.png -crop 500x1320+290+0  +repage '.
                         $this->rootPath. $destination . 
                         $this->fabric_id . '_style_' . $style_id . '_view_1.png'
                    );
                    $this->fabric_id++;
                    //glow
                    exec(
                        'convert '.
                        $this->rootPath.$destination . 
                        $this->fabric_id . '_style_' . $style_id . '_view_1.png ' . 
                        $fit_glow . ' -geometry +0+0 -composite '.
                        $this->rootPath.$destination . 
                        $this->fabric_id . '_style_' . $style_id . '_view_1.png'
                    );
                    $this->fabric_id++;
                    //highlighted
                    exec(
                        'composite ' . $fit_highlighted . ' -compose Overlay  '.
                        $this->rootPath.$destination . 
                        $this->fabric_id . '_style_' . $style_id . '_view_1.png '.
                        $this->rootPath.$destination . 
                        $this->fabric_id . '_style_' . $style_id . '_view_1.png'
                    );
                }
                        
                $this->fabric_id++;
            }
    }
    
    public function execute()
    {

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $id = $this->getRequest()->getParam('suit_lapel_id');

            if (isset($data['status']) && $data['status'] === 'true'){
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['suit_lapel_id'])) {
                $data['suit_lapel_id'] = null;
            }
           
           
            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Suit\Lapel\Model\Lapel')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This suit_lapel no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            
            
            if (isset($data['suit_upperrightmask'][0]['name']) && isset($data['suit_upperrightmask'][0]['tmp_name'])) {
                $data['suit_upperrightmask'] ='/suit_lapel/'.$data['suit_upperrightmask'][0]['name'];
            }elseif (isset($data['suit_upperrightmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_upperrightmask'] =$data['suit_upperrightmask'][0]['name'];
            } else {
                $data['suit_upperrightmask'] = null;
            }

            if (isset($data['main_image'][0]['name']) && isset($data['main_image'][0]['tmp_name'])) {
                $data['main_image'] ='/suit_lapel/'.$data['main_image'][0]['name'];
            }elseif (isset($data['main_image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['main_image'] =$data['main_image'][0]['name'];
            } else {
                $data['main_image'] = null;
            }

            if (isset($data['objimage'][0]['name']) && isset($data['objimage'][0]['tmp_name'])) {
                $data['objimage'] ='/suit_lapel/'.$data['objimage'][0]['name'];
            }elseif (isset($data['objimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['objimage'] =$data['objimage'][0]['name'];
            } else {
                $data['objimage'] = null;
            }
            
            if (isset($data['mlt_image'][0]['name']) && isset($data['mlt_image'][0]['tmp_name'])) {
                $data['mlt_image'] ='/suit_lapel/'.$data['mlt_image'][0]['name'];
            }elseif (isset($data['mlt_image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['mlt_image'] =$data['mlt_image'][0]['name'];
            } else {
                $data['mlt_image'] = null;
            }
            
            $model->setData($data);

            $this->inlineTranslation->suspend();
            try {


               

            //     $model->save();
            //     exec("python convert_obj_three.py -i ".$this->rootPath.$data['objimage']." 
            //             -b -o created_files/outfile".$model->getId().".js");

                $fabric_thumb_name = $model->getsuit_upperrightmask();

                $this->fabric_id = $model->getId();

                $fabricThumbImgpath = ''.$this->rootPath.''.$fabric_thumb_name;
                $fabricName = $fabric_thumb_name;
                
                $fabric_0 = ''.$this->rootPath.'/Glow-Mask/fab_zero_image' . $fabricName;
                $fabric_0 =  str_replace('/suit_lapel', '', $fabric_0);

                
                exec('convert -size 1080x1320 tile:' . $fabricThumbImgpath .' '. $fabric_0);

                // left 
                $destSleeve = '/Glow-Mask/created_suit_images/styles/sleeves/';

                $this->createImage(
                        'suitsleeves',          // table name
                        'suitsleeves_id',       // Primary key
                        'left_glow_image',      // glow image
                        'left_mask_image',      // mask image
                        'left_hi_image',        // highlight image
                        $fabric_0,              // created a tile
                        $destSleeve
                    ); 

                // // right
                // $this->createImage(
                //     'suitsleeves',
                //         'suitsleeves_id', 
                //         'right_glow_image', 
                //         'right_mask_image', 
                //         'right_hi_image', 
                //         $fabric_0, 
                //         $destSleeve
                //     );

                // // back left 
                // $this->createImage(
                //     'suitsleeves',
                //     'suitsleeves_id',
                //     'back_left_glow_image',
                //     'back_left_mask_image',
                //     'back_left_hi_image',
                //     $fabric_0,
                //     $destSleeve
                // ); 

                // //back right
                // $this->createImage(
                //     'suitsleeves', 
                //     'suitsleeves_id', 
                //     'back_right_glow_image', 
                //     'back_right_mask_image', 
                //     'back_right_hi_image', 
                //     $fabric_0, 
                //     $destSleeve
                // ); 

                // // Style suit

                // // jacket style front
                // $destStyle = '/Glow-Mask/created_suit_images/styles/jacket/';
                // $this->createImage(
                //     'suitstyle', 
                //     'suitstyle_id', 
                //     'glow_image', 
                //     'mask_image', 
                //     'hi_image', 
                //     $fabric_0, 
                //     $destStyle
                // ); 

                // // jacket style back
                // $this->createImage(
                //     'suitstyle', 
                //     'suitstyle_id', 
                //     'back_glow_image', 
                //     'back_mask_image', 
                //     'back_hi_image', 
                //     $fabric_0, 
                //     $destStyle
                // ); 

                // // coat style

                // // front coat

                // $destCoat = '/Glow-Mask/created_suit_images/styles/coat/';
                // $this->createImage(
                //     'suitcoatstyles', 
                //     'suitcoatstyles_id', 
                //     'glow_image', 
                //     'mask_image', 
                //     'hi_image', 
                //     $fabric_0, 
                //     $destCoat
                // ); 

                // // back coat
                // $this->createImage(
                //     'suitcoatstyles', 
                //     'suitcoatstyles_id', 
                //     'back_glow_image', 
                //     'back_mask_image', 
                //     'back_hi_image', 
                //     $fabric_0, 
                //     $destCoat
                // ); 


                // $destPocket = '/Glow-Mask/created_suit_images/styles/pocket/';

                // $this->createImage(
                //         'suitpockets',          // table name
                //         'suitpocket_id',       // Primary key
                //         'left_glow_image',      // glow image
                //         'left_mask_image',      // mask image
                //         'left_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPocket
                //     ); 

                // $this->createImage(
                //         'suitpockets',          // table name
                //         'suitpocket_id',       // Primary key
                //         'right_glow_image',      // glow image
                //         'right_mask_image',      // mask image
                //         'right_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPocket
                //     ); 

                //  $this->createImage(
                //         'suitpockets',          // table name
                //         'suitpocket_id',       // Primary key
                //         'ticket_glow_image',      // glow image
                //         'ticket_mask_image',      // mask image
                //         'ticket_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPocket
                //     ); 

                //  // pocketsquare

                //  $destPocketSq = '/Glow-Mask/created_suit_images/styles/pocketsquare/';

                //  $this->createImage(
                //         'suitpocketsquare',          // table name
                //         'suitpocketsquare_id',       // Primary key
                //         'glow_image',      // glow image
                //         'mask_image',      // mask image
                //         'hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPocketSq
                //     ); 
                
                // // Vest                
                // $destVestLapl = '/Glow-Mask/created_suit_images/vests/vestlapel/';

                //  $this->createImage(
                //         'vestlapels',          // table name
                //         'vestlapels_id',       // Primary key
                //         'upper_left_glow_image',      // glow image
                //         'upper_left_mask_image',      // mask image
                //         'upper_left_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestLapl
                //     ); 

                //  $this->createImage(
                //         'vestlapels',          // table name
                //         'vestlapels_id',       // Primary key
                //         'upper_right_glow_image',      // glow image
                //         'upper_right_mask_image',      // mask image
                //         'upper_right_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestLapl
                //     ); 

                //  $this->createImage(
                //         'vestlapels',          // table name
                //         'vestlapels_id',       // Primary key
                //         'lower_left_glow_image',      // glow image
                //         'lower_left_mask_image',      // mask image
                //         'lower_left_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestLapl
                //     ); 

                //  $this->createImage(
                //         'vestlapels',          // table name
                //         'vestlapels_id',       // Primary key
                //         'lower_right_glow_image',      // glow image
                //         'lower_right_mask_image',      // mask image
                //         'lower_right_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestLapl
                //     ); 

                //  // vestage

                // $destVestStyle = '/Glow-Mask/created_suit_images/vests/veststyle/';

                // $this->createImage( 
                //         'veststyleedge',          // table name
                //         'veststyleedge_id',       // Primary key
                //         'glow_image',      // glow image
                //         'mask_image',      // mask image
                //         'hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestStyle
                //     ); 

                
                // // vest pocket
                // $destVestPocket = '/Glow-Mask/created_suit_images/vests/vestpocket/';

                // $this->createImage( 
                //         'vestpocket',          // table name
                //         'vestpocket_id',       // Primary key
                //         'glow_image',      // glow image
                //         'mask_image',      // mask image
                //         'hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestPocket          // destination path
                //     ); 

                // $this->createImage( 
                //         'vestpocket',          // table name
                //         'vestpocket_id',       // Primary key
                //         'ticket_glow_image',      // glow image
                //         'ticket_mask_image',      // mask image
                //         'ticket_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestPocket          // destination path
                //     ); 

                // // coat

                // $destVestPocket = '/Glow-Mask/created_suit_images/coats/collers/';

                // $this->createImage( 
                //         'suitcoatcollars',          // table name
                //         'suitcoatcollars_id',       // Primary key
                //         'lower_left_glow_image',      // glow image
                //         'lower_left_mask_image',      // mask image
                //         'lower_left_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestPocket          // destination path
                //     ); 

                // $this->createImage( 
                //         'suitcoatcollars',          // table name
                //         'suitcoatcollars_id',       // Primary key
                //         'lower_right_glow_image',      // glow image
                //         'lower_right_mask_image',      // mask image
                //         'lower_right_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestPocket          // destination path
                //     ); 

                // $this->createImage( 
                //         'suitcoatcollars',          // table name
                //         'suitcoatcollars_id',       // Primary key
                //         'upper_left_glow_image',      // glow image
                //         'upper_left_mask_image',      // mask image
                //         'upper_left_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestPocket          // destination path
                //     ); 

                // $this->createImage( 
                //         'suitcoatcollars',          // table name
                //         'suitcoatcollars_id',       // Primary key
                //         'upper_right_glow_image',      // glow image
                //         'upper_right_mask_image',      // mask image
                //         'upper_right_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destVestPocket          // destination path
                //     ); 



                // $destPuffFront = '/Glow-Mask/created_suit_images/pants/front/';

                // $this->createImage( 
                //         'pantcuff',          // table name
                //         'pantcuff_id',       // Primary key
                //         'glow_image',      // glow image
                //         'mask_image',      // mask image
                //         'hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPuffFront          // destination path
                //     ); 

                // $destPuffBack = '/Glow-Mask/created_suit_images/pants/back/';               
                // $this->createImage( 
                //         'pantcuff',          // table name
                //         'pantcuff_id',       // Primary key
                //         'back_glow_image',      // glow image
                //         'back_mask_image',      // mask image
                //         'back_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPuffBack          // destination path
                //     ); 

                // $destPuffFolded = '/Glow-Mask/created_suit_images/pants/folded/';
                // $this->createImage( 
                //         'pantcuff',          // table name
                //         'pantcuff_id',       // Primary key
                //         'folded_glow_image',      // glow image
                //         'folded_mask_image',      // mask image
                //         'folded_hi_image',        // highlight image
                //         $fabric_0,              // created a tile
                //         $destPuffFolded          // destination path
                //     ); 
                
                $this->messageManager->addSuccess(__('suit_lapel Saved successfully'));
                $this->dataPersistor->clear('suit_lapel');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['suit_lapel_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');

            } catch (LocalizedException $e) {
                    $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                echo $e; die;
                    $this->messageManager->addException($e, __('Something went wrong while saving the suit_lapel.'));
                    // print_r($e); 
            }

            $this->dataPersistor->set('suit_lapel', $data);
            return $resultRedirect->setPath('*/*/edit', ['suit_lapel_id' => $this->getRequest()->getParam('suit_lapel_id')]);
            
        }
        return $resultRedirect->setPath('*/*/');
    }
}