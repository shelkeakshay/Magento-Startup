<?php
/**
* Created By:Nisha Jadhav    
* Created On:28th May 2018
* Purpose:Registered the module
*/
	\Magento\Framework\Component\ComponentRegistrar::register(
		\Magento\Framework\Component\ComponentRegistrar::MODULE,
		'Test_Ajax',
		__DIR__
	);
