<?php
namespace Mageplaza\HelloWorld\Block;

class Demo extends \Magento\Framework\View\Element\Template
{
	public function sayHello()
	{
		return __('Custom Product Detail');
	}
}
