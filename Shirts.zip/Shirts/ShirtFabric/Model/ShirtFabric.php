<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Shirts\ShirtFabric\Model;

class ShirtFabric extends \Magento\Framework\Model\AbstractModel
{


    protected function _construct()
    {
        $this->_init('Shirts\ShirtFabric\Model\ResourceModel\ShirtFabric');
    }


    public function getAvailableStatuses()
    {


        $availableOptions = ['1' => 'Enable',
                          '0' => 'Disable'];

        return $availableOptions;
    }
}
