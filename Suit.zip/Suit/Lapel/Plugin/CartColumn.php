<?php
/**
* Created By:Nisha Jadhav    
* Created On:29 April 2018
* Purpose:Create a block data for frontend which contain collection info and extends template
*/
namespace Suit\Lapel\Plugin;
class CartColumn
{
    
    public function afterGetItemRenderer(\Magento\Checkout\Block\Cart\AbstractCart $subject, $result)
    {
        $result->setTemplate('Suit_Lapel::default.phtml');
        return $result;
    }
    
}