<?php
    /**
    * Rewrite Product ListProduct Block
    * @category    FME
    * @package     FME_Test
    * @author      Fme Extensions Development Company
    */
 namespace Test\Ajax\Block\Rewrite\Product;

class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
{
	public function demo(){
        // echo "hi";
        return "Demo****************";
        }
    }
