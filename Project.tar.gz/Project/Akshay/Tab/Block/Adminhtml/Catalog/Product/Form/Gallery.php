<?php
namespace Akshay\Tab\Block\Adminhtml\Catalog\Product\Form;

class Gallery extends \Magento\Backend\Block\Template
{
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'group/gallery.phtml';
    
    function data(){
        
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->get('Magento\Framework\Registry')->registry('current_product');//get current product
        $id= $product->getId();
        if (isset($id)){
        $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
        ->get('Magento\Framework\App\ResourceConnection');
        $connection= $this->_resources->getConnection();
        $table = $this->_resources->getTableName('custom_tab');
        
        $sql = "Select * FROM " . $table." where id=".$id;
       // echo $sql;
        $result = $connection->fetchAll($sql);
     
        }
        else {
            $result[0]['tab_value']=-1;
        }
        return $result;
    }
    
}