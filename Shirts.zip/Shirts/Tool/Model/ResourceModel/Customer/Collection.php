<?php
namespace Shirts\Tool\Model\ResourceModel\Customer;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'customers_collection';
	protected $_eventObject = 'customer_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Shirts\Tool\Model\Customer', 'Shirts\Tool\Model\ResourceModel\Customer');
	}

}
