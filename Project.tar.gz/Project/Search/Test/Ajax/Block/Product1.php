<?php

namespace Test\Ajax\Block;

use Magento\Catalog\Model\Product;

use Magento\GroupedProduct\Block\Product\View\Type\Grouped as MagentoGrouped;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Framework\Stdlib\ArrayUtils;
use Magento\Catalog\Model\ProductFactory;

Class Product1 extends \Magento\Framework\View\Element\Template
{   
      
    public function __construct(
       
        ProductFactory $productFactory,
        Context $context,
        ArrayUtils $arrayUtils,
        array $data = [],
        \Magento\Framework\Registry $registry      
       )
    {
       
        $this->productFactory               = $productFactory;
        $this->registry     = $registry;
        parent::__construct($context, $data);
    }
    
    public function getProductById()
    {
         $productId = $this->registry->registry('custom');

          $object= \Magento\Framework\App\ObjectManager::getInstance();
         return   $object->create('Magento\Catalog\Model\Product')->load($productId);
    }
}