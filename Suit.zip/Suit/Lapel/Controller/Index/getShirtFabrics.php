<?php

namespace Suit\Lapel\Controller\Index;

class getShirtFabrics extends \Magento\Framework\App\Action\Action{
	

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory	
		)
	{
		$this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$this->resource = $this->objectManager->get('Magento\Framework\App\ResourceConnection');
		$this->connection = $this->resource->getConnection();
		$this->resultJsonFactory = $resultJsonFactory;
		return parent::__construct($context);
	}

	public function execute()
	{	
		return $this->getShirtFabricsAction();

	}
	
	public function getShirtFabricsAction() {
		 
		$storeManager = $this->objectManager->get('\Magento\Store\Model\StoreManagerInterface');
		$basePath = $storeManager->getStore()->getBaseUrl();  // get base url...

		//Select Data from table
		$sqlmaterial = "SELECT * FROM fabric_season WHERE status='1'";
		$material_collection = $this->connection->fetchAll($sqlmaterial); 
										// gives associated array, table fields as key in array.
		$materials = array();
        foreach ($material_collection as $material) {
            $id = $material['season_id'];
            $name = $material['title'];
            $status = $material['status'];
            if ($status) {
                $materials[] = array('id' => $id, 'name' => $name, 'parent' => 'material');
            }
        }

        $sqlpattern = "SELECT * FROM fabric_pattern WHERE status='1'";
        $pattern_collection = $this->connection->fetchAll($sqlpattern);
        $patterns = array();
        foreach ($pattern_collection as $pattern) {
            $id = $pattern['pattern_id'];
            $name = $pattern['title'];
            if ($status) {
                $patterns[] = array('id' => $id, 'name' => $name, 'parent' => 'pattern');
            }
        }
       
        $sqlseason = "SELECT * FROM fabric_material WHERE status='1'";
        $season_collection = $this->connection->fetchAll($sqlseason);
        $seasons = array();
        foreach ($season_collection as $season) {
            $id = $season['material_id'];
            $name = $season['title'];
            if ($status) {
                $seasons[] = array('id' => $id, 'name' => $name, 'parent' => 'seasons');
            }
        }

        $sqlcolor = "SELECT * FROM fabric_color WHERE status='1'";
        $color_collection = $this->connection->fetchAll($sqlcolor);
        $colors = array();
        foreach ($color_collection as $color) {
            $id = $color['color_id'];
            $name = $color['title'];
            if ($status) {
                $colors[] = array('id' => $id, 'name' => $name, 'parent' => 'color');
            }
        }

        $sqlcategory = "SELECT * FROM fabric_category WHERE status='1'";
        $category_collection = $this->connection->fetchAll($sqlcategory);
        $categorys = array();
        foreach ($category_collection as $category) {
            $id = $category['category_id'];
            $name = $category['title'];
            $class = $category['class'];
            if ($status) {
                $categorys[] = array('id' => $id, 'name' => $name, 'parent' => 'category', "class" => $class);
            }
        }

        $categories = array($materials, $patterns, $seasons, $colors, $categorys);



        $sqlfab = "SELECT * FROM shirt_shirtfabric WHERE status='1' ORDER BY title ASC";
        $fabrics_collection = $this->connection->fetchAll($sqlfab);

        $fabrics = array();

        try{
    	$i = 0;
        foreach ($fabrics_collection as $fabric) {

            $id = $fabric['fabric_id'];
            $name = $fabric['title'];
            $thumb = $fabric['display_fabric_thumb'];
            $price = $fabric['price'];
            $real_img = $fabric['fabric_large_image'];
            $shirt_type_name = "Cotton";
            $status = $fabric['status'];


            $shirt_material_id = $fabric['fabric_material_id'];
            $sqlmaterial = "SELECT * FROM fabric_material WHERE status='1' 
            				AND material_id='" . $shirt_material_id . "'";
            $material_collection = $this->connection->fetchAll($sqlmaterial);


            $shirt_pattern_id = $fabric['fabric_pattern_id'];
            $sqlpattern = "SELECT * FROM fabric_pattern WHERE status='1' AND pattern_id='" . $shirt_pattern_id . "' ";
            $pattern_collection = $this->connection->fetchAll($sqlpattern);

            $shirt_season_id = $fabric['fabric_season_id'];
            $sqlseason = "SELECT * FROM fabric_season WHERE status='1' AND season_id='" . $shirt_season_id . "'";

            $shirt_color_id = $fabric['fabric_color_id'];
            $sqlcolor = "SELECT * FROM fabric_color WHERE status='1' AND color_id='" . $shirt_color_id . "'";
            $color_collection = $this->connection->fetchAll($sqlcolor);

            $shirt_category_id = $fabric['fabric_category_id'];
            $sqlcategory = "SELECT * FROM fabric_category WHERE status='1' 
            	AND category_id='" . $shirt_category_id . "'";
            $category_collection = $this->connection->fetchAll($sqlcategory);

            if ($status) {
                $shirt_fab_type_name = $material_collection[0]['title'];
                $fabrics[] = array(
                	'id' => $id,
                    'name' => $name,
                    'fabric_thumb' => $basePath . 'media/' . $thumb,
                    'real_img' => $basePath . 'media/' . $real_img,
                    'price' => $price,
                    'material_parent' => $material_collection[0]['title'],
                    'pattern_parent' => $pattern_collection[0]['title'],
                    'season_parent' => $season_collection[0]['title'],
                    'color_parent' => $color_collection[0]['title'],
                    'category_parent' => $category_collection[0]['title']
                );
            }
        }
    	}catch(\Exeption $e){
    		echo $e;
    		die;
    	}

        $fabricInfo = array('fabric' => $fabrics, 'category' => $categories);
        // echo json_encode($fabricInfo, true);

        // $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fabricInfo)); X1
        return $this->resultJsonFactory->create()->setData($fabricInfo);   // X2
       
    }
}