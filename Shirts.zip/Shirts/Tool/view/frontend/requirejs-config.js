var config = {
    map: {
        '*': {
            jquery_min: 'Shirts_Tool/js/library/jquery-1.10.2.min',
            jquery_ui: 'Shirts_Tool/js/library/jquery-ui',
            bootstrap_min: 'Shirts_Tool/js/library/bootstrap.min',
            owl_carousel_min: 'Shirts_Tool/js/library/owl.carousel.min',
            scroll_it: 'Shirts_Tool/js/library/scrollIt.min',
            skroll_r: 'Shirts_Tool/js/library/skrollr.min',
            jquery_mcustom_scrollbar: 'Shirts_Tool/js/library/jquery.mCustomScrollbar',
            jquery_elevatezoom: 'Shirts_Tool/js/library/jquery.elevatezoom',

            angular: 'Shirts_Tool/js/library/angular',
            angular_route: 'Shirts_Tool/js/library/angular-route',
            angular_animate: 'Shirts_Tool/js/library/angular-animate',
            html2canvas: 'Shirts_Tool/js/library/html2canvas',

            app: 'Shirts_Tool/js/pipl-shirt/app',
            factory: 'Shirts_Tool/js/pipl-shirt/factory',
            shirt_controller: 'Shirts_Tool/js/pipl-shirt/shirt-controller',
            tool_custom: 'Shirts_Tool/js/pipl-shirt/tool_custom',
            custom_dir: 'Shirts_Tool/js/pipl-shirt/custom-directive',
            custom: 'Shirts_Tool/js/library/custom'
        }
    }
};
