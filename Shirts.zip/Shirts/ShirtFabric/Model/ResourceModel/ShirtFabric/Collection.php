<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Shirts\ShirtFabric\Model\ResourceModel\ShirtFabric;

use \Shirts\ShirtFabric\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'shirtfabric_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Shirts\ShirtFabric\Model\ShirtFabric', 'Shirts\ShirtFabric\Model\ResourceModel\ShirtFabric');
        $this->_map['fields']['shirtfabric_id'] = 'main_table.shirtfabric_id';
    }
}
