require(['jquery'],function(){
          jQuery(document).ready(function() {
              
              jQuery("#isSelect").click(function(){
                sort = jQuery("#product-select-filter").val();
                grouped_pid = jQuery("#grouped_product_id").val();
                q = jQuery('#partsearch').val();
                jQuery.ajax({
                      url : '/magento2.4/ajax/index/filter/',
                      data: { 'q' :  q  , 'grouped_pid': grouped_pid, 'sort': sort},
                      type : 'GET',
                beforeSend: function () {
                  jQuery('body').trigger('processStart');
                },
                success: function (res) {
                    alert('Sort Complete');
                       jQuery('#search-filter-result').html('');
                       jQuery('#search-filter-result').append(res);
                       jQuery('body').trigger('processStop');
                }
                  });
          //alert(q);
              });
            });
                
        });