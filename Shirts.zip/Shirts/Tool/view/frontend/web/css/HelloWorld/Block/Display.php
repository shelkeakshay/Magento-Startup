<?php
namespace Mageplaza\HelloWorld\Block;
class Display extends \Magento\Framework\View\Element\Template
{
	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Mageplaza\HelloWorld\Model\CustomerFactory $customerFactory)
	{
		$this->_customerFactory = $customerFactory;
		parent::__construct($context);
	}

	public function sayHello()
	{
		return __('Custom Product Detail');
	}

	public function getPostCollection(){
	$post = $this->_customerFactory->create();
	return $post->getCollection();
}

}
