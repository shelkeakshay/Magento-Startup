<?php
namespace PartFinder\Extension\Controller\Index;
/**
    * Created By:Nisha Jadhav
    * Created On:26 th June 2018
    * Purpose:Add Product into Cart
*/
use \Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Response\Http;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Json\Helper\Data;
use Psr\Log\LoggerInterface;
use Magento\Checkout\Model\Sidebar;

class Cart extends \Magento\Framework\App\Action\Action
{ 
    protected $sidebar;
 
    /**
     * @var LoggerInterface
     */
    protected $logger;
 
    /**
     * @var Data
     */
    protected $jsonHelper;
 
    /**
     * @var Cart
     */
    protected $cart;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Catalog\Model\Product $product,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Checkout\Model\Session $checkoutSession,
        LoggerInterface $logger,
        Data $jsonHelper,
        Sidebar $sidebar,
        PageFactory $pageFactory
        )
    {
        $this->sidebar = $sidebar;
        $this->logger = $logger;
        $this->jsonHelper = $jsonHelper;
        $this->_checkoutSession = $checkoutSession;
        $this->_cart = $cart;
        $this->_product = $product;
        $this->formKey = $formKey;
        $this->resultPageFactory = $pageFactory;
        return parent::__construct($context);
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        try {
                $productIds = $this->getRequest()->getParam('data');
                $objectManager= \Magento\Framework\App\ObjectManager::getInstance();
                for($i = 0; $i < sizeof($productIds); $i++){
                    $product = $objectManager->create('\Magento\Catalog\Model\Product')->load($productIds[$i]['id']);
                    $itemId = $productIds[$i]['id'];
                    $itemQty = $productIds[$i]['qty']; 
                    $params = array(
                              'form_key' => $this->formKey->getFormKey(),
                              'product' => $itemId, //product Id
                              'qty' => $itemQty//quantity of product
                              
                    );
                
                    $this->_cart->addProduct($product, $params);
                    $this->_cart->save();
                    $this->updateQuoteItem($itemId, $itemQty);
                    $this->messageManager->addSuccess(__('Product has been successfully added to cart.'));
            
            }
            $this->_redirect("checkout/cart/index", $params);
            return $resultPage;
         
        } catch (LocalizedException $e) {
            return $this->jsonResponse($e->getMessage());
        } catch (\Exception $e) {
            $this->logger->critical($e);
            return $this->jsonResponse($e->getMessage());
        }
    
    }
    /**
     * Update quote item
     *
     * @param int $itemId
     * @param int $itemQty
     * @throws LocalizedException
     * @return $this
     */
    public function updateQuoteItem($itemId, $itemQty)
    {
        $itemData = [$itemId => ['qty' => $itemQty]];
        $this->_cart->updateItems($itemData)->save();
    }
 
    /**
     * Get quote object associated with cart. By default it is current customer session quote
     *
     * @return \Magento\Quote\Model\Quote
     */
    public function getQuote()
    {
        return $this->_checkoutSession->getQuote();
    }
 
}
