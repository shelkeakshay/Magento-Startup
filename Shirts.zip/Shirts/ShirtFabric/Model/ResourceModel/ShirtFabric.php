<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Shirts\ShirtFabric\Model\ResourceModel;

class ShirtFabric extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{



    protected function _construct()
    {
        $this->_init('shirts_shirtfabric', 'shirtfabric_id');
    }
}
