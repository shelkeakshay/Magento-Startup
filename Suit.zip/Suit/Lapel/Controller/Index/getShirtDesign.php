<?php

namespace Suit\Lapel\Controller\Index;

class getShirtDesign extends \Magento\Framework\App\Action\Action{
	

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory	
		)
	{
		$this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$this->resource = $this->objectManager->get('Magento\Framework\App\ResourceConnection');
		$this->connection = $this->resource->getConnection();
		$this->resultJsonFactory = $resultJsonFactory;
		return parent::__construct($context);
	}

	public function execute()
	{	
		
        return $this->getShirtButtonFabricAction();
	}

	
	public function getShirtButtonFabricAction() {
        // $basePath = $this->getBasePath();

        $storeManager = $this->objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        $basePath = $storeManager->getStore()->getBaseUrl();  // get base url...

        $sqlCollarStyle = " SELECT * FROM shirtstyle WHERE status='1' ORDER BY shirtstyle_id ASC "; 
            //AND gender='1'
        $collarstyle_collection = $this->connection->fetchAll($sqlCollarStyle);

        $collarstylesArr = array();
        foreach ($collarstyle_collection as $collarstyle) {

            $id     = $collarstyle['shirtstyle_id'];
            $title  = $collarstyle['title'];
            $class  = $collarstyle['class'];
            $price  = $collarstyle['price'];
            $thumb  = $collarstyle['thumb'];
            $status = $collarstyle['status'];

            if ($status) {
                $collarstylesArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Collar Style',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $collarstyle_data = array('id' => 1, 'name' => 'Collar Style', 'designType' => 'shirt', 'class' => 'icon-Collar_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Style_Main_Icon.png', "style" => $collarstylesArr);

        // cuff
        $sqlCuff = "SELECT * FROM shirtcuff WHERE status='1' ORDER BY shirtcuff_id ASC"; //AND gender='1'
        $cuff_collection = $this->connection->fetchAll($sqlCuff);

        $cuffsArr = array();
        foreach ($cuff_collection as $cuff) {

            $id = $cuff['shirtcuff_id'];
            $title = $cuff['title'];
            $class = $cuff['class'];
            $price = $cuff['price'];
            $thumb = null;
            $status = $cuff['status'];

            if ($status) {
                $cuffsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Cuffs',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $cuff_data = array('id' => 2, 'name' => 'Cuffs', 'designType' => 'shirt', 'class' => 'icon-Cuff_Main_Icon', 'img' => $basePath .'media/shirt_images/thumbnail/00_Cuffs_Main_Icon.png', "style" => $cuffsArr);
    
        // sleeves
        $sqlSleeves = "SELECT * FROM shirtsleeves WHERE status='1' ORDER BY shirtsleeves_id ASC"; //AND gender='1'
        $sleeves_collection = $this->connection->fetchAll($sqlSleeves);

        $sleevesArr = array();
        foreach ($sleeves_collection as $sleeves) {

            $id = $sleeves['shirtsleeves_id'];
            $title = $sleeves['title'];
            $class = $sleeves['class'];
            $price = $sleeves['price'];
            $thumb = null;
            $status = $sleeves['status'];

            if ($status) {
                $sleevesArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Sleeves',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $sleeves_data = array('id' => 3, 'name' => 'Sleeves', 'designType' => 'shirt', 'class' => 'icon-Sleeve_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Fit_Main_Icon.png', "style" => $sleevesArr);


        // fit
        $sqlFit = "SELECT * FROM shirtfit WHERE status='1'  ORDER BY shirtfit_id ASC"; //AND gender='1'
        $fit_collection = $this->connection->fetchAll($sqlFit);

        $fitsArr = array();
        foreach ($fit_collection as $fit) {

            $id = $fit['shirtfit_id'];
            $title = $fit['title'];
            $class = $fit['class'];
            $price = $fit['price'];
            $thumb = null;
            $status = $fit['status'];

            if ($status) {
                $fitsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Fit',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }



        $fit_data = array('id' => 4, 'name' => 'Fit', 'designType' => 'shirt', 'class' => 'icon-Fit_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Fit_Main_Icon.png', "style" => $fitsArr);

        // pocket
        $sqlPocket = "SELECT * FROM shirtpocket WHERE status='1' ORDER BY shirtpocket_id ASC"; //AND gender='1'
        $pocket_collection = $this->connection->fetchAll($sqlPocket);

        $pocketsArr = array();
        foreach ($pocket_collection as $pocket) {

            $id = $pocket['shirtpocket_id'];
            $title = $pocket['title'];
            $class = $pocket['class'];
            $price = $pocket['price'];
            $thumb = $pocket['thumb'];
            $status = $pocket['status'];

            if ($status) {
                $pocketsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Pocket',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }

        $pocket_data = array('id' => 5, 'name' => 'Pocket', 'designType' => 'shirt', 'class' => 'icon-Withoutflap_Pocket_Right', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Pocket_Main_Icon.png', "style" => $pocketsArr);
        

        // plackets
        $sqlPlackets = "SELECT * FROM shirtplackets WHERE status='1' ORDER BY shirtplackets_id ASC"; //AND gender='1'
        $plackets_collection = $this->connection->fetchAll($sqlPlackets);

        $placketsArr = array();
        foreach ($plackets_collection as $plackets) {

            $id = $plackets['shirtplackets_id'];
            $title = $plackets['title'];
            $class = $plackets['class'];
            $price = $plackets['price'];
            $thumb = $plackets['thumb'];
            $status = $plackets['status'];

            if ($status) {
                $placketsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Plackets',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $thumb
                );
            }
        }



        $plackets_data = array('id' => 6, 'name' => 'Plackets', 'designType' => 'shirt', 'class' => 'icon-Placket_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Plackets_Main_Icon.png', "style" => $placketsArr);


        // pleats
        $sqlPleats = "SELECT * FROM shirtpleats WHERE status='1' ORDER BY shirtpleats_id ASC"; //AND gender='1'
        $pleats_collection = $this->connection->fetchAll($sqlPleats);

        $pleatsArr = array();
        foreach ($pleats_collection as $pleats) {

            $id = $pleats['shirtpleats_id'];
            $title = $pleats['title'];
            $class = $pleats['class'];
            $price = $pleats['price'];
            $image = $pleats['image'];
            $status = $pleats['status'];

            if ($status) {
                $pleatsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Pleats',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'img' => $basePath . 'media/' . $image
                );
            }
        }



        $pleats_data = array('id' => 7, 'name' => 'Pleats', 'designType' => 'shirt', 'class' => 'icon-Pleats_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00Pleats_Main_Icon.png', "style" => $pleatsArr);

        // bottom
        $sqlBottom = "SELECT * FROM shirtbottom WHERE status='1' ORDER BY shirtbottom_id ASC"; //AND gender='1'
        $bottom_collection = $this->connection->fetchAll($sqlBottom);

        $bottomsArr = array();
        foreach ($bottom_collection as $bottom) {

            $id = $bottom['shirtbottom_id'];
            $title = $bottom['title'];
            $class = $bottom['class'];
            $price = $bottom['price'];
            $view1_image = $bottom['view1_image'];
            $view2_image = $bottom['view2_image'];
            $view3_image = $bottom['view3_image'];
            $status = $bottom['status'];

            if ($status) {
                $bottomsArr[] = array(
                    'id' => $id,
                    'class' => $class,
                    'parent' => 'Bottom',
                    'designType' => 'shirt',
                    'name' => $title,
                    'price' => $price,
                    'view1_image' => $basePath . 'media/' . $view1_image,
                    'view2_image' => $basePath . 'media/' . $view2_image,
                    'view3_image' => $basePath . 'media/' . $view3_image,
                );
            }
        }

        $bottom_data = array('id' => 8, 'name' => 'Bottom', 'designType' => 'shirt', 'class' => 'icon-Bottom_Main_Icon', 'img' => $basePath . 'media/shirt_images/thumbnail/00_Bottom_Main_Icon.png', "style" => $bottomsArr);


        $shirtDesignInfo = array($collarstyle_data, $cuff_data, $sleeves_data, $fit_data, $pocket_data, 
                                $plackets_data, $pleats_data, $bottom_data);
        //        echo json_encode($shirtDesignInfo, true);

        // $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fabrics)); X1
        return $this->resultJsonFactory->create()->setData($shirtDesignInfo);   // X2
    }
}